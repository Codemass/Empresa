<?php
require_once 'conexion.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Recuperar contraseña</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .box{max-width:600px;margin:60px auto;background:#fff;padding:24px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.06);}
    .send_btn{background:#7c5fe9;color:#fff;padding:10px 18px;border-radius:8px;border:none;cursor:pointer;}
    .alert{padding:12px;border-radius:6px;margin-bottom:12px;}
    .alert-warning{background:#fff3cd;color:#856404;border:1px solid #ffeeba;}
  </style>
</head>
<body>
  <div class="box">
    <h3>Recuperar contraseña</h3>
    <p>Ingresa tu correo para recibir un código de 6 dígitos.</p>
    
    <?php if (isset($_GET['msg'])): ?>
      <div class="alert alert-warning">
        <?php echo htmlspecialchars($_GET['msg']); ?>
      </div>
    <?php endif; ?>
    
    <form method="POST" action="send_reset.php">
      <div style="margin-bottom:12px;">
        <label for="correo">Correo electrónico</label>
        <input id="correo" name="correo" type="email" placeholder="tu@correo.com" required style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
      </div>
      <div>
        <button type="submit" class="send_btn">Enviar código</button>
        <a href="login.php" style="margin-left:12px;color:#666;text-decoration:none;">← Volver</a>
      </div>
    </form>
  </div>
</body>
</html>
