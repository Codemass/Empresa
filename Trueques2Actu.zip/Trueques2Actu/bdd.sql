CREATE TABLE Usuario (
    CI INT PRIMARY KEY,
    Nombre VARCHAR(50),
    Apellido VARCHAR(50),
    Contrasena VARCHAR(100),
    Correo VARCHAR(100),
    FechaNacimiento DATE
) ENGINE=InnoDB;

CREATE TABLE Registrado (
    CI INT PRIMARY KEY,
    FOREIGN KEY (CI) REFERENCES Usuario(CI)
) ENGINE=InnoDB;

CREATE TABLE Administrador (
    CI INT PRIMARY KEY,
    FOREIGN KEY (CI) REFERENCES Usuario(CI)
) ENGINE=InnoDB;

CREATE TABLE Publicacion (
    ID_Publicacion INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Estado VARCHAR(20),
    FechaPublicacion DATE
) ENGINE=InnoDB;

CREATE TABLE Trueque (
    ID_Trueque INT PRIMARY KEY,
    ID_PublicacionReceptor INT,
    CI_UsuarioReceptor INT,
    FechaAceptacion DATE,
    FOREIGN KEY (ID_PublicacionReceptor) REFERENCES Publicacion(ID_Publicacion),
    FOREIGN KEY (CI_UsuarioReceptor) REFERENCES Registrado(CI)
) ENGINE=InnoDB;

CREATE TABLE Valoracion (
    ID_Valoracion INT PRIMARY KEY,
    CI_UsuarioEmisor INT,
    CI_UsuarioValorado INT,
    Puntuacion INT,
    Comentario TEXT,
    FOREIGN KEY (CI_UsuarioEmisor) REFERENCES Registrado(CI),
    FOREIGN KEY (CI_UsuarioValorado) REFERENCES Registrado(CI)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS publicaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    imagen VARCHAR(255) NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS solicitudes_trueque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_publicacion INT NOT NULL,
    id_usuario_solicitante INT NOT NULL,
    id_usuario_dueno INT NOT NULL,
    estado VARCHAR(20) DEFAULT 'pendiente',
    fecha_solicitud DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_solicitante) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_dueno) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS chats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_solicitud INT NOT NULL UNIQUE,
    id_usuario_1 INT NOT NULL,
    id_usuario_2 INT NOT NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_solicitud) REFERENCES solicitudes_trueque(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_1) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_2) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS mensajes_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_chat INT NOT NULL,
    id_usuario INT NOT NULL,
    mensaje TEXT NOT NULL,
    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_chat) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);