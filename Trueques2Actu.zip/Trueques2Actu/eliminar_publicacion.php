<?php
require_once 'conexion.php';
session_start();

// Verificar admin con credenciales completas
if (!isset($_SESSION['admin']) || !$_SESSION['admin'] || 
    !isset($_SESSION['ci']) || $_SESSION['ci'] !== '51946920' || 
    !isset($_SESSION['nombre']) || $_SESSION['nombre'] !== 'El' ||
    !isset($_SESSION['apellido']) || $_SESSION['apellido'] !== 'Admin' ||
    !isset($_SESSION['correo']) || $_SESSION['correo'] !== 'codemass2025@gmail.com') {
    http_response_code(403);
    echo "Acceso denegado.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // Obtener ruta de imagen para eliminar el fichero
    $stmt = $conexion->prepare("SELECT imagen FROM publicaciones WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($imagen_ruta);
    if ($stmt->fetch()) {
        $stmt->close();

        // Eliminar registro
        $del = $conexion->prepare("DELETE FROM publicaciones WHERE id = ?");
        $del->bind_param("i", $id);
        if ($del->execute()) {
            // Intentar borrar fichero (si existe y no es URL remota)
            if ($imagen_ruta && !filter_var($imagen_ruta, FILTER_VALIDATE_URL) && file_exists($imagen_ruta)) {
                @unlink($imagen_ruta);
            }
            $del->close();
            header("Location: publicaciones.php?deleted=1");
            exit;
        } else {
            echo "Error al eliminar: " . $conexion->error;
            exit;
        }
    } else {
        $stmt->close();
        echo "Publicación no encontrada.";
        exit;
    }
} else {
    echo "Solicitud inválida.";
    exit;
}
?>
