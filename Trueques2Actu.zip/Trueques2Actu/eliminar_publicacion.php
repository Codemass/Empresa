<?php
require_once 'conexion.php';
session_start();

// Verificar sesión de administrador
if (!isset($_SESSION['correo']) || $_SESSION['correo'] !== 'codemass2025@gmail.com') {
    header('Location: publicaciones.php?error=' . urlencode('No autorizado'));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $motivo = isset($_POST['motivo']) ? trim($_POST['motivo']) : '';
    if ($id <= 0) {
        header('Location: publicaciones.php?error=' . urlencode('ID inválido'));
        exit;
    }

    // Crear tabla de auditoría si no existe
    $sql_create = "CREATE TABLE IF NOT EXISTS eliminaciones (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_publicacion INT NOT NULL,
        motivo TEXT,
        eliminado_por VARCHAR(255),
        fecha DATETIME DEFAULT CURRENT_TIMESTAMP
    )";
    $conexion->query($sql_create);

    // Insertar registro de eliminación
    $stmt_ins = $conexion->prepare("INSERT INTO eliminaciones (id_publicacion, motivo, eliminado_por) VALUES (?, ?, ?)");
    if ($stmt_ins) {
        $user = isset($_SESSION['correo']) ? $_SESSION['correo'] : 'unknown';
        $stmt_ins->bind_param("iss", $id, $motivo, $user);
        $stmt_ins->execute();
        $stmt_ins->close();
    }

    // Eliminar la publicación
    $stmt = $conexion->prepare("DELETE FROM publicaciones WHERE id = ?");
    if (!$stmt) {
        header('Location: publicaciones.php?error=' . urlencode('Error en la consulta'));
        exit;
    }
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $stmt->close();
        header('Location: publicaciones.php?deleted=1');
        exit;
    } else {
        $error = $stmt->error ?: 'No se pudo eliminar';
        $stmt->close();
        header('Location: publicaciones.php?error=' . urlencode($error));
        exit;
    }
} else {
    header('Location: publicaciones.php?error=' . urlencode('Solicitud no válida'));
    exit;
}
?>
