<?php
require_once 'conexion.php';
session_start();

// verificar admin
if (!isset($_SESSION['correo']) || $_SESSION['correo'] !== 'codemass2025@gmail.com') {
    header('Location: index.html');
    exit;
}

// manejar acciones (marcar respondido / eliminar)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = intval($_POST['id']);
    if ($action === 'marcar_respondido') {
        $stmt = $conexion->prepare("UPDATE contact_messages SET estado = 'respondido' WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        header('Location: admin_mensajes.php?updated=1');
        exit;
    } elseif ($action === 'eliminar') {
        $stmt = $conexion->prepare("DELETE FROM contact_messages WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        header('Location: admin_mensajes.php?deleted=1');
        exit;
    }
}

// obtener mensajes
$res = $conexion->query("SELECT * FROM contact_messages ORDER BY fecha_creacion DESC");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Admin - Mensajes de Contacto</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    body { background: linear-gradient(135deg,#e3e0f7 0%,#b6b3e6 100%); }
    .admin-container { background:#fff;border-radius:20px;padding:24px;max-width:1000px;margin:40px auto;box-shadow:0 8px 32px rgba(99,102,241,0.1);}
    .back-link { display:inline-flex; align-items:center; gap:8px; color:#7c5fe9; text-decoration:none; font-weight:600; margin-bottom:12px; }
    .back-link:hover { color:#5558d9; text-decoration:none; }
    table { width:100%; border-collapse:collapse; }
    th, td { padding:10px;border-bottom:1px solid #eee; text-align:left; }
    th { background:#6366f1;color:#fff; }
    .badge { padding:4px 8px;border-radius:6px;font-weight:600; }
    .badge-pendiente { background:#fff3cd;color:#856404; }
    .badge-respondido { background:#d4edda;color:#155724; }
    .actions { display:flex; gap:8px; }
    .btn { padding:6px 10px;border:none;border-radius:6px;cursor:pointer; }
    .btn-view { background:#6366f1;color:#fff; }
    .btn-ok { background:#28a745;color:#fff; }
    .btn-del { background:#dc3545;color:#fff; }
  </style>
</head>
<body>
  <div class="admin-container">
    <a href="admin_panel.php" class="back-link" aria-label="Volver al panel">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path d="M15 18L9 12L15 6" stroke="#7c5fe9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      ← Volver
    </a>
    <h2>Mensajes de Contacto</h2>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success">Mensaje marcado como respondido.</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success">Mensaje eliminado.</div><?php endif; ?>

    <?php if ($res && $res->num_rows>0): ?>
    <table>
      <thead>
        <tr><th>Remitente</th><th>Contacto</th><th>Mensaje</th><th>Fecha</th><th>Estado</th><th>Acciones</th></tr>
      </thead>
      <tbody>
        <?php while($m = $res->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($m['nombre'] ?: 'Usuario registrado #' . intval($m['id_usuario'])); ?></td>
          <td><?php echo htmlspecialchars($m['correo']); ?><?php if($m['telefono']): ?><br><small><?php echo htmlspecialchars($m['telefono']); ?></small><?php endif; ?></td>
          <td style="max-width:400px;white-space:pre-wrap;"><?php echo htmlspecialchars($m['mensaje']); ?></td>
          <td><?php echo date('d/m/Y H:i', strtotime($m['fecha_creacion'])); ?></td>
          <td><span class="badge <?php echo $m['estado']==='respondido' ? 'badge-respondido' : 'badge-pendiente'; ?>"><?php echo htmlspecialchars(ucfirst($m['estado'])); ?></span></td>
          <td>
            <div class="actions">
              <form method="POST" style="display:inline;">
                <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                <button class="btn btn-ok" name="action" value="marcar_respondido">Marcar respondido</button>
              </form>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Eliminar mensaje?');">
                <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                <button class="btn btn-del" name="action" value="eliminar">Eliminar</button>
              </form>
            </div>

            <!-- Mostrar respuestas existentes -->
            <?php
              $rep_stmt = $conexion->prepare("SELECT r.id, r.mensaje, r.fecha, a.nombre AS admin_nombre FROM admin_replies r LEFT JOIN administradores a ON r.id_admin = a.id WHERE r.contact_id = ? ORDER BY r.fecha ASC");
              if ($rep_stmt) {
                  $rep_stmt->bind_param("i", $m['id']);
                  $rep_stmt->execute();
                  $rep_res = $rep_stmt->get_result();
              }
            ?>
            <?php if (isset($rep_res) && $rep_res->num_rows>0): ?>
              <div style="margin-top:10px;padding:8px;border-left:3px solid #6366f1;background:#fafafa;border-radius:6px;">
                <strong>Respuestas:</strong>
                <?php while($rep = $rep_res->fetch_assoc()): ?>
                  <div style="margin-top:6px;"><small style="color:#666;"><?php echo htmlspecialchars($rep['admin_nombre'] ?: 'Admin'); ?> — <?php echo date('d/m H:i', strtotime($rep['fecha'])); ?></small><div style="background:#fff;padding:8px;border-radius:6px;margin-top:6px;"><?php echo htmlspecialchars($rep['mensaje']); ?></div></div>
                <?php endwhile; ?>
              </div>
            <?php endif; ?>

            <!-- Formulario para responder (envía a admin_responder.php) -->
            <form method="POST" action="admin_responder.php" style="margin-top:8px;">
                <input type="hidden" name="contact_id" value="<?php echo $m['id']; ?>">
                <textarea name="reply" placeholder="Escribir respuesta..." required style="width:100%;min-height:60px;padding:6px;border-radius:6px;margin-top:8px;"></textarea>
                <div style="text-align:right;margin-top:6px;">
                  <button type="submit" class="btn btn-view" style="background:#6366f1;color:#fff;padding:6px 10px;border-radius:6px;border:none;">Enviar respuesta</button>
                </div>
            </form>

          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
    <p>No hay mensajes.</p>
    <?php endif; ?>
  </div>
</body>
</html>
