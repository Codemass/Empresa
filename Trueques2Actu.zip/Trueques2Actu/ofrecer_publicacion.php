<?php
require_once 'conexion.php';
session_start();

// Verificar sesión
if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}

// Obtener user id
$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uidtmp);
        if ($stmtu->fetch()) $user_id = intval($uidtmp);
        $stmtu->close();
    }
}

if (!$user_id) {
    header('Location: login.php');
    exit;
}

// id de la publicación objetivo (la que queremos solicitar)
$id_objetivo = isset($_GET['id_publicacion']) ? intval($_GET['id_publicacion']) : 0;
if ($id_objetivo <= 0) {
    header('Location: publicaciones.php');
    exit;
}

// Obtener publicaciones propias del usuario (excluyendo la objetivo)
$stmt = $conexion->prepare("SELECT id, titulo, descripcion, imagen, categoria FROM publicaciones WHERE id_usuario = ? AND id <> ? ORDER BY fecha_creacion DESC");
$stmt->bind_param("ii", $user_id, $id_objetivo);
$stmt->execute();
$mis_publicaciones = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Ofrecer publicación - Trueque</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<style>
.container { max-width:920px; margin:40px auto; background:#fff;padding:20px;border-radius:12px; box-shadow:0 8px 32px rgba(99,102,241,0.06); }
.pub-card { display:flex; gap:12px; padding:12px; border:1px solid #eee; border-radius:10px; margin-bottom:12px; align-items:center; }
.pub-thumb { width:84px;height:64px;object-fit:cover;border-radius:8px; }
.pub-info { flex:1; }
.btn-offer { background:#7c5fe9;color:#fff;border:none;padding:8px 12px;border-radius:8px; cursor:pointer; }
.empty { color:#777; padding:20px; text-align:center; }
</style>
</head>
<body>
<div class="container">
  <h3>Ofrecer una de tus publicaciones como propuesta</h3>
  <p>Selecciona una publicación propia para ofrecer en trueque por la publicación seleccionada.</p>

  <?php if ($mis_publicaciones && $mis_publicaciones->num_rows > 0): ?>
    <?php while($p = $mis_publicaciones->fetch_assoc()): ?>
      <div class="pub-card">
        <img class="pub-thumb" src="<?php echo htmlspecialchars($p['imagen'] ?: 'images/default-avatar.png'); ?>" alt="">
        <div class="pub-info">
          <strong><?php echo htmlspecialchars($p['titulo']); ?></strong>
          <div style="color:#666;font-size:0.9rem;"><?php echo htmlspecialchars(substr($p['descripcion'],0,140)); ?></div>
        </div>
        <form method="POST" action="procesar_solicitud_trueque.php" style="margin:0;">
          <input type="hidden" name="id_publicacion" value="<?php echo $id_objetivo; ?>">
          <input type="hidden" name="id_publicacion_ofrecida" value="<?php echo $p['id']; ?>">
          <button type="submit" class="btn-offer">Ofrecer</button>
        </form>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="empty">No tienes publicaciones disponibles para ofrecer. <a href="publicar.html">Publica algo</a> primero.</div>
  <?php endif; ?>

  <div style="margin-top:18px;"><a href="publicacion.php?id=<?php echo $id_objetivo; ?>" style="color:#7c5fe9;">← Volver a la publicación</a></div>
</div>
</body>
</html>
