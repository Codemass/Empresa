<?php
require_once 'conexion.php';
session_start();

// Verificar si es admin
$is_admin = false;
if (isset($_SESSION['correo']) && $_SESSION['correo'] === 'codemass2025@gmail.com') {
    $is_admin = true;
}

if (!$is_admin || !isset($_GET['id'])) {
    header('Location: admin_chats.php');
    exit;
}

$id_chat = intval($_GET['id']);

// Obtener info del chat
$stmt = $conexion->prepare("SELECT c.id, c.fecha_creacion,
                           u1.nombre AS nombre_usuario_1, u1.apellido AS apellido_usuario_1,
                           u2.nombre AS nombre_usuario_2, u2.apellido AS apellido_usuario_2,
                           p.titulo AS publicacion_titulo
                           FROM chats c
                           JOIN usuarios u1 ON c.id_usuario_1 = u1.id
                           JOIN usuarios u2 ON c.id_usuario_2 = u2.id
                           JOIN solicitudes_trueque st ON c.id_solicitud = st.id
                           JOIN publicaciones p ON st.id_publicacion = p.id
                           WHERE c.id = ?");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$chat_info = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Obtener mensajes
$stmt = $conexion->prepare("SELECT mc.id, mc.id_usuario, mc.mensaje, mc.fecha_envio, u.nombre, u.apellido
                            FROM mensajes_chat mc
                            JOIN usuarios u ON mc.id_usuario = u.id
                            WHERE mc.id_chat = ?
                            ORDER BY mc.fecha_envio ASC");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$mensajes_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Detalle del Chat - Admin</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    body { background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%); }
    .container { background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(99,102,241,0.1); padding: 30px; margin: 40px auto; max-width: 800px; }
    h2 { color: #7c5fe9; margin-bottom: 20px; }
    .chat-info { background: #f8f9ff; padding: 16px; border-radius: 8px; margin-bottom: 20px; }
    .chat-messages { background: #f8f9ff; border-radius: 8px; padding: 20px; max-height: 500px; overflow-y: auto; margin-bottom: 20px; }
    .mensaje { padding: 12px; border-radius: 8px; margin-bottom: 12px; }
    .mensaje-usuario { background: #e3e0f7; color: #333; }
    .timestamp { font-size: 0.85rem; color: #999; }
  </style>
</head>
<body>
  <div class="container">
    <a href="admin_chats.php" style="color:#6366f1;text-decoration:none;margin-bottom:20px;display:inline-block;">← Volver a Chats</a>
    
    <h2>Detalle del Chat</h2>
    
    <?php if ($chat_info): ?>
    <div class="chat-info">
      <p><strong>Usuarios:</strong> <?php echo htmlspecialchars($chat_info['nombre_usuario_1'] . ' ' . $chat_info['apellido_usuario_1']); ?> ↔ <?php echo htmlspecialchars($chat_info['nombre_usuario_2'] . ' ' . $chat_info['apellido_usuario_2']); ?></p>
      <p><strong>Publicación:</strong> <?php echo htmlspecialchars($chat_info['publicacion_titulo']); ?></p>
      <p><strong>Iniciado:</strong> <?php echo date('d/m/Y H:i', strtotime($chat_info['fecha_creacion'])); ?></p>
    </div>

    <div class="chat-messages">
      <?php while($msg = $mensajes_result->fetch_assoc()): ?>
      <div class="mensaje mensaje-usuario">
        <strong><?php echo htmlspecialchars($msg['nombre'] . ' ' . $msg['apellido']); ?></strong><br>
        <?php echo htmlspecialchars($msg['mensaje']); ?>
        <div class="timestamp"><?php echo date('d/m/Y H:i', strtotime($msg['fecha_envio'])); ?></div>
      </div>
      <?php endwhile; ?>
    </div>
    <?php else: ?>
    <p>Chat no encontrado</p>
    <?php endif; ?>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
