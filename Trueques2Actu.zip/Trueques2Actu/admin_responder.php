<?php
require_once 'conexion.php';
session_start();

// Verificar admin
if (!isset($_SESSION['correo']) || $_SESSION['correo'] !== 'codemass2025@gmail.com') {
    header('Location: index.html');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['contact_id']) || !isset($_POST['reply'])) {
    header('Location: admin_mensajes.php');
    exit;
}

$contact_id = intval($_POST['contact_id']);
$reply = trim($_POST['reply']);
$admin_id = null;

// intentar obtener id del admin por correo (si existe en tabla administradores)
if (isset($_SESSION['correo'])) {
    $correo = $_SESSION['correo'];
    $stmt = $conexion->prepare("SELECT id FROM administradores WHERE correo = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $stmt->bind_result($aid);
        if ($stmt->fetch()) $admin_id = intval($aid);
        $stmt->close();
    }
}

// Insertar respuesta
$stmt = $conexion->prepare("INSERT INTO admin_replies (contact_id, id_admin, mensaje) VALUES (?, ?, ?)");
if ($stmt) {
    if ($admin_id === null) {
        $null = null;
        $stmt->bind_param("iis", $contact_id, $null, $reply);
    } else {
        $stmt->bind_param("iis", $contact_id, $admin_id, $reply);
    }
    $stmt->execute();
    $stmt->close();
}

// Marcar mensaje como respondido
$stmt2 = $conexion->prepare("UPDATE contact_messages SET estado = 'respondido' WHERE id = ?");
if ($stmt2) {
    $stmt2->bind_param("i", $contact_id);
    $stmt2->execute();
    $stmt2->close();
}

// (Opcional) podríamos enviar un correo al usuario aquí

header('Location: admin_mensajes.php?updated=1');
exit;
?>
