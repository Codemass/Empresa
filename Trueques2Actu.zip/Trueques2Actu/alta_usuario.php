<?php

if (isset($_POST['enviardatos'])) {
    // Recoger datos con validación básica
    $ci = $_POST['ci'] ?? '';
    $nombre = $_POST['nombre'] ?? '';
    $apellido = $_POST['apellido'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $fechanacimiento = $_POST['fechanacimiento'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';

    if ($ci && $nombre && $apellido && $correo && $fechanacimiento && $contrasena) {
        require("conexion.php");

        // Hash de la contraseña (más seguro que MD5)
        $contrasena_hashed = password_hash($contrasena, PASSWORD_DEFAULT);

        $stmt = $conexion->prepare("INSERT INTO Usuario (CI, Nombre, Apellido, Contrasena, Correo, FechaNacimiento) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $ci, $nombre, $apellido, $contrasena_hashed, $correo, $fechanacimiento);

        if ($stmt->execute()) {
            echo "<script>alert('Registro realizado con éxito.');window.location='index.html';</script>";
        } else {
            echo "<script>alert('No se pudo realizar el alta de registro.');window.location='register.html';</script>";
        }

        $stmt->close();
        $conexion->close();
        exit;
    } else {
        header("location:../index.php?error=campos_vacios");
        exit;
    }
}
?>
