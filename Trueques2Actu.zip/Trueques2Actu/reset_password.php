<?php
require_once 'conexion.php';

$rid = isset($_GET['rid']) ? intval($_GET['rid']) : 0;
$sent = isset($_GET['sent']);
$mailerror = isset($_GET['mailerror']);
$msg = isset($_GET['msg']) ? $_GET['msg'] : '';
$err = isset($_GET['err']) ? $_GET['err'] : '';

if ($rid <= 0) {
    header('Location: forgot_password.php'); exit;
}

// Obtener datos del reset desde BD para validar y mostrar usuario
$stmt = $conexion->prepare("SELECT user_id, email, token, expires_at, used FROM password_resets WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $rid);
$stmt->execute();
$stmt->bind_result($db_user_id, $db_email, $db_token, $db_expires_at, $db_used);
if (!$stmt->fetch()) {
    $stmt->close();
    header('Location: forgot_password.php?msg=' . urlencode('Solicitud inválida o expirada.')); exit;
}
$stmt->close();

// Obtener nombre del usuario
$user_name = '';
if ($db_user_id) {
    $s = $conexion->prepare("SELECT nombre, apellido FROM usuarios WHERE id = ? LIMIT 1");
    $s->bind_param("i", $db_user_id);
    $s->execute();
    $s->bind_result($nm, $ap);
    if ($s->fetch()) {
        $user_name = trim($nm . ' ' . $ap);
    }
    $s->close();
}

// Pasar valores a variables para la plantilla
$correo = $db_email;
$rid = intval($rid);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Restablecer contraseña</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .box{max-width:600px;margin:60px auto;background:#fff;padding:24px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.06);}
    .send_btn{background:#7c5fe9;color:#fff;padding:10px 18px;border-radius:8px;border:none;cursor:pointer;}
    .alert{padding:12px;border-radius:6px;margin-bottom:12px;}
    .alert-success{background:#d4edda;color:#155724;border:1px solid #c3e6cb;}
    .alert-warning{background:#fff3cd;color:#856404;border:1px solid #ffeeba;}
    .alert-danger{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;}
    .correo-display{background:#f8f9fa;padding:12px;border-radius:6px;margin-bottom:12px;border-left:4px solid #7c5fe9;}
    .correo-display label{display:block;font-size:0.9rem;color:#666;margin-bottom:4px;font-weight:600;}
    .correo-display p{margin:0;color:#000;font-weight:500;font-size:1rem;}
  </style>
</head>
<body>
  <div class="box">
    <h3>Restablecer contraseña</h3>
    
    <?php if ($sent): ?>
      <div class="alert alert-success">
        <i class="fa fa-check"></i> ✓ Código enviado al correo registrado. Revisa tu bandeja de entrada.
      </div>
    <?php endif; ?>
    
    <?php if ($mailerror): ?>
      <div class="alert alert-warning">
        <?php echo htmlspecialchars($msg); ?>
      </div>
    <?php endif; ?>
    
    <?php if ($err): ?>
      <div class="alert alert-danger">
        <?php echo htmlspecialchars($err); ?>
      </div>
    <?php endif; ?>

    <!-- Mostrar nombre y correo del usuario (correo no editable, en negro) -->
    <div class="correo-display">
      <?php if ($user_name): ?><label>Usuario:</label><p><?php echo htmlspecialchars($user_name); ?></p><?php endif; ?>
      <label>Correo registrado:</label>
      <p><?php echo htmlspecialchars($correo); ?></p>
    </div>

    <p>Ingresa el código que recibiste por correo y la nueva contraseña.</p>

    <form method="POST" action="process_reset.php">
      <input type="hidden" name="rid" value="<?php echo intval($rid); ?>">
      
      <div style="margin-bottom:12px;">
        <label for="code">Código (6 dígitos)</label>
        <input id="code" name="code" type="text" pattern="\d{6}" maxlength="6" placeholder="000000" required style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
      </div>
      
      <div style="margin-bottom:12px;">
        <label for="password">Nueva contraseña</label>
        <input id="password" name="password" type="password" minlength="6" required style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
      </div>
      
      <div style="margin-bottom:12px;">
        <label for="password_confirm">Confirmar contraseña</label>
        <input id="password_confirm" name="password_confirm" type="password" minlength="6" required style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
      </div>
      
      <div>
        <button type="submit" class="send_btn">Cambiar contraseña</button>
        <a href="login.php" style="margin-left:12px;color:#666;text-decoration:none;">← Volver</a>
      </div>
    </form>
  </div>
</body>
</html>
