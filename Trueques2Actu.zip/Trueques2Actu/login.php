<?php

if(isset($_POST['iniciar'])){
	
	$ci = $_POST['usuario'];
	$contrasena = MD5($_POST['contrasena']);

	// Validar que los campos no estén vacíos
	if($ci!="" && $contrasena!=""){
		require("conexion.php");

		$sql = "SELECT * FROM Usuario WHERE CI = '$ci' AND Contrasena = '$contrasena'";
		$result = $conexion->query($sql);
		$numfilas = mysqli_num_rows($result);

		if($numfilas==1){
			header('Location: index.html');
		}else{
			print "<script>alert('Usuario y/o contraseña incorrectos.');window.location='../index.php';</script>";
			exit;
		}
	}
}

?>