<?php
session_start();
require_once 'conexion.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ci = isset($_POST['ci']) ? trim($_POST['ci']) : '';
    $contrasena = isset($_POST['contrasena']) ? $_POST['contrasena'] : '';

    if ($ci === '' || $contrasena === '') {
        $error = 'Por favor completa C.I. y contraseña.';
    } else {
        // Intentar login como administrador
        $stmt = $conexion->prepare("SELECT id, correo, contrasena FROM administradores WHERE ci = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("s", $ci);
            $stmt->execute();
            $stmt->bind_result($admin_id, $admin_correo, $admin_hash);
            if ($stmt->fetch()) {
                $stmt->close();
                if (password_verify($contrasena, $admin_hash)) {
                    // Login admin exitoso
                    $_SESSION['admin'] = true;
                    $_SESSION['id'] = $admin_id;
                    $_SESSION['ci'] = $ci;
                    $_SESSION['correo'] = $admin_correo;
                    header("Location: publicaciones.php");
                    exit;
                } else {
                    $error = "Credenciales inválidas";
                }
            } else {
                $stmt->close();
                // No es administrador: intentar usuario normal
                $stmt2 = $conexion->prepare("SELECT id, correo, contrasena, nombre, apellido FROM usuarios WHERE ci = ? LIMIT 1");
                if ($stmt2) {
                    $stmt2->bind_param("s", $ci);
                    $stmt2->execute();
                    $stmt2->bind_result($user_id, $user_correo, $user_hash, $user_nombre, $user_apellido);
                    if ($stmt2->fetch()) {
                        $stmt2->close();
                        if (password_verify($contrasena, $user_hash)) {
                            // Login usuario exitoso
                            $_SESSION['user'] = true;
                            $_SESSION['user_id'] = $user_id;
                            $_SESSION['ci'] = $ci;
                            $_SESSION['correo'] = $user_correo;
                            $_SESSION['nombre'] = $user_nombre;
                            $_SESSION['apellido'] = $user_apellido;
                            header("Location: publicaciones.php");
                            exit;
                        } else {
                            $error = "Credenciales inválidas";
                        }
                    } else {
                        $stmt2->close();
                        $error = "Credenciales inválidas";
                    }
                } else {
                    $error = "Error en la consulta de usuarios";
                }
            }
        } else {
            $error = "Error en la consulta de administradores";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <!-- basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- mobile metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="initial-scale=1, maximum-scale=1">
   <!-- site metas -->
   <title>CHANGEMASS</title>
   <meta name="keywords" content="">
   <meta name="description" content="">
   <meta name="author" content="">
   <!-- bootstrap css -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- style css -->
   <link rel="stylesheet" href="css/style.css">
   <!-- Responsive-->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- fevicon -->
   <link rel="icon" href="images/fevicon.png" type="image/gif" />
   <!-- Scrollbar Custom CSS -->
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <!-- Tweaks for older IEs-->
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
      media="screen">
   <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->

<body class="main-layout position_head">
   <!-- loader  -->
   <div class="loader_bg">
      <div class="loader"><img src="images/loading.gif" alt="#" /></div>
   </div>
   <!-- end loader -->
   <!-- header -->
   <header>
      <!-- header inner -->
      <div class="header">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                           <a href="index administrador.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
   </header>
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <style>
      .footer .location_icon li {
         display: inline-flex;
         align-items: center;
         gap: 8px;
         color: #7c5fe9 !important;
         list-style: none;
         font-size: 1rem;
         justify-content: center;
         text-align: left;
      }

      .footer .location_icon i {
         color: #7c5fe9 !important;
      }

      body {
         background: #b6b3e6 !important;
         min-height: 100vh;
      }

      .container {
         background: #fff;
         border-radius: 20px;
         box-shadow: 0 8px 32px 0 #6366f11a;
         padding: 30px 30px;
         margin-top: 30px;
         margin-bottom: 15px;
         max-width: 1000px;
         animation: fadeInUp 1s;
      }
   </style>
   <div id="contact" class="contact">
      <div class="">
         <div class="row">
            <div class="col-md-6">
               <form id="request" class="main_form" action="login.php" method="POST">
                  <div class="row">
                     <div class="col-md-12 ">
                        <h3>Iniciar sesión <p>o <a class="" href="register.php">crear una cuenta</a></p>
                        </h3>
                     </div>

                     <?php if ($error): ?>
                     <div class="col-md-12">
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                     </div>
                     <?php endif; ?>

                     <div class="col-md-12 ">
                        <input class="contactus" placeholder="C.I." type="text" name="ci"
                           pattern="[0-9]+" title="Solo se permiten números del 0 al 9" required
                           oninput="this.value = this.value.replace(/[^0-9]/g, '') " maxlength="8">
                     </div>

                     <div class="col-md-12">
                        <input class="contactus" placeholder="Contraseña" type="password" name="contrasena" required>
                     </div>

                     <div class="col-md-12">
                        <button class="send_btn" type="submit" name="iniciar" value="1">Iniciar sesión</button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <div class="container-fluid">
         <div class="map_section">
            <div id="map">
            </div>
         </div>
      </div>
   </div>
   </div>
   <!-- end contact section -->
   <!--  footer -->
   <footer>
      <div class="footer">
         <div class="container">
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <ul class="location_icon">
                     <li><a
                           href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/@-34.8851079,-56.1953592,17z/data=!3m1!4b1!4m6!3m5!1s0x959f8018248ae2ef:0x51dd959d2d332c67!8m2!3d-34.8851123!4d-56.1927843!16s%2Fg%2F1hd_ld504?entry=ttu&g_ep=EgoyMDI1MDkwNy4wIKXMDSoASAFQAw%3D%3D"><i
                              class="fa fa-map-marker" aria-hidden="true"></i></a><br>Ubicación</li>
                     <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a><br>+598 95 764 982</li>
                     <li><a
                           href="https://mail.google.com/mail/u/1/#sent?compose=CllgCJTGmpJrsBmqKPHhfSRxBZgLMTJvsdBdNdTCfVrZJxjnNFDMcXZMrFTRRgJFgjLfBrCXQjV"><i
                              class="fa fa-envelope" aria-hidden="true"></i></a><br>codemass2025@gmail.com</li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="copyright">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <p>©2025 Design by CODEMASS</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </footer>
   <!-- end footer -->
   <!-- Javascript files-->
   <script src="js/jquery.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/jquery-3.0.0.min.js"></script>
   <!-- sidebar -->
   <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
   <script src="js/custom.js"></script>
   <script>
      // This example adds a marker to indicate the position of Bondi Beach in Sydney,
      // Australia.
      function initMap() {
         var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 11,
            center: { lat: 40.645037, lng: -73.880224 },
         });

         var image = 'images/maps-and-flags.png';
         var beachMarker = new google.maps.Marker({
            position: { lat: 40.645037, lng: -73.880224 },
            map: map,
            icon: image
         });
      }
   </script>

</body>

</html>