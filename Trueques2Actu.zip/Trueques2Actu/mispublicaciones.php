<?php
require_once 'conexion.php';
session_start();

// Verificar sesión
if (!isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}

// Obtener id de usuario por CI
$ci = $_SESSION['ci'];
$stmt = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
$stmt->bind_param("s", $ci);
$stmt->execute();
$stmt->bind_result($user_id);
if (!$stmt->fetch()) {
    $stmt->close();
    echo "Usuario no encontrado.";
    exit;
}
$stmt->close();

// Asegurar columnas 'estado' y 'trocado' en publicaciones
$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'estado'");
if ($res && $res->num_rows === 0) {
    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `estado` VARCHAR(20) NOT NULL DEFAULT 'activo'");
}
$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'trocado'");
if ($res && $res->num_rows === 0) {
    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `trocado` TINYINT(1) NOT NULL DEFAULT 0");
}

// Manejo de acciones (delete / toggle / mark_traded) usando POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['pub_id'])) {
    $action = $_POST['action'];
    $pub_id = intval($_POST['pub_id']);

    // Verificar que la publicación pertenece al usuario
    $chk = $conexion->prepare("SELECT id FROM publicaciones WHERE id = ? AND id_usuario = ? LIMIT 1");
    $chk->bind_param("ii", $pub_id, $user_id);
    $chk->execute();
    $chk->store_result();
    if ($chk->num_rows === 0) {
        $chk->close();
        header('Location: mispublicaciones.php?error=notfound');
        exit;
    }
    $chk->close();

    if ($action === 'delete') {
        $del = $conexion->prepare("DELETE FROM publicaciones WHERE id = ? AND id_usuario = ?");
        $del->bind_param("ii", $pub_id, $user_id);
        $del->execute();
        $del->close();
        header('Location: mispublicaciones.php?deleted=1');
        exit;
    }

    if ($action === 'toggle') {
        // new_state passed in POST
        $new_state = isset($_POST['new_state']) ? $_POST['new_state'] : 'activo';
        $allowed = ['activo','pausado','oculto','trueque'];
        if (!in_array($new_state, $allowed)) $new_state = 'activo';
        $upd = $conexion->prepare("UPDATE publicaciones SET estado = ? WHERE id = ? AND id_usuario = ?");
        $upd->bind_param("sii", $new_state, $pub_id, $user_id);
        $upd->execute();
        $upd->close();
        header('Location: mispublicaciones.php?updated=1');
        exit;
    }

    if ($action === 'mark_traded') {
        $upd = $conexion->prepare("UPDATE publicaciones SET estado = 'trueque', trocado = 1 WHERE id = ? AND id_usuario = ?");
        $upd->bind_param("ii", $pub_id, $user_id);
        $upd->execute();
        $upd->close();
        header('Location: mispublicaciones.php?traded=1');
        exit;
    }
}

// Obtener publicaciones del usuario
$q = $conexion->prepare("SELECT id, titulo, fecha_creacion, estado, trocado FROM publicaciones WHERE id_usuario = ? ORDER BY fecha_creacion DESC");
$q->bind_param("i", $user_id);
$q->execute();
$result = $q->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mis Publicaciones | CHANGEMASS</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%);
            min-height: 100vh;
        }
        .container {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(99, 102, 241, 0.10);
            padding: 40px 32px;
            margin-top: 40px;
            margin-bottom: 40px;
            max-width: 900px;
            animation: fadeInUp 1s;
        }
        h2 {
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            color: #6366f1;
            letter-spacing: 1px;
            margin-bottom: 30px;
            text-shadow: 0 2px 8px rgba(99,102,241,0.08);
            text-align: center;
        }
        .publicacion {
            background: #f8f8ff;
            border-radius: 14px;
            padding: 20px;
            margin-bottom: 16px;
            box-shadow: 0 4px 12px rgba(99,102,241,0.08);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s;
        }
        .publicacion:hover {
            transform: scale(1.01);
        }
        .pub-info h5 {
            margin: 0;
            color: #4b3bbd;
            font-weight: 600;
        }
        .pub-info p {
            margin: 4px 0 0;
            color: #6b6b6b;
            font-size: 0.9rem;
        }
        .pub-actions i {
            font-size: 1.4rem;
            margin-left: 15px;
            cursor: pointer;
            transition: color 0.3s, transform 0.2s;
        }
        .pub-actions i:hover {
            transform: scale(1.2);
        }
        .view-btn { color: #4b3bbd; }       /* ojito azul */
        .pause-btn { color: #e0b100; }      /* amarillo */
        .resume-btn { color: #4bbd4b; }     /* verde */
        .delete-btn { color: #e34b4b; }
        .hide-btn { color: #888; }
        .traded-badge { background:#4bbd4b;color:#fff;padding:4px 8px;border-radius:8px;font-weight:600;font-size:0.85rem; }
        .estado-texto { font-weight:700; color:#333; }

        .footer .location_icon li {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #7c5fe9 !important;
            list-style: none;
            font-size: 1rem;
            justify-content: center;
        }
    </style>
</head>
<body class="main-layout position_head">

<header>
   <div class="header">
      <div class="container-fluid">
         <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
               <div class="full">
                  <div class="center-desk">
                     <div class="logo">
                        <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150"/></a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
               <nav class="navigation navbar navbar-expand-md navbar-dark">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04"
                     aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarsExample04">
                     <ul class="navbar-nav mr-auto">
                        <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                        <li class="nav-item"><a class="nav-link" href="publicaciones.php">Publicaciones</a></li>
                        <li class="nav-item"><a class="nav-link" href="publicar.php">Publicar</a></li>
                        <li class="nav-item"><a class="nav-link" href="contactanos.html">Contactanos</a></li>
                        <li class="nav-item d_none login_btn">
                           <a class="nav-link" href="ajustes.html">
                              <i class="fa-solid fa-gear" style="margin-right:6px;"></i> Ajustes
                           </a>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
   </div>
</header>

<div class="container animate__animated animate__fadeInUp">
    <h2><i class="fa-solid fa-file-lines" style="margin-right:10px;"></i> Mis Publicaciones</h2>

    <?php
    // mensajes
    if (isset($_GET['deleted'])) echo '<div class="alert alert-success">Publicación eliminada.</div>';
    if (isset($_GET['updated'])) echo '<div class="alert alert-success">Estado actualizado.</div>';
    if (isset($_GET['traded'])) echo '<div class="alert alert-success">Publicación marcada como trueque.</div>';

    if ($result && $result->num_rows > 0):
        while($row = $result->fetch_assoc()):
            $estado = $row['estado'];
            $trocado = intval($row['trocado']);
    ?>
    <div class="publicacion" data-estado="<?php echo htmlspecialchars($estado); ?>">
        <div class="pub-info">
            <h5><?php echo htmlspecialchars($row['titulo']); ?></h5>
            <p>Publicado el <?php echo date('d/m/Y', strtotime($row['fecha_creacion'])); ?> — Estado: <span class="estado-texto"><?php echo htmlspecialchars(ucfirst($estado)); ?></span>
            <?php if ($trocado): ?> — <span class="traded-badge">Trocado</span><?php endif; ?>
            </p>
        </div>
        <div class="pub-actions">
            <a href="publicacion.php?id=<?php echo $row['id']; ?>" title="Ver publicación"><i class="fa-solid fa-eye view-btn"></i></a>

            <?php if ($estado === 'activo'): ?>
                <form style="display:inline;" method="POST" action="mispublicaciones.php" onsubmit="return confirm('¿Pausar esta publicación?');">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="pub_id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" name="new_state" value="pausado">
                    <button type="submit" style="background:none;border:none;padding:0;margin:0;"><i class="fa-solid fa-pause pause-btn" title="Pausar publicación"></i></button>
                </form>
                <form style="display:inline;" method="POST" action="mispublicaciones.php" onsubmit="return confirm('¿Ocultar esta publicación?');">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="pub_id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" name="new_state" value="oculto">
                    <button type="submit" style="background:none;border:none;padding:0;margin:0;"><i class="fa-solid fa-eye-slash hide-btn" title="Ocultar publicación"></i></button>
                </form>
            <?php elseif ($estado === 'pausado'): ?>
                <form style="display:inline;" method="POST" action="mispublicaciones.php">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="pub_id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" name="new_state" value="activo">
                    <button type="submit" style="background:none;border:none;padding:0;margin:0;"><i class="fa-solid fa-play resume-btn" title="Reanudar publicación"></i></button>
                </form>
                <form style="display:inline;" method="POST" action="mispublicaciones.php" onsubmit="return confirm('¿Ocultar esta publicación?');">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="pub_id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" name="new_state" value="oculto">
                    <button type="submit" style="background:none;border:none;padding:0;margin:0;"><i class="fa-solid fa-eye-slash hide-btn" title="Ocultar publicación"></i></button>
                </form>
            <?php elseif ($estado === 'oculto'): ?>
                <form style="display:inline;" method="POST" action="mispublicaciones.php">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="pub_id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" name="new_state" value="activo">
                    <button type="submit" style="background:none;border:none;padding:0;margin:0;"><i class="fa-solid fa-eye view-btn" title="Publicar"></i></button>
                </form>
            <?php endif; ?>

            <?php if (!$trocado): ?>
                <form style="display:inline;" method="POST" action="mispublicaciones.php" onsubmit="return confirm('¿Marcar como trocado/trueque?');">
                    <input type="hidden" name="action" value="mark_traded">
                    <input type="hidden" name="pub_id" value="<?php echo $row['id']; ?>">
                    <button type="submit" style="background:none;border:none;padding:0;margin:0;"><i class="fa-solid fa-handshake" title="Marcar como trueque"></i></button>
                </form>
            <?php endif; ?>

            <form style="display:inline;" method="POST" action="mispublicaciones.php" onsubmit="return confirm('¿Eliminar esta publicación?');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="pub_id" value="<?php echo $row['id']; ?>">
                <button type="submit" style="background:none;border:none;padding:0;margin:0;"><i class="fa-solid fa-trash delete-btn" title="Eliminar publicación"></i></button>
            </form>
        </div>
    </div>
    <?php
        endwhile;
    else:
    ?>
    <div class="alert alert-info">No tienes publicaciones todavía.</div>
    <?php endif; ?>

</div>

<footer>
   <div class="footer">
      <div class="container">
         <div class="row">
            <div class="col-md-8 offset-md-2">
               <ul class="location_icon">
                  <li><a href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/"><i class="fa fa-map-marker" aria-hidden="true" style="color:#7c5fe9;"></i></a><br>Ubicación</li>
                  <li><a href="#"><i class="fa fa-phone" aria-hidden="true" style="color:#7c5fe9;"></i></a><br>+598 95 764 982</li>
                  <li><a href="mailto:codemass2025@gmail.com"><i class="fa fa-envelope" aria-hidden="true" style="color:#7c5fe9;"></i></a><br>codemass2025@gmail.com</li>
               </ul>
            </div>
         </div>
      </div>
      <div class="copyright">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <p>©2025 Design by CODEMASS</p>
               </div>
            </div>
         </div>
      </div>
   </div>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>