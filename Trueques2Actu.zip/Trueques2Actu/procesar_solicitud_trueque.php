<?php
require_once 'conexion.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$publicacion_id = $data['publicacion_id'] ?? 0;
$usuario_destino_id = $data['usuario_destino_id'] ?? 0;
$usuario_origen_id = $_SESSION['id_usuario'];

// Crear tabla si no existe
$sql = "CREATE TABLE IF NOT EXISTS solicitudes_trueque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    publicacion_id INT NOT NULL,
    usuario_origen_id INT NOT NULL,
    usuario_destino_id INT NOT NULL,
    estado ENUM('pendiente', 'aceptada', 'rechazada') DEFAULT 'pendiente',
    fecha_solicitud DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id),
    FOREIGN KEY (usuario_origen_id) REFERENCES usuarios(id),
    FOREIGN KEY (usuario_destino_id) REFERENCES usuarios(id)
)";
$conexion->query($sql);

// Verificar si ya existe una solicitud pendiente
$stmt = $conexion->prepare("SELECT id FROM solicitudes_trueque 
                           WHERE publicacion_id = ? AND usuario_origen_id = ? 
                           AND estado = 'pendiente'");
$stmt->bind_param("ii", $publicacion_id, $usuario_origen_id);
$stmt->execute();
if ($stmt->get_result()->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Ya tienes una solicitud pendiente para esta publicación']);
    exit;
}

// Insertar nueva solicitud
$stmt = $conexion->prepare("INSERT INTO solicitudes_trueque 
                           (publicacion_id, usuario_origen_id, usuario_destino_id) 
                           VALUES (?, ?, ?)");
$stmt->bind_param("iii", $publicacion_id, $usuario_origen_id, $usuario_destino_id);

if ($stmt->execute()) {
    // Crear notificación para el usuario destino
    $sql = "CREATE TABLE IF NOT EXISTS notificaciones (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT NOT NULL,
        mensaje TEXT NOT NULL,
        leida BOOLEAN DEFAULT FALSE,
        fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    )";
    $conexion->query($sql);

    $mensaje = "Tienes una nueva solicitud de trueque para tu publicación";
    $stmt = $conexion->prepare("INSERT INTO notificaciones (usuario_id, mensaje) VALUES (?, ?)");
    $stmt->bind_param("is", $usuario_destino_id, $mensaje);
    $stmt->execute();

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al procesar la solicitud']);
}
