<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once 'conexion.php';
session_start();

// Limpiar salida previa
ob_clean();

// Crear tabla si no existe
$sql = "CREATE TABLE IF NOT EXISTS solicitudes_trueque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_publicacion INT NOT NULL,
    id_usuario_solicitante INT NOT NULL,
    id_usuario_dueno INT NOT NULL,
    id_publicacion_ofrecida INT DEFAULT NULL,
    estado VARCHAR(20) DEFAULT 'pendiente',
    fecha_solicitud DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_solicitante) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_dueno) REFERENCES usuarios(id) ON DELETE CASCADE
)";
$conexion->query($sql);

// Verificar sesión de usuario
if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    echo "error:no_sesion";
    exit;
}

// Obtener id_usuario
$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id = intval($uid);
        $stmtu->close();
    }
}

if ($user_id === null) {
    echo "error:usuario_no_encontrado";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id_publicacion'])) {
    echo "error:datos_incompletos";
    exit;
}

$id_publicacion = intval($_POST['id_publicacion']);
$id_publicacion_ofrecida = isset($_POST['id_publicacion_ofrecida']) ? intval($_POST['id_publicacion_ofrecida']) : null;

try {
    // Obtener dueño de la publicación
    $stmt = $conexion->prepare("SELECT id_usuario, titulo FROM publicaciones WHERE id = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception($conexion->error);
    }
    
    $stmt->bind_param("i", $id_publicacion);
    if (!$stmt->execute()) {
        throw new Exception($stmt->error);
    }
    
    $stmt->bind_result($id_usuario_dueno, $pub_titulo);
    if (!$stmt->fetch()) {
        $stmt->close();
        echo "error:publicacion_no_existe";
        exit;
    }
    $stmt->close();

    // NUEVO: validar que la publicación tenga dueño
    if (empty($id_usuario_dueno)) {
        echo "error:publicacion_sin_dueno";
        exit;
    }

    // Verificar que no sea el mismo usuario
    if ($user_id === $id_usuario_dueno) {
        echo "error:misma_publicacion";
        exit;
    }

    // Verificar que no haya solicitud pendiente ya
    $stmt = $conexion->prepare("SELECT id, id_publicacion_ofrecida FROM solicitudes_trueque WHERE id_publicacion = ? AND id_usuario_solicitante = ? AND estado = 'pendiente' LIMIT 1");
    if (!$stmt) {
        throw new Exception($conexion->error);
    }
    $stmt->bind_param("ii", $id_publicacion, $user_id);
    if (!$stmt->execute()) {
        throw new Exception($stmt->error);
    }
    $stmt->bind_result($existing_id, $existing_ofrecida);
    if ($stmt->fetch()) {
        $stmt->close();
        $existing_ofrecida = $existing_ofrecida === null ? null : intval($existing_ofrecida);
        $offered = $id_publicacion_ofrecida === null ? null : intval($id_publicacion_ofrecida);

        // Si es idéntica → tratar como éxito (no duplicar)
        if ($existing_ofrecida === $offered) {
            header('Location: publicaciones.php?success=solicitud_enviada');
            exit;
        }

        // Si difiere → actualizar la oferta en la solicitud existente
        $up = $conexion->prepare("UPDATE solicitudes_trueque SET id_publicacion_ofrecida = ? WHERE id = ?");
        if ($up) {
            if ($offered === null) {
                $null = null;
                $up->bind_param("ii", $null, $existing_id);
            } else {
                $up->bind_param("ii", $offered, $existing_id);
            }
            $up->execute();
            $up->close();
        }

        // Crear notificación por cambio de oferta
        $noti_stmt = $conexion->prepare("INSERT INTO notificaciones (user_id, tipo, referencia_id, mensaje) VALUES (?, 'solicitud_trueque', ?, ?)");
        if ($noti_stmt) {
            $msg_txt = "Solicitud actualizada (nueva oferta) sobre: " . mb_substr($pub_titulo ?: 'Publicación', 0, 80);
            $noti_stmt->bind_param("iis", $id_usuario_dueno, $id_publicacion, $msg_txt);
            $noti_stmt->execute();
            $noti_stmt->close();
        }

        header('Location: publicaciones.php?success=solicitud_enviada');
        exit;
    } else {
        $stmt->close();
    }

    // Insertar solicitud
    $stmt = $conexion->prepare("INSERT INTO solicitudes_trueque (id_publicacion, id_usuario_solicitante, id_usuario_dueno, id_publicacion_ofrecida) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception($conexion->error);
    }
    
    // manejar null para offered
    if ($id_publicacion_ofrecida === null) {
        $null = null;
        $stmt->bind_param("iiii", $id_publicacion, $user_id, $id_usuario_dueno, $null);
    } else {
        $stmt->bind_param("iiii", $id_publicacion, $user_id, $id_usuario_dueno, $id_publicacion_ofrecida);
    }
    if (!$stmt->execute()) {
        throw new Exception($stmt->error);
    }
    
    $stmt->close();

    // NUEVO: crear notificación interna para el dueño
    $noti_stmt = $conexion->prepare("INSERT INTO notificaciones (user_id, tipo, referencia_id, mensaje) VALUES (?, 'solicitud_trueque', ?, ?)");
    if ($noti_stmt) {
        $msg_txt = "Nueva solicitud de trueque sobre: " . mb_substr($pub_titulo ?: 'Publicación', 0, 80);
        $noti_stmt->bind_param("iis", $id_usuario_dueno, $id_publicacion, $msg_txt);
        $noti_stmt->execute();
        $noti_stmt->close();
    }

    // Redirigir siempre (independiente de si fue AJAX o no)
    header('Location: publicaciones.php?success=solicitud_enviada');
    exit;
    
} catch (Exception $e) {
    echo "error:exception_" . urlencode(substr($e->getMessage(), 0, 50));
    exit;
}
?>
