<?php
require_once 'conexion.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    echo json_encode(['success' => false, 'message' => 'no_session']);
    exit;
}

$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id = intval($uid);
        $stmtu->close();
    }
}

if (!$user_id) {
    echo json_encode(['success' => false, 'message' => 'user_not_found']);
    exit;
}

$stmt = $conexion->prepare("UPDATE contact_messages SET estado = 'visto' WHERE id_usuario = ? AND estado = 'respondido'");
if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $ok = $stmt->execute();
    $stmt->close();
    if ($ok) {
        echo json_encode(['success' => true]);
        exit;
    } else {
        echo json_encode(['success' => false, 'message' => 'db_error']);
        exit;
    }
} else {
    echo json_encode(['success' => false, 'message' => 'prepare_failed']);
    exit;
}
?>
