<?php
$servidor   = "localhost";
$usuario    = "root";
$contrasena = "";      // ← aquí pones la contraseña que me dijiste
$base_datos = "proyecto"; // ← ajusta al nombre real de tu BD

$conexion = new mysqli($servidor, $usuario, $contrasena, $base_datos);

if ($conexion->connect_error) {
    // Mensaje claro para desarrollo; en producción no muestres errores crudos
    die("Lo sentimos, este sitio web está experimentando problemas: " . $conexion->connect_error);
}
?>
