<?php
require_once 'conexion.php';
session_start();

// si no hay pending_login en sesión, permitir entrada si viene rid en GET (para soporte)
$rid = isset($_GET['rid']) ? intval($_GET['rid']) : 0;
$correo = isset($_GET['correo']) ? $_GET['correo'] : '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rid = isset($_POST['rid']) ? intval($_POST['rid']) : 0;
    $code = isset($_POST['code']) ? trim($_POST['code']) : '';

    if ($rid <= 0 || $code === '') {
        $err = "Código requerido.";
    } else {
        $stmt = $conexion->prepare("SELECT id, user_id, user_type, email, token, expires_at, used FROM login_verifications WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $rid);
        $stmt->execute();
        $stmt->bind_result($id, $user_id, $user_type, $email, $token, $expires_at, $used);
        if (!$stmt->fetch()) {
            $stmt->close();
            $err = "Solicitud inválida.";
        } else {
            $stmt->close();
            if ($used) { $err = "Este código ya fue utilizado."; }
            elseif (strtotime($expires_at) < time()) { $err = "El código ha expirado."; }
            elseif (!hash_equals(trim($token), trim($code))) { $err = "Código inválido."; }
            else {
                // marcar usado
                $up = $conexion->prepare("UPDATE login_verifications SET used = 1 WHERE id = ? LIMIT 1");
                $up->bind_param("i", $rid);
                $up->execute();
                $up->close();

                // establecer sesión según tipo
                if ($user_type === 'admin') {
                    // obtener datos admin opcionalmente
                    $s = $conexion->prepare("SELECT id, correo FROM administradores WHERE id = ? LIMIT 1");
                    $s->bind_param("i", $user_id);
                    $s->execute();
                    $s->bind_result($aid, $acorreo);
                    if ($s->fetch()) {
                        $_SESSION['admin'] = true;
                        $_SESSION['id'] = $aid;
                        $_SESSION['ci'] = ''; // opcional si no disponible
                        $_SESSION['correo'] = $acorreo;
                    }
                    $s->close();
                } else {
                    $s = $conexion->prepare("SELECT id, nombre, apellido, correo FROM usuarios WHERE id = ? LIMIT 1");
                    $s->bind_param("i", $user_id);
                    $s->execute();
                    $s->bind_result($uid, $nombre, $apellido, $correo_db);
                    if ($s->fetch()) {
                        $_SESSION['user'] = true;
                        $_SESSION['user_id'] = $uid;
                        $_SESSION['ci'] = ''; // no disponible aquí
                        $_SESSION['correo'] = $correo_db;
                        $_SESSION['nombre'] = $nombre;
                        $_SESSION['apellido'] = $apellido;
                    }
                    $s->close();
                }

                header("Location: publicaciones.php");
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Verificar inicio de sesión</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .box{max-width:520px;margin:60px auto;background:#fff;padding:20px;border-radius:10px;box-shadow:0 6px 18px rgba(0,0,0,0.06);}
    .send_btn{background:#7c5fe9;color:#fff;padding:10px 18px;border-radius:8px;border:none;cursor:pointer;}
    .info{margin-bottom:12px;color:#333;}
    .err{color:#c82333;margin-bottom:12px;}
  </style>
</head>
<body>
  <div class="box">
    <h3>Verificación por código</h3>
    <p class="info">Hemos enviado un código al correo registrado<?php if($correo) echo " ({ htmlspecialchars(\$correo) })"; ?>. Ingresa el código para completar el inicio de sesión.</p>

    <?php if (isset($err)): ?><div class="err"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

    <form method="POST" action="verify_login.php">
      <input type="hidden" name="rid" value="<?php echo intval($rid); ?>">
      <div style="margin-bottom:12px;">
        <label>Código (6 dígitos)</label>
        <input name="code" pattern="\d{6}" maxlength="6" required style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
      </div>
      <div>
        <button type="submit" class="send_btn">Verificar y entrar</button>
        <a href="login.php" style="margin-left:12px;color:#666;text-decoration:none;">← Volver</a>
      </div>
    </form>
  </div>
</body>
</html>
