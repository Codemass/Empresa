<?php
session_start();
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['user_id'])) {
    header('Location: miperfil.php');
    exit;
}

$user_id = intval($_POST['user_id']);

// Obtener user_id de sesión (preferir $_SESSION['user_id']; fallback por CI)
$session_uid = null;
if (isset($_SESSION['user_id'])) {
    $session_uid = intval($_SESSION['user_id']);
} elseif (isset($_SESSION['ci'])) {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $session_uid = intval($uid);
        $stmtu->close();
    }
}

// Si no se pudo determinar usuario autenticado, volver al perfil con error (sin enviar a login)
if ($session_uid === null) {
    header('Location: miperfil.php?error=auth');
    exit;
}

// Verificar que la publicación sea del usuario autenticado
if ($session_uid !== $user_id) {
    header('Location: miperfil.php?error=owner');
    exit;
}

if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
    header('Location: miperfil.php?error=upload');
    exit;
}

$allowed = ['image/jpeg','image/png','image/webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $_FILES['avatar']['tmp_name']);
finfo_close($finfo);

if (!in_array($mime, $allowed)) {
    header('Location: miperfil.php?error=type');
    exit;
}

$ext = '';
switch($mime){
  case 'image/jpeg': $ext = 'jpg'; break;
  case 'image/png': $ext = 'png'; break;
  case 'image/webp': $ext = 'webp'; break;
}

// crear carpeta si no existe
$destDir = __DIR__ . '/uploads/avatars';
if (!is_dir($destDir)) mkdir($destDir, 0755, true);

$filename = 'avatar_user_' . $user_id . '_' . time() . '.' . $ext;
$destPath = $destDir . '/' . $filename;

if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $destPath)) {
    header('Location: miperfil.php?error=move');
    exit;
}

// guardar ruta relativa en DB (usa ruta accesible desde web)
$publicPath = 'uploads/avatars/' . $filename;
$stmt = $conexion->prepare("UPDATE usuarios SET avatar = ? WHERE id = ?");
if ($stmt) {
    $stmt->bind_param("si", $publicPath, $user_id);
    $stmt->execute();
    $stmt->close();
}

// redirigir de vuelta al perfil (sin pasar por login)
header('Location: miperfil.php?updated=1');
exit;
?>
