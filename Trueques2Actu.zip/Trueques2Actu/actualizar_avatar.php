<?php
session_start();
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['user_id'])) {
    header('Location: miperfil.php');
    exit;
}

$user_id = intval($_POST['user_id']);

// verificar que el usuario en sesión coincide (opcional)
if (!isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
    header('Location: miperfil.php?error=upload');
    exit;
}

$allowed = ['image/jpeg','image/png','image/webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $_FILES['avatar']['tmp_name']);
finfo_close($finfo);

if (!in_array($mime, $allowed)) {
    header('Location: miperfil.php?error=type');
    exit;
}

$ext = '';
switch($mime){
  case 'image/jpeg': $ext = 'jpg'; break;
  case 'image/png': $ext = 'png'; break;
  case 'image/webp': $ext = 'webp'; break;
}

// crear carpeta si no existe
$destDir = __DIR__ . '/uploads/avatars';
if (!is_dir($destDir)) mkdir($destDir, 0755, true);

$filename = 'avatar_user_' . $user_id . '_' . time() . '.' . $ext;
$destPath = $destDir . '/' . $filename;

if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $destPath)) {
    header('Location: miperfil.php?error=move');
    exit;
}

// guardar ruta relativa en DB (usa ruta accesible desde web)
$publicPath = 'uploads/avatars/' . $filename;
$stmt = $conexion->prepare("UPDATE usuarios SET avatar = ? WHERE id = ?");
if ($stmt) {
    $stmt->bind_param("si", $publicPath, $user_id);
    $stmt->execute();
    $stmt->close();
}

// redirigir de vuelta al perfil
header('Location: miperfil.php?updated=1');
exit;
?>
