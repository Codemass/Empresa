<?php
require_once 'conexion.php';

$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviardatos'])) {
    $ci = isset($_POST['ci']) ? trim($_POST['ci']) : '';
    $nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $apellido = isset($_POST['apellido']) ? trim($_POST['apellido']) : '';
    $correo = isset($_POST['correo']) ? trim($_POST['correo']) : '';
    $fecha_nacimiento = isset($_POST['fechanacimiento']) ? trim($_POST['fechanacimiento']) : '';
    $contrasena = isset($_POST['contrasena']) ? $_POST['contrasena'] : '';

    // Validaciones
    if ($ci === '' || $nombre === '' || $apellido === '' || $correo === '' || $fecha_nacimiento === '' || $contrasena === '') {
        $mensaje = 'Faltan campos obligatorios';
        $tipo_mensaje = 'error';
    } elseif (!preg_match('/^[0-9]{1,8}$/', $ci)) {
        $mensaje = 'C.I. inválida (solo números, máximo 8 dígitos)';
        $tipo_mensaje = 'error';
    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensaje = 'Correo inválido';
        $tipo_mensaje = 'error';
    } else {
        // Verificar duplicados
        $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? OR correo = ?");
        if ($stmt) {
            $stmt->bind_param("ss", $ci, $correo);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $mensaje = 'C.I. o correo ya registrado';
                $tipo_mensaje = 'error';
                $stmt->close();
            } else {
                $stmt->close();
                // Insertar usuario
                $hash = password_hash($contrasena, PASSWORD_DEFAULT);
                $insert = $conexion->prepare("INSERT INTO usuarios (ci, nombre, apellido, correo, fecha_nacimiento, contrasena) VALUES (?, ?, ?, ?, ?, ?)");
                if ($insert) {
                    $insert->bind_param("ssssss", $ci, $nombre, $apellido, $correo, $fecha_nacimiento, $hash);
                    if ($insert->execute()) {
                        $mensaje = 'Registro exitoso. Redirigiendo al login...';
                        $tipo_mensaje = 'success';
                        $insert->close();
                        header('refresh:2;url=login.php');
                    } else {
                        $mensaje = 'Error al registrar: ' . $insert->error;
                        $tipo_mensaje = 'error';
                        $insert->close();
                    }
                } else {
                    $mensaje = 'Error en la consulta de inserción.';
                    $tipo_mensaje = 'error';
                }
            }
        } else {
            $mensaje = 'Error en la consulta de verificación.';
            $tipo_mensaje = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>CHANGEMASS</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
   </head>
   <body class="main-layout position_head">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href=""><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <h1>CHANGEMASS</h1>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- contact section -->
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <style>
         .footer .location_icon li {
               display: inline-flex;
               align-items: center;
               gap: 8px;
               color: #7c5fe9 !important;
               list-style: none;
               font-size: 1rem;
               justify-content: center;
               text-align: left;
            }
            .footer .location_icon i {
               color: #7c5fe9 !important;
            }
            .container {
               background: #fff;
               border-radius: 20px;
               box-shadow: 0 8px 32px 0 #6366f11a;
               padding: 50px;
               margin-top: 780px;
               margin-bottom: 15px;
               max-width: 850px;
               animation: fadeInUp 1s;
            }
            .containerr {
               background: #fff;
               border-radius: 20px;
               box-shadow: 0 8px 32px 0 #6366f11a;
               padding: 50px;
            
               margin-top: 80px;
               margin-bottom: 15px;
              
               animation: fadeInUp 1s;
            }
      </style>
      <div id="contact" class="contact">
         <div class="">
            <div class="row">
               <div class="col-md-6">
                  <form id="request" class="main_form" method="POST" action="register.php">
                     <div class="row">
                        <div class="col-md-12 ">
                          <h3>Crear cuenta<p>o <a class="" href="login.php">Iniciar sesion</a></p></h3>
                        </div>

                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="C.I." type="text" name="ci"
                              pattern="[0-9]+" title="Solo se permiten números del 0 al 9" required
                              oninput="this.value = this.value.replace(/[^0-9]/g, '') " maxlength="8">
                        </div>
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="Nombre" type="text" name="nombre" required>
                        </div>
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="Apellido" type="text" name="apellido" required>
                        </div>
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="Correo" type="email" name="correo" required>
                        </div>
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="Fecha de Nacimiento" type="date" name="fechanacimiento" required>
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Contraseña" type="password" name="contrasena" required>
                        </div>
                        <div class="col-md-12">
                           <button class="send_btn" type="submit" name="enviardatos" value="1">Registrar</button>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <!--  footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/@-34.8851079,-56.1953592,17z/data=!3m1!4b1!4m6!3m5!1s0x959f8018248ae2ef:0x51dd959d2d332c67!8m2!3d-34.8851123!4d-56.1927843!16s%2Fg%2F1hd_ld504?entry=ttu&g_ep=EgoyMDI1MDkwNy4wIKXMDSoASAFQAw%3D%3D"><i class="fa fa-map-marker" aria-hidden="true"></i></a><br>Ubicación</li>
                        <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a><br>+598 95 561 757</li>
                        <li><a href="https://mail:codemass2025@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a><br>codemass2025@gmail.com</li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="containerr">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>
