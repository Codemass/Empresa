<?php
require_once 'conexion.php';
session_start();

// Detectar admin
$is_admin = false;
if (isset($_SESSION['correo']) && $_SESSION['correo'] === 'codemass2025@gmail.com') {
    $is_admin = true;
}

// Obtener id de la publicación
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    header("Location: publicaciones.php");
    exit;
}

// Consulta simple primero
$stmt = $conexion->prepare("SELECT * FROM publicaciones WHERE id = ?");
if ($stmt === false) {
    die('Error en la preparación de la consulta: ' . $conexion->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();
$publicacion = $resultado->fetch_assoc();

if (!$publicacion) {
    header("Location: publicaciones.php");
    exit;
}

// Si existe id_usuario, obtener información del usuario
if (isset($publicacion['id_usuario'])) {
    $stmt = $conexion->prepare("SELECT nombre FROM usuarios WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $publicacion['id_usuario']);
        $stmt->execute();
        $usuario_result = $stmt->get_result();
        $usuario = $usuario_result->fetch_assoc();
        $publicacion['nombre_usuario'] = $usuario ? $usuario['nombre'] : 'Usuario Anónimo';
    }
} else {
    $publicacion['nombre_usuario'] = 'Usuario Anónimo';
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CHANGEMASS - <?php echo htmlspecialchars($publicacion['categoria']); ?></title>
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/responsive.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   </head>
   <body class="main-layout position_head">
      <!-- header -->
      <header>
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark">
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                              <li class="nav-item"><a class="nav-link" href="publicaciones.php">Publicaciones</a></li>
                              <li class="nav-item"><a class="nav-link" href="publicar.html">Publicar</a></li>
                              <li class="nav-item"><a class="nav-link" href="contactanos.html">Contactanos</a></li>
                              <?php if ($is_admin): ?>
                              <li class="nav-item">
                                 <a class="nav-link" href="admin_panel.php" style="font-weight:700;color:#ffd700;">
                                    <i class="fa fa-shield" aria-hidden="true"></i> Admin
                                 </a>
                              </li>
                              <?php endif; ?>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>

      <!-- Contenido principal -->
      <div class="container animate__animated animate__fadeInUp" style="margin-top:50px;margin-bottom:50px;">
         <div class="row">
            <div class="col-md-8 offset-md-2">
               <div class="glasses_box" style="padding:40px;">
                  <figure style="margin-bottom:30px;">
                     <img src="<?php echo htmlspecialchars($publicacion['imagen']); ?>" 
                          alt="<?php echo htmlspecialchars($publicacion['categoria']); ?>"
                          style="max-width:100%;height:auto;border-radius:15px;box-shadow:0 4px 24px 0 rgba(99,102,241,0.15);">
                  </figure>
                  <h2 style="color:#7c5fe9;font-size:2rem;font-weight:700;margin-bottom:20px;">
                     <?php echo htmlspecialchars($publicacion['categoria']); ?>
                  </h2>
                  <div class="description" style="color:#4b4b4b;font-size:1.1rem;line-height:1.6;margin-bottom:30px;">
                     <?php echo nl2br(htmlspecialchars($publicacion['descripcion'])); ?>
                  </div>
                  <div class="metadata" style="color:#6366f1;font-size:0.9rem;margin-bottom:20px;">
                     <p>Publicado por: <?php echo htmlspecialchars($publicacion['nombre_usuario']); ?></p>
                     <p>Fecha: <?php echo date('d/m/Y', strtotime($publicacion['fecha_creacion'])); ?></p>
                  </div>

                  <?php if ($is_admin): ?>
                  <div class="admin-controls" style="display:flex;gap:10px;justify-content:center;margin-top:20px;">
                     <a href="editar_publicacion.php?id=<?php echo $publicacion['id']; ?>" 
                        class="btn btn-primary">
                        <i class="fa fa-edit"></i> Editar
                     </a>
                     <form action="eliminar_publicacion.php" method="POST" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $publicacion['id']; ?>">
                        <button type="submit" class="btn btn-danger" 
                                onclick="return confirm('¿Seguro que deseas eliminar esta publicación?');">
                           <i class="fa fa-trash"></i> Eliminar
                        </button>
                     </form>
                  </div>
                  <?php endif; ?>

                  <?php if (isset($_SESSION['id_usuario']) && $_SESSION['id_usuario'] != $publicacion['id_usuario']): ?>
                  <div class="trueque-controls" style="text-align:center;margin:20px 0;">
                     <button type="button" class="btn btn-primary" 
                             onclick="solicitarTrueque(<?php echo $publicacion['id']; ?>, <?php echo $publicacion['id_usuario']; ?>)">
                        <i class="fa fa-exchange"></i> Solicitar Trueque
                     </button>
                  </div>
                  <?php endif; ?>

                  <div style="text-align:center;margin-top:30px;">
                     <a href="publicaciones.php" class="read_more">
                        <i class="fa fa-arrow-left"></i> Volver a Publicaciones
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <!-- Footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="#"><i class="fa fa-map-marker"></i></a><span>Ubicación</span></li>
                        <li><a href="#"><i class="fa fa-phone"></i></a><span>+598 95 764 982</span></li>
                        <li><a href="#"><i class="fa fa-envelope"></i></a><span>codemass2025@gmail.com</span></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>

      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <script>
      function solicitarTrueque(idPublicacion, idUsuarioDestino) {
         if (confirm('¿Deseas enviar una solicitud de trueque para este artículo?')) {
            fetch('procesar_solicitud_trueque.php', {
               method: 'POST',
               headers: {
                  'Content-Type': 'application/json',
               },
               body: JSON.stringify({
                  publicacion_id: idPublicacion,
                  usuario_destino_id: idUsuarioDestino
               })
            })
            .then(response => response.json())
            .then(data => {
               if (data.success) {
                  alert('Solicitud de trueque enviada correctamente');
               } else {
                  alert(data.message || 'Error al enviar la solicitud');
               }
            });
         }
      }
      </script>
   </body>
</html>
