<?php
require_once 'conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: contactanos.php');
    exit;
}

$nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : null;
$correo = isset($_POST['correo']) ? trim($_POST['correo']) : null;
$telefono = isset($_POST['telefono']) ? trim($_POST['telefono']) : null;
$mensaje = isset($_POST['mensaje']) ? trim($_POST['mensaje']) : '';

if ($mensaje === '' || $correo === '') {
    header('Location: contactanos.php?sent=0');
    exit;
}

$id_usuario = null;
if (isset($_SESSION['user_id'])) {
    $id_usuario = intval($_SESSION['user_id']);
} elseif (isset($_SESSION['ci'])) {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $id_usuario = intval($uid);
        $stmtu->close();
    }
}

$stmt = $conexion->prepare("INSERT INTO contact_messages (id_usuario, nombre, correo, telefono, mensaje) VALUES (?, ?, ?, ?, ?)");
if ($stmt) {
    // usar NULL para id_usuario si no hay sesión
    if ($id_usuario === null) {
        $null = null;
        $stmt->bind_param("issss", $null, $nombre, $correo, $telefono, $mensaje);
    } else {
        $stmt->bind_param("issss", $id_usuario, $nombre, $correo, $telefono, $mensaje);
    }
    $stmt->execute();
    $stmt->close();
}

header('Location: contactanos.php?sent=1');
exit;
?>
