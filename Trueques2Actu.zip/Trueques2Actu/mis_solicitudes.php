<?php
require_once 'conexion.php';
session_start();

// Verificar sesión de usuario
if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}

$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id = intval($uid);
        $stmtu->close();
    }
}

if ($user_id === null) {
    header('Location: login.php');
    exit;
}

// NUEVO: contar pendientes para badge
$pendientes = 0;
$cp = $conexion->prepare("SELECT COUNT(*) FROM solicitudes_trueque WHERE id_usuario_dueno = ? AND estado = 'pendiente'");
if ($cp) {
    $cp->bind_param("i", $user_id);
    $cp->execute();
    $cp->bind_result($pendientes);
    $cp->fetch();
    $cp->close();
}

// Manejar aceptar/rechazar solicitud
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['id_solicitud'])) {
    $action = $_POST['action'];
    $id_solicitud = intval($_POST['id_solicitud']);

    // Obtener datos de la solicitud (asegurar que pertenezca al dueño)
    $stmt = $conexion->prepare("SELECT id_publicacion, id_usuario_solicitante, id_publicacion_ofrecida FROM solicitudes_trueque WHERE id = ? AND id_usuario_dueno = ?");
    if ($stmt) {
        $stmt->bind_param("ii", $id_solicitud, $user_id);
        $stmt->execute();
        $stmt->bind_result($id_pub, $id_sol, $id_ofrecida);
        if ($stmt->fetch()) {
            $stmt->close();
            
            if ($action === 'aceptar') {
                // Actualizar estado a aceptada
                $stmt = $conexion->prepare("UPDATE solicitudes_trueque SET estado = 'aceptada' WHERE id = ?");
                $stmt->bind_param("i", $id_solicitud);
                $stmt->execute();
                $stmt->close();

                // Crear chat (guardar id_solicitud en chats)
                $stmt = $conexion->prepare("INSERT INTO chats (id_solicitud, id_usuario_1, id_usuario_2) VALUES (?, ?, ?)");
                $stmt->bind_param("iii", $id_solicitud, $user_id, $id_sol);
                $stmt->execute();
                $chat_id = $stmt->insert_id;
                $stmt->close();

                // Marcar publicaciones involucradas como inactivas (no borrarlas para mantener integridad)
                // Marcar la publicación objetivo
                $stmt = $conexion->prepare("UPDATE publicaciones SET activo = 0 WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param("i", $id_pub);
                    $stmt->execute();
                    $stmt->close();
                }
                // Marcar la publicación ofrecida (si existe)
                if (!empty($id_ofrecida)) {
                    $stmt = $conexion->prepare("UPDATE publicaciones SET activo = 0 WHERE id = ?");
                    if ($stmt) {
                        $stmt->bind_param("i", $id_ofrecida);
                        $stmt->execute();
                        $stmt->close();
                    }
                }

                header('Location: mis_solicitudes.php?aceptada=1');
                exit;
            } elseif ($action === 'rechazar') {
                $stmt = $conexion->prepare("UPDATE solicitudes_trueque SET estado = 'rechazada' WHERE id = ?");
                $stmt->bind_param("i", $id_solicitud);
                $stmt->execute();
                $stmt->close();

                header('Location: mis_solicitudes.php?rechazada=1');
                exit;
            }
        } else {
            $stmt->close();
        }
    }
}

// Obtener solicitudes
$stmt = $conexion->prepare("SELECT st.id, st.id_publicacion, st.fecha_solicitud, st.estado, u.nombre, u.apellido, u.avatar, p.titulo, p.imagen
                            FROM solicitudes_trueque st
                            JOIN usuarios u ON st.id_usuario_solicitante = u.id
                            JOIN publicaciones p ON st.id_publicacion = p.id
                            WHERE st.id_usuario_dueno = ?
                            ORDER BY st.fecha_solicitud DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mis Solicitudes de Trueque</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%); min-height: 100vh; }
    .container { background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(99,102,241,0.1); padding: 30px; margin-top: 40px; margin-bottom: 40px; max-width: 900px; }
    h2 { color: #7c5fe9; font-weight: 700; margin-bottom: 30px; }
    .solicitud-card { border: 1px solid #e3e0f7; border-radius: 15px; padding: 20px; margin-bottom: 20px; display: flex; gap: 20px; align-items: center; transition: all 0.3s; }
    .solicitud-card:hover { box-shadow: 0 4px 16px rgba(99,102,241,0.15); }
    .solicitud-avatar { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; }
    .solicitud-info h5 { color: #6366f1; margin: 0 0 8px 0; }
    .solicitud-info p { margin: 4px 0; color: #666; font-size: 0.9rem; }
    .solicitud-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
    .badge-pendiente { background: #fff3cd; color: #856404; }
    .badge-aceptada { background: #d4edda; color: #155724; }
    .badge-rechazada { background: #f8d7da; color: #721c24; }
    .solicitud-actions { display: flex; gap: 8px; margin-left: auto; }
    .solicitud-actions button { padding: 6px 12px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .btn-aceptar { background: #28a745; color: #fff; }
    .btn-aceptar:hover { background: #218838; }
    .btn-rechazar { background: #dc3545; color: #fff; }
    .btn-rechazar:hover { background: #c82333; }
    .btn-ver { background: #6366f1; color: #fff; }
    .btn-ver:hover { background: #5558d9; }
    .empty-state { text-align: center; padding: 60px 20px; color: #999; }
    .empty-state i { font-size: 3rem; margin-bottom: 20px; }
    .alert { padding: 12px; margin-bottom: 20px; border-radius: 8px; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
  </style>
</head>
<body class="main-layout position_head">
  <header>
    <div class="header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
            <div class="full">
              <div class="center-desk">
                <div class="logo">
                  <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
            <nav class="navigation navbar navbar-expand-md navbar-dark">
              <div class="collapse navbar-collapse" id="navbarsExample04">
                <ul class="navbar-nav mr-auto">
                  <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                  <li class="nav-item"><a class="nav-link" href="publicaciones.php">Publicaciones</a></li>
                  <li class="nav-item"><a class="nav-link" href="publicar.html">Publicar</a></li>
                  <li class="nav-item">
                                 <a class="nav-link" href="contactanos.php">Contactanos</a>
                              </li>
                  <li class="nav-item"><a class="nav-link active" href="mis_solicitudes.php">Mis Solicitudes</a></li>
            
                              <li class="nav-item"><a class="nav-link" href="mis_chats.php">Mis Chats</a></li>
                   <li class="nav-item d_none login_btn">
                                 <a class="nav-link" href="ajustes.html">
                                    <i class="fa-solid fa-gear" style="margin-right:6px;"></i> ajustes</a>
                              </li>
                </ul>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </header>

  <div class="container animate__animated animate__fadeInUp">
    <h2><i class="fa fa-inbox"></i> Mis Solicitudes de Trueque <?php if($pendientes>0): ?><span style="background:#ffc107;color:#000;padding:4px 10px;border-radius:14px;font-size:0.8rem;"><?php echo intval($pendientes); ?> pendientes</span><?php endif; ?></h2>

    <?php if (isset($_GET['aceptada'])): ?>
    <div class="alert alert-success">
      <i class="fa fa-check"></i> Solicitud aceptada. El chat se ha creado automáticamente.
    </div>
    <?php elseif (isset($_GET['rechazada'])): ?>
    <div class="alert alert-success">
      <i class="fa fa-times"></i> Solicitud rechazada.
    </div>
    <?php endif; ?>

    <?php if ($result && $result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): ?>
      <div class="solicitud-card">
        <img src="<?php echo htmlspecialchars($row['avatar'] ? $row['avatar'] : 'images/default-avatar.png'); ?>" alt="avatar" class="solicitud-avatar">
        
        <div class="solicitud-info" style="flex: 1;">
          <h5><?php echo htmlspecialchars($row['nombre'] . ' ' . $row['apellido']); ?></h5>
          <p><strong>Solicita trueque por:</strong> <?php echo htmlspecialchars($row['titulo']); ?></p>
          <p><strong>Fecha:</strong> <?php echo date('d/m/Y H:i', strtotime($row['fecha_solicitud'])); ?></p>
          <span class="solicitud-badge badge-<?php echo $row['estado']; ?>">
            <?php echo ucfirst($row['estado']); ?>
          </span>
        </div>

        <div class="solicitud-actions">
          <?php if ($row['estado'] === 'pendiente'): ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="action" value="aceptar">
              <input type="hidden" name="id_solicitud" value="<?php echo $row['id']; ?>">
              <button type="submit" class="btn-aceptar">Aceptar</button>
            </form>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="action" value="rechazar">
              <input type="hidden" name="id_solicitud" value="<?php echo $row['id']; ?>">
              <button type="submit" class="btn-rechazar">Rechazar</button>
            </form>
          <?php elseif ($row['estado'] === 'aceptada'): ?>
         
          <?php endif; ?>
        </div>
      </div>
      <?php endwhile; ?>
    <?php else: ?>
      <div class="empty-state">
        <i class="fa fa-inbox"></i>
        <p>No tienes solicitudes de trueque aún</p>
        <a href="publicaciones.php" class="read_more">Ver Publicaciones</a>
      </div>
    <?php endif; ?>

    <div style="text-align:center;margin-top:30px;">
      <a href="publicaciones.php" class="read_more">
        <i class="fa fa-arrow-left"></i> Volver a Publicaciones
      </a>
    </div>
  </div>
<link rel="stylesheet" href="css/style.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
         <style>
            .footer .location_icon li {
               display: inline-flex;
               align-items: center;
               gap: 8px;
               color: #7c5fe9 !important;
               list-style: none;
               font-size: 1rem;
               justify-content: center;
               text-align: left;
            }
            .footer .location_icon i {
               color: #7c5fe9 !important;
            }
             body {
               background: #b6b3e6 !important;
               min-height: 100vh;
            }
            .container {
               background: #fff;
               border-radius: 20px;
               box-shadow: 0 8px 32px 0 #6366f11a;
               padding: 30px 30px;
               margin-top: 30px;
               margin-bottom: 15px;
               max-width: 1200px;
               animation: fadeInUp 1s;
            }
         
         
            </style>
   <footer>
      <div class="footer">
         <div class="container">
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <ul class="location_icon">
            <li style="margin-bottom:0;"><a href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/@-34.8851079,-56.1953592,17z/data=!3m1!4b1!4m6!3m5!1s0x959f8018248ae2ef:0x51dd959d2d332c67!8m2!3d-34.8851123!4d-56.1927843!16s%2Fg%2F1hd_ld504?entry=ttu&g_ep=EgoyMDI1MDkwNy4wIKXMDSoASAFQAw%3D%3D" target="_blank" rel="noopener noreferrer"><i class="fa fa-map-marker" aria-hidden="true"></i></a><span> Ubicación</span></li>
            <li style="margin-bottom:0;"><a href="#" target="_blank" rel="noopener noreferrer"><i class="fa fa-phone" aria-hidden="true"></i></a><span> +598 95 561 757</span></li>
            <li style="margin-bottom:0;"><a href="https://mail:codemass2025@gmail.com" target="_blank" rel="noopener noreferrer"><i class="fa fa-envelope" aria-hidden="true"></i></a><span> codemass2025@gmail.com</span></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="copyright">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <p>©2025 Design by CODEMASS</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </footer>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
