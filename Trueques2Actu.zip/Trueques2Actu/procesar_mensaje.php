<?php
require_once 'conexion.php';
session_start();

if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}

$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id = intval($uid);
        $stmtu->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id_chat']) || !isset($_POST['mensaje'])) {
    header('Location: publicaciones.php');
    exit;
}

$id_chat = intval($_POST['id_chat']);
$mensaje = trim($_POST['mensaje']);

if ($mensaje === '') {
    header('Location: chat.php?id='.$id_chat);
    exit;
}

// Verificar acceso
$stmt = $conexion->prepare("SELECT id_usuario_1, id_usuario_2 FROM chats WHERE id = ?");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$stmt->bind_result($u1, $u2);
if (!$stmt->fetch() || ($user_id !== $u1 && $user_id !== $u2)) {
    $stmt->close();
    header('Location: publicaciones.php');
    exit;
}
$stmt->close();

// Insertar mensaje
$stmt = $conexion->prepare("INSERT INTO mensajes_chat (id_chat, id_usuario, mensaje) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $id_chat, $user_id, $mensaje);
$stmt->execute();
$stmt->close();

header('Location: chat.php?id='.$id_chat);
exit;
?>
