<?php
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php'); exit;
}

$rid = isset($_POST['rid']) ? intval($_POST['rid']) : 0;
$code = isset($_POST['code']) ? trim($_POST['code']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$password_confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';

if ($rid <= 0 || $code === '' || $password === '' || $password_confirm === '') {
    $err = urlencode("Todos los campos son obligatorios.");
    header("Location: reset_password.php?rid={$rid}&err={$err}");
    exit;
}

if ($password !== $password_confirm) {
    $err = urlencode("Las contraseñas no coinciden.");
    header("Location: reset_password.php?rid={$rid}&err={$err}");
    exit;
}

// Buscar reset
$stmt = $conexion->prepare("SELECT id, user_id, email, token, expires_at, used FROM password_resets WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $rid);
$stmt->execute();
$stmt->bind_result($id, $user_id, $email, $token, $expires_at, $used);
if (!$stmt->fetch()) {
    $stmt->close();
    $err = urlencode("Solicitud inválida.");
    header("Location: forgot_password.php?err={$err}");
    exit;
}
$stmt->close();

if ($used) {
    $err = urlencode("Este código ya fue utilizado.");
    header("Location: forgot_password.php?err={$err}");
    exit;
}

if (strtotime($expires_at) < time()) {
    $err = urlencode("El código ha expirado. Solicita uno nuevo.");
    header("Location: forgot_password.php?err={$err}");
    exit;
}

if (!hash_equals(trim($token), trim($code))) {
    $err = urlencode("Código inválido.");
    header("Location: reset_password.php?rid={$rid}&err={$err}");
    exit;
}

// Actualizar contraseña
$hash = password_hash($password, PASSWORD_DEFAULT);
$up = $conexion->prepare("UPDATE usuarios SET contrasena = ? WHERE id = ? LIMIT 1");
$up->bind_param("si", $hash, $user_id);
if (!$up->execute()) {
    $up->close();
    $err = urlencode("Error al actualizar contraseña.");
    header("Location: reset_password.php?rid={$rid}&err={$err}");
    exit;
}
$up->close();

// marcar token como usado
$mark = $conexion->prepare("UPDATE password_resets SET used = 1 WHERE id = ? LIMIT 1");
$mark->bind_param("i", $rid);
$mark->execute();
$mark->close();

// redirigir a login con éxito
$ok = urlencode("Contraseña cambiada exitosamente. Inicia sesión con tu nueva contraseña.");
header("Location: login.php?ok={$ok}");
exit;
?>
