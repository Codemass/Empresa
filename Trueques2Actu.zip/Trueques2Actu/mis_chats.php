<?php
require_once 'conexion.php';
session_start();

// Verificar sesión de usuario
if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}

$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id = intval($uid);
        $stmtu->close();
    }
}

if ($user_id === null) {
    header('Location: login.php');
    exit;
}

// Obtener chats donde el usuario es participante
$stmt = $conexion->prepare("SELECT c.id, c.id_usuario_1, c.id_usuario_2, c.fecha_creacion,
                           u1.nombre AS nombre_usuario_1, u1.apellido AS apellido_usuario_1, u1.avatar AS avatar_usuario_1,
                           u2.nombre AS nombre_usuario_2, u2.apellido AS apellido_usuario_2, u2.avatar AS avatar_usuario_2,
                           st.id_publicacion, p.titulo AS publicacion_titulo, p.imagen AS publicacion_imagen
                           FROM chats c
                           JOIN usuarios u1 ON c.id_usuario_1 = u1.id
                           JOIN usuarios u2 ON c.id_usuario_2 = u2.id
                           JOIN solicitudes_trueque st ON c.id_solicitud = st.id
                           JOIN publicaciones p ON st.id_publicacion = p.id
                           WHERE c.id_usuario_1 = ? OR c.id_usuario_2 = ?
                           ORDER BY c.fecha_creacion DESC");
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

$sol_pend_badge = 0;
$bp = $conexion->prepare("SELECT COUNT(*) FROM solicitudes_trueque WHERE id_usuario_dueno = ? AND estado='pendiente'");
if ($bp) {
    $bp->bind_param("i", $user_id);
    $bp->execute();
    $bp->bind_result($sol_pend_badge);
    $bp->fetch();
    $bp->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mis Chats</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%); min-height: 100vh; }
    .container { background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(99,102,241,0.1); padding: 30px; margin-top: 40px; margin-bottom: 40px; max-width: 900px; }
    h2 { color: #7c5fe9; font-weight: 700; margin-bottom: 30px; }
    .chat-card { border: 1px solid #e3e0f7; border-radius: 15px; padding: 20px; margin-bottom: 20px; display: flex; gap: 20px; align-items: center; cursor: pointer; transition: all 0.3s; text-decoration: none; color: inherit; }
    .chat-card:hover { box-shadow: 0 4px 16px rgba(99,102,241,0.15); transform: translateY(-2px); text-decoration: none; color: inherit; }
    .chat-avatar { width: 70px; height: 70px; border-radius: 50%; object-fit: cover; }
    .chat-info { flex: 1; }
    .chat-info h5 { color: #6366f1; margin: 0 0 8px 0; font-weight: 600; }
    .chat-info p { margin: 4px 0; color: #666; font-size: 0.9rem; }
    .chat-pub { display: flex; align-items: center; gap: 8px; margin-top: 12px; padding-top: 12px; border-top: 1px solid #e3e0f7; }
    .chat-pub img { width: 40px; height: 40px; border-radius: 8px; object-fit: cover; }
    .chat-pub span { font-size: 0.85rem; color: #999; }
    .chat-btn { background: #6366f1; color: #fff; padding: 8px 16px; border-radius: 8px; text-decoration: none; font-weight: 600; }
    .chat-btn:hover { background: #5558d9; text-decoration: none; }
    .empty-state { text-align: center; padding: 60px 20px; color: #999; }
    .empty-state i { font-size: 3rem; margin-bottom: 20px; }
  </style>
</head>
<body class="main-layout position_head">
  <header>
    <div class="header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
            <div class="full">
              <div class="center-desk">
                <div class="logo">
                  <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
            <nav class="navigation navbar navbar-expand-md navbar-dark">
              <div class="collapse navbar-collapse" id="navbarsExample04">
                <ul class="navbar-nav mr-auto">
                  <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                  <li class="nav-item"><a class="nav-link" href="publicaciones.php">Publicaciones</a></li>
                  <li class="nav-item"><a class="nav-link" href="publicar.html">Publicar</a></li>
                  <li class="nav-item">
                                 <a class="nav-link" href="contactanos.php">Contactanos</a>
                              </li>
                  <li class="nav-item"><a class="nav-link" href="mis_solicitudes.php">Mis Solicitudes<?php if($sol_pend_badge>0): ?> <span style="background:#ffc107;color:#000;padding:2px 8px;border-radius:12px;font-size:0.7rem;"><?php echo intval($sol_pend_badge); ?></span><?php endif; ?></a></li>
                  <li class="nav-item"><a class="nav-link active" href="mis_chats.php">Mis Chats</a></li>
                   <li class="nav-item d_none login_btn">
                                 <a class="nav-link" href="ajustes.html">
                                    <i class="fa-solid fa-gear" style="margin-right:6px;"></i> ajustes</a>
                              </li>
                </ul>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </header>

  <div class="container animate__animated animate__fadeInUp">
    <h2><i class="fa fa-comments"></i> Mis Chats</h2>

    <?php if ($result && $result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): 
        // Determinar cuál es el otro usuario
        $otro_usuario_id = ($user_id === intval($row['id_usuario_1'])) ? intval($row['id_usuario_2']) : intval($row['id_usuario_1']);
        $otro_nombre = ($user_id === intval($row['id_usuario_1'])) ? $row['nombre_usuario_2'] : $row['nombre_usuario_1'];
        $otro_apellido = ($user_id === intval($row['id_usuario_1'])) ? $row['apellido_usuario_2'] : $row['apellido_usuario_1'];
        $otro_avatar = ($user_id === intval($row['id_usuario_1'])) ? $row['avatar_usuario_2'] : $row['avatar_usuario_1'];
      ?>
      <a href="chat.php?id=<?php echo $row['id']; ?>" class="chat-card">
        <img src="<?php echo htmlspecialchars($otro_avatar ? $otro_avatar : 'images/default-avatar.png'); ?>" alt="avatar" class="chat-avatar">
        
        <div class="chat-info">
          <h5><?php echo htmlspecialchars($otro_nombre . ' ' . $otro_apellido); ?></h5>
          <p><strong>Iniciado:</strong> <?php echo date('d/m/Y H:i', strtotime($row['fecha_creacion'])); ?></p>
          
          <div class="chat-pub">
            <img src="<?php echo htmlspecialchars($row['publicacion_imagen']); ?>" alt="publicación">
            <span><strong>Trueque por:</strong> <?php echo htmlspecialchars($row['publicacion_titulo']); ?></span>
          </div>
        </div>

        <div class="chat-btn">Ver Chat →</div>
      </a>
      <?php endwhile; ?>
    <?php else: ?>
      <div class="empty-state">
        <i class="fa fa-comments"></i>
        <p>No tienes chats activos aún</p>
        <a href="publicaciones.php" class="read_more">Ver Publicaciones</a>
      </div>
    <?php endif; ?>

    <div style="text-align:center;margin-top:30px;">
      <a href="publicaciones.php" class="read_more">
        <i class="fa fa-arrow-left"></i> Volver a Publicaciones
      </a>
    </div>
  </div>
<link rel="stylesheet" href="css/style.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
         <style>
            .footer .location_icon li {
               display: inline-flex;
               align-items: center;
               gap: 8px;
               color: #7c5fe9 !important;
               list-style: none;
               font-size: 1rem;
               justify-content: center;
               text-align: left;
            }
            .footer .location_icon i {
               color: #7c5fe9 !important;
            }
             body {
               background: #b6b3e6 !important;
               min-height: 100vh;
            }
            .container {
               background: #fff;
               border-radius: 20px;
               box-shadow: 0 8px 32px 0 #6366f11a;
               padding: 30px 30px;
               margin-top: 30px;
               margin-bottom: 15px;
               max-width: 1200px;
               animation: fadeInUp 1s;
            }
         
         
            </style>
   <footer>
      <div class="footer">
         <div class="container">
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <ul class="location_icon">
            <li style="margin-bottom:0;"><a href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/@-34.8851079,-56.1953592,17z/data=!3m1!4b1!4m6!3m5!1s0x959f8018248ae2ef:0x51dd959d2d332c67!8m2!3d-34.8851123!4d-56.1927843!16s%2Fg%2F1hd_ld504?entry=ttu&g_ep=EgoyMDI1MDkwNy4wIKXMDSoASAFQAw%3D%3D" target="_blank" rel="noopener noreferrer"><i class="fa fa-map-marker" aria-hidden="true"></i></a><span> Ubicación</span></li>
            <li style="margin-bottom:0;"><a href="#" target="_blank" rel="noopener noreferrer"><i class="fa fa-phone" aria-hidden="true"></i></a><span> +598 95 561 757</span></li>
            <li style="margin-bottom:0;"><a href="https://mail:codemass2025@gmail.com" target="_blank" rel="noopener noreferrer"><i class="fa fa-envelope" aria-hidden="true"></i></a><span> codemass2025@gmail.com</span></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="copyright">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <p>©2025 Design by CODEMASS</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </footer>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
