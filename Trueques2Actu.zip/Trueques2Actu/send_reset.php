<?php
require_once 'conexion.php';

// ---------- CAMBIO: configuración SMTP centralizada y debug controlable ----------
$smtpHost   = 'smtp.gmail.com';
$smtpPort   = 587;
$smtpUser   = 'codemass2025@gmail.com';    // <-- correo remitente (usa el email completo)
$smtpPass   = '';      // <-- REEMPLAZA por App Password (Gmail) o credenciales SMTP
$smtpSecure = 'tls';
$fromName   = 'CHANGEMASS';
$fromEmail  = $smtpUser;

// activar debug sólo si se pasa ?debug=1 (NO dejar en 1 en producción)
$enableDebug = isset($_GET['debug']) && $_GET['debug'] === '1';
// -------------------------------------------------------------------------------

// Validación básica del POST (ya estaba)
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['correo'])) {
    header('Location: forgot_password.php'); exit;
}

$correo = trim($_POST['correo']);

// Validar que sea un correo válido
if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    $msg = urlencode("Correo inválido.");
    header("Location: forgot_password.php?msg={$msg}");
    exit;
}

// Buscar usuario por correo (ahora traemos nombre para el cuerpo del mail)
$stmt = $conexion->prepare("SELECT id, nombre, apellido, correo FROM usuarios WHERE correo = ? LIMIT 1");
$stmt->bind_param("s", $correo);
$stmt->execute();
$stmt->bind_result($user_id, $user_nombre, $user_apellido, $user_email);
if (!$stmt->fetch()) {
    $stmt->close();
    // No revelar si existe o no
    $msg = urlencode("Si existe la cuenta, hemos enviado un código al correo registrado.");
    header("Location: forgot_password.php?msg={$msg}");
    exit;
}
$stmt->close();

// crear tabla si no existe (mantener)
$crear = "
CREATE TABLE IF NOT EXISTS password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  email VARCHAR(255) NOT NULL,
  token VARCHAR(10) NOT NULL,
  expires_at DATETIME NOT NULL,
  used TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
";
$conexion->query($crear);

// generar código de 6 dígitos
try {
    $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
} catch (Exception $e) {
    $code = sprintf('%06d', mt_rand(0, 999999));
}

$expires = date('Y-m-d H:i:s', time() + 15*60); // 15 minutos

$insert = $conexion->prepare("INSERT INTO password_resets (user_id, email, token, expires_at) VALUES (?, ?, ?, ?)");
$insert->bind_param("isss", $user_id, $user_email, $code, $expires);
if (!$insert->execute()) {
    $insert->close();
    $msg = urlencode("Error al generar el código. Intenta nuevamente.");
    header("Location: forgot_password.php?msg={$msg}");
    exit;
}
$reset_id = $insert->insert_id;
$insert->close();

// Preparar cuerpo del correo incluyendo nombre y correo registrado
$nombre_completo = trim($user_nombre . ' ' . $user_apellido);
$subject = "CHANGEMASS — Código para restablecer contraseña";
$body = "Hola {$nombre_completo},\n\n";
$body .= "Has solicitado restablecer la contraseña para la cuenta asociada a este correo: {$user_email}\n\n";
$body .= "Tu código de verificación es: {$code}\n\n";
$body .= "Este código será válido por 15 minutos.\n\n";
$body .= "Si usted no solicitó este restablecimiento o si no reconoce este usuario, ignore este correo.\n\n";
$body .= "Saludos,\nCHANGEMASS\n";

// Intentar enviar con PHPMailer si está disponible
$mailSent = false;
$mailErrorMsg = '';

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    // Verificar que la extensión OpenSSL esté habilitada: STARTTLS/SMTP sobre TLS requiere openssl
    if (!extension_loaded('openssl')) {
        $mailSent = false;
        $mailErrorMsg = "La extensión PHP OpenSSL no está habilitada. Habilítala en php.ini (descomenta 'extension=openssl'), reinicia Apache y vuelve a intentar.";
    } else {
        require __DIR__ . '/vendor/autoload.php';
        try {
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->SMTPAuth   = true;
            $mail->Host       = $smtpHost;
            $mail->Username   = $smtpUser;
            $mail->Password   = $smtpPass;
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = $smtpPort;
            $mail->CharSet    = 'UTF-8';

            // Capturar debug sólo si $enableDebug
            $mailErrorMsg = '';
            $mail->SMTPDebug = $enableDebug ? 2 : 0;
            if ($enableDebug) {
                $mail->Debugoutput = function($str, $level) use (&$mailErrorMsg) {
                    $mailErrorMsg .= "Debug[$level]: $str\n";
                };
            } else {
                $mail->Debugoutput = null;
            }

            // Remitente (empresa)
            $mail->setFrom($fromEmail, $fromName);
            $mail->addAddress($user_email, $nombre_completo);

            // construir enlace absoluto al reset (ya existente)
            $baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
            $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
            $link_reset = $baseUrl . $scriptDir . '/reset_password.php?rid=' . intval($reset_id);

            // HTML body (ya preparado en el archivo)
            $htmlBody = '<!doctype html><html><head><meta charset="utf-8"><title>Restablecer contraseña</title></head><body style="font-family:Arial,Helvetica,sans-serif;color:#222">';
            $htmlBody .= "<h2 style=\"color:#6366f1;\">CHANGEMASS — Restablecimiento de contraseña</h2>";
            $htmlBody .= "<p>Hola <strong>" . htmlspecialchars($nombre_completo) . "</strong>,</p>";
            $htmlBody .= "<p>Se solicitó restablecer la contraseña para la cuenta asociada a este correo: <strong>" . htmlspecialchars($user_email) . "</strong>.</p>";
            $htmlBody .= "<p><strong>Código de verificación:</strong> <span style=\"font-size:1.25em;background:#f3f4ff;padding:6px 10px;border-radius:6px;display:inline-block;\">" . htmlspecialchars($code) . "</span></p>";
            $htmlBody .= "<p>O puedes restablecer la contraseña haciendo clic en el siguiente enlace:</p>";
            $htmlBody .= "<p><a href=\"" . htmlspecialchars($link_reset) . "\" style=\"color:#4b3bbd;\">Restablecer mi contraseña</a></p>";
            $htmlBody .= "<p><small>Este código y enlace expiran en 15 minutos.</small></p>";
            $htmlBody .= "<hr><p style=\"color:#666;font-size:0.9rem;\">Si usted no solicitó este restablecimiento o si no reconoce este usuario, ignore este correo.</p>";
            $htmlBody .= "<p>Saludos,<br>CHANGEMASS</p>";
            $htmlBody .= "</body></html>";

            // Plain text alternative
            $altBody = "CHANGEMASS — Restablecimiento de contraseña\n\n";
            $altBody .= "Hola {$nombre_completo}\n\n";
            $altBody .= "Has solicitado restablecer la contraseña para: {$user_email}\n\n";
            $altBody .= "Código: {$code}\n\n";
            $altBody .= "Link: {$link_reset}\n\n";
            $altBody .= "Si usted no solicitó esto, ignore este correo.\n\nCHANGEMASS";

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = $altBody;

            // Opcional para entorno local (no verifiques certificados)
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                ]
            ];

            $mail->send();
            $mailSent = true;
        } catch (\PHPMailer\PHPMailer\Exception $e) {
            // incluir mensaje de excepción + debug (si hubo)
            $mailErrorMsg = trim(($mailErrorMsg ? $mailErrorMsg . "\n" : '') . $e->getMessage());
            // si el error indica autenticación, añadir pista rápida sobre App Password / 2FA
            if (stripos($mailErrorMsg, 'authentication') !== false || stripos($mailErrorMsg, 'auth') !== false) {
                $mailErrorMsg .= "\nSugerencia: asegúrate de usar el email completo como usuario (ej. codemass2025@gmail.com) y una App Password si usas Gmail con 2FA. Verifica además que OpenSSL esté habilitado en PHP.";
            }
            $mailSent = false;

            // --- NUEVO: registrar debug en fichero para diagnóstico (no exponer al usuario) ---
            try {
                $logDir = __DIR__ . '/logs';
                if (!is_dir($logDir)) mkdir($logDir, 0755, true);
                $logFile = $logDir . '/mail_debug.log';
                $entry = "[" . date('Y-m-d H:i:s') . "] send_reset.php - rid={$reset_id} to={$user_email}\n" . $mailErrorMsg . "\n\n";
                @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
            } catch (Throwable $logErr) {
                // silencioso: no interrumpir el flujo por fallo en logging
            }
            // --- fin nuevo ---
        }
    }
} else {
    $mailSent = false;
    $mailErrorMsg = 'PHPMailer no está instalado. Ejecuta en la carpeta del proyecto: composer require phpmailer/phpmailer';
}

// NUEVO: validar que las credenciales SMTP estén configuradas (evitar intentar auth con placeholders)
if (empty($smtpUser) || !filter_var($smtpUser, FILTER_VALIDATE_EMAIL) || empty($smtpPass) || strpos($smtpPass, 'TU_APP_PASSWORD') !== false) {
    // mensaje corto y accionable (se guarda en $mailErrorMsg y redirige como antes)
    $mailSent = false;
    $mailErrorMsg = "Credenciales SMTP no configuradas. Configura \$smtpUser como el correo remitente (ej. codemass2025@gmail.com) y \$smtpPass con una App Password (Gmail) o credenciales SMTP válidas. Para Gmail: activa 2FA y crea una App Password en https://myaccount.google.com/apppasswords. También habilita OpenSSL en php.ini y reinicia Apache.";
    // registrar en log por diagnóstico (silencioso)
    try {
        $logDir = __DIR__ . '/logs';
        if (!is_dir($logDir)) mkdir($logDir, 0755, true);
        $logFile = $logDir . '/mail_debug.log';
        $entry = "[" . date('Y-m-d H:i:s') . "] send_reset.php - ABORT smtp credentials missing. user={$smtpUser}\n" . $mailErrorMsg . "\n\n";
        @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
    } catch (Throwable $logErr) { /* silent */ }

    $redirect = "reset_password.php?rid=" . intval($reset_id) . "&correo=" . urlencode($user_email);
    $short = substr($mailErrorMsg, 0, 380);
    $redirect .= '&mailerror=1&msg=' . urlencode("No se pudo enviar el correo. Detalle: {$short}");
    header("Location: {$redirect}");
    exit;
}

// redirigir indicando detalle de error (truncar por seguridad si hace falta)
$redirect = "reset_password.php?rid=" . intval($reset_id) . "&correo=" . urlencode($user_email);
if ($mailSent) {
    $redirect .= '&sent=1';
} else {
    $short = substr($mailErrorMsg, 0, 380);
    $redirect .= '&mailerror=1&msg=' . urlencode("No se pudo enviar el correo. Detalle: {$short}");
}
header("Location: {$redirect}");
exit;
?>
