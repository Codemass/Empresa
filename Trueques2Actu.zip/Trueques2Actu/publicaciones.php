<?php
require_once 'conexion.php';

session_start();
$is_admin = false;
if (isset($_SESSION['correo']) && $_SESSION['correo'] === 'codemass2025@gmail.com') {
    $is_admin = true;
}

// manejar mensajes flash de eliminación
$mensaje_eliminado = '';
if (isset($_GET['deleted']) && $_GET['deleted'] == '1') {
    $mensaje_eliminado = 'Publicación eliminada correctamente.';
} elseif (isset($_GET['error'])) {
    $mensaje_eliminado = 'Error: ' . htmlspecialchars($_GET['error']);
}

// Obtener categoría seleccionada
$categoria_filtro = isset($_GET['categoria']) ? $_GET['categoria'] : '';

// Construir query según filtro
if ($categoria_filtro) {
    $query = "SELECT * FROM publicaciones WHERE categoria = ? ORDER BY fecha_creacion DESC";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("s", $categoria_filtro);
    $stmt->execute();
    $resultado = $stmt->get_result();
} else {
    $query = "SELECT * FROM publicaciones ORDER BY fecha_creacion DESC";
    $resultado = $conexion->query($query);
}
?>
<!DOCTYPE html>
<html lang="en">
   <script>
  function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const sidebarCol = document.querySelector('.sidebar-col');
    const contentCol = document.querySelector('.content-col');
    
    sidebar.classList.toggle('hidden');
    sidebarCol.classList.toggle('hidden');
    contentCol.classList.toggle('full-width');
  }
</script>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>CHANGEMASS</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout position_head">
     
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item">
                                 <a class="nav-link" href="index.html">Inicio</a>
                              </li>
                              <li class="nav-item active">
                                 <a class="nav-link" href="publicaciones.php">Publicaciones</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="publicar.html">Publicar</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="contactanos.html">Contactanos</a>
                              </li>
                              <li class="nav-item dropdown">
                                 <a class="nav-link dropdown-toggle" href="#" id="categoriasDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    ☰ Categorías
                                 </a>
                                 <div class="dropdown-menu" aria-labelledby="categoriasDropdown">
                                    <a class="dropdown-item" href="publicaciones.php">Todas</a>
                                    <a class="dropdown-item" href="publicaciones.php?categoria=Ropa">Ropa</a>
                                    <a class="dropdown-item" href="publicaciones.php?categoria=Muebles">Muebles</a>
                                    <a class="dropdown-item" href="publicaciones.php?categoria=Electrodomésticos">Electrodomésticos</a>
                                    <a class="dropdown-item" href="publicaciones.php?categoria=Tecnología">Tecnología</a>
                                    <a class="dropdown-item" href="publicaciones.php?categoria=Deportes">Deportes</a>
                                    <a class="dropdown-item" href="publicaciones.php?categoria=Juguetes">Juguetes</a>
                                 </div>
                              </li>
                              <?php if ($is_admin): // --- CHANGED: admin nav items --- ?>
                              <li class="nav-item">
                                 <a class="nav-link" href="admin_panel.php" style="font-weight:700;color:#ffd700;"><i class="fa fa-shield" aria-hidden="true"></i> Admin</a>
                              </li>
                              <?php endif; ?>
                              <li class="nav-item d_none login_btn">
                                 <a class="nav-link" href="ajustes.html">
                                    <i class="fa-solid fa-gear" style="margin-right:6px;"></i> ajustes</a>
                              </li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <link rel="stylesheet" href="css/style.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
         <style>
            body {
               background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%);
               font-family: 'Poppins', sans-serif;
            }
            .titlepage h2 {
               color: #7c5fe9;
               font-size: 2.5rem;
               font-weight: 700;
               letter-spacing: 1px;
               text-shadow: 0 2px 8px rgba(99,102,241,0.10);
               margin-bottom: 32px;
            }
            .glasses_box {
             background: #fff;
             border-radius: 25px;
             box-shadow: 0 4px 24px 0 rgba(99,102,241,0.10);
             padding: 24px 16px;
             margin-bottom: 32px;
             transition: box-shadow 0.3s, transform 0.2s;
             text-align: center;
            }
            
            .category-link {
               display: block;
               text-decoration: none;
               color: inherit;
               cursor: pointer;
            }
            .category-link:focus, .category-link:hover {
               text-decoration: none;
            }
            .glasses_box:hover {
               box-shadow: 0 8px 32px 0 #7c5fe9;
               transform: translateY(-6px) scale(1.05);
            }
            .glasses_box figure img {
               width: 200px;
               height: 200px;
               object-fit: cover;
               margin-bottom: 16px;
               border-radius: 20px;
               box-shadow: 0 2px 8px #6366f114;
            }
            .glasses_box p {
               color: #6366f1;
               font-size: 1.1rem;
               font-weight: 500;
               margin-top: 8px;
            }
            .sidebar {
               background: #fff;
               border-radius: 16px;
               box-shadow: 0 2px 12px rgba(99,102,241,0.10);
               padding: 24px 18px;
               margin-bottom: 32px;
            }
            .sidebar h2 {
               color: #7c5fe9;
               font-size: 1.3rem;
               font-weight: 600;
               margin-bottom: 16px;
            }
            .sidebar ul {
               list-style: none;
               padding: 0;
            }
            .sidebar ul li {
               color: #6366f1;
               font-size: 1rem;
               padding: 6px 0;
               border-bottom: 1px solid #e3e0f7;
               transition: color 0.2s;
               cursor: pointer;
            }
            .sidebar ul li:last-child {
               border-bottom: none;
            }
            .sidebar ul li:hover {
               color: #7c5fe9;
            }
         </style>
      <!-- end header inner -->
      <!-- end header -->
      <!-- Our  Glasses section -->
      <div class="glasses">
         <div class="">
               <div class="row">
                  <div class="col-md-10 offset-md-1">
                     <div class="titlepage" style="background:#b6b3e6;border-radius:18px;">
                        <h2>Publicaciones</h2>
                     </div>
                  </div>
               </div>
         </div>
         <div class="container-fluid">
                   <div class="sidebar hidden">
   <div class="sidebar" style="background:#b6b3e6;border-radius:16px;box-shadow:0 2px 12px #6366f11a;padding:24px 18px;margin-bottom:32px;">
         <h2>Categorías</h2>
         <ul>
            <li><a href="publicaciones.php" style="color:#6366f1;text-decoration:none;">Todas</a></li>
            <li><a href="publicaciones.php?categoria=Ropa" style="color:#6366f1;text-decoration:none;">Ropa</a></li>
            <li><a href="publicaciones.php?categoria=Muebles" style="color:#6366f1;text-decoration:none;">Muebles</a></li>
            <li><a href="publicaciones.php?categoria=Electrodomésticos" style="color:#6366f1;text-decoration:none;">Electrodomésticos</a></li>
            <li><a href="publicaciones.php?categoria=Tecnología" style="color:#6366f1;text-decoration:none;">Tecnología</a></li>
            <li><a href="publicaciones.php?categoria=Deportes" style="color:#6366f1;text-decoration:none;">Deportes</a></li>
            <li><a href="publicaciones.php?categoria=Juguetes" style="color:#6366f1;text-decoration:none;">Juguetes</a></li>
         </ul>
      </div>
   </div>
            <div class="row">
            <?php
            if ($resultado && $resultado->num_rows > 0) {
               while($row = $resultado->fetch_assoc()) {
            ?>
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                  <a href="publicacion.php?id=<?php echo $row['id']; ?>" class="glasses_box category-link">
                     <figure>
                        <img src="<?php echo htmlspecialchars($row['imagen']); ?>" 
                             alt="<?php echo htmlspecialchars($row['categoria']); ?>"/>
                     </figure>
                     <h3><span class="blu"></span></h3>
                     <p><?php echo htmlspecialchars($row['categoria']); ?></p>
                  </a>
                  <?php if ($is_admin): ?>
                  <div style="margin-top:8px;display:flex;gap:8px;justify-content:center;">
                     <!-- EDIT removed -->
                     <button type="button" class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $row['id']; ?>" data-title="<?php echo htmlspecialchars($row['categoria'], ENT_QUOTES); ?>">Eliminar</button>
                  </div>
                  <?php endif; ?>
               </div>
            <?php
               }
            } else {
            ?>
                  <div class="col-12 text-center">
                     <div class="glasses_box">
                        <p><?php echo $categoria_filtro ? "No hay publicaciones en esta categoría" : "No hay publicaciones disponibles"; ?></p>
                     </div>
                  </div>
            <?php } ?>
               <div class="col-md-12">
                  <a class="read_more" href="#">Ver mas</a>
               </div>
            </div>
         </div>
      </div>
      <!-- modal: eliminar publicación con motivo -->
<div id="deleteModal" class="modal-overlay hidden" aria-hidden="true">
  <div class="modal-box">
    <h5>Eliminar publicación</h5>
    <p id="modalInfo" style="margin-bottom:8px;color:#333;"></p>
    <form id="deleteForm" action="eliminar_publicacion.php" method="POST">
      <input type="hidden" name="id" id="deleteId" value="">
      <div style="margin-bottom:8px;">
        <label for="motivo">Motivo de eliminación (opcional)</label>
        <textarea id="motivo" name="motivo" rows="4" style="width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;"></textarea>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;">
        <button type="button" id="cancelDelete" class="btn btn-secondary">Cancelar</button>
        <button type="submit" class="btn btn-danger">Confirmar eliminación</button>
      </div>
    </form>
  </div>
</div>

<style>
/* modal simple */
.modal-overlay.hidden { display: none; }
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display:flex;
  align-items:center;
  justify-content:center;
  z-index: 2000;
}
.modal-box {
  background:#fff;
  padding:18px;
  border-radius:10px;
  width: 90%;
  max-width:480px;
  box-shadow: 0 6px 30px rgba(0,0,0,0.3);
}
</style>

<script>
// abrir modal al clickear eliminar
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.delete-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var id = this.getAttribute('data-id');
      var title = this.getAttribute('data-title') || 'Publicación';
      document.getElementById('deleteId').value = id;
      document.getElementById('modalInfo').textContent = 'Vas a eliminar: ' + title + '. Indica el motivo si lo deseas.';
      document.getElementById('deleteModal').classList.remove('hidden');
      document.getElementById('deleteModal').setAttribute('aria-hidden','false');
    });
  });
  document.getElementById('cancelDelete').addEventListener('click', function(){
    document.getElementById('deleteModal').classList.add('hidden');
    document.getElementById('deleteModal').setAttribute('aria-hidden','true');
    document.getElementById('motivo').value = '';
    document.getElementById('deleteId').value = '';
  });
  // cerrar modal si clic fuera de box
  document.getElementById('deleteModal').addEventListener('click', function(e){
    if (e.target === this) {
      document.getElementById('cancelDelete').click();
    }
  });
});
</script>
      <link rel="stylesheet" href="css/style.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
         <style>.footer .location_icon li {
               display: inline-flex;
               align-items: center;
               gap: 8px;
               color: #7c5fe9 !important;
               list-style: none;
               font-size: 1rem;
               justify-content: center;
               text-align: left;
            }
              .footer .location_icon i {
               color: #7c5fe9 !important;
            }
             body {
               background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%);
               min-height: 100vh;
            }
            .container {
               background: #fff;
               border-radius: 20px;
               box-shadow: 0 8px 32px 0 rgba(99, 102, 241, 0.10);
               padding: 30px 30px;
               margin-top: 15px;
               margin-bottom: 15px;
               max-width: 900px;
               animation: fadeInUp 1s;
            }
            </style>
      <!-- end Our  Glasses section -->
      <!--  footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/@-34.8851079,-56.1953592,17z/data=!3m1!4b1!4m6!3m5!1s0x959f8018248ae2ef:0x51dd959d2d332c67!8m2!3d-34.8851123!4d-56.1927843!16s%2Fg%2F1hd_ld504?entry=ttu&g_ep=EgoyMDI1MDkwNy4wIKXMDSoASAFQAw%3D%3D"><i class="fa fa-map-marker" aria-hidden="true"></i></a><span>Ubicación</span></li>
                        <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a><span>+598 95 764 982</span></li>
                        <li><a href="https://mail.google.com/mail/u/1/#sent?compose=CllgCJTGmpJrsBmqKPHhfSRxBZgLMTJvsdBdNdTCfVrZJxjnNFDMcXZMrFTRRgJFgjLfBrCXQjV"><i class="fa fa-envelope" aria-hidden="true"></i></a><span>codemass2025@gmail.com</span></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>