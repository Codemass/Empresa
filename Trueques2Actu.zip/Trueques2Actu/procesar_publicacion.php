<?php
require_once 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $categoria = $_POST['categoria'];
    $descripcion = $_POST['descripcion'];
    
    // Procesar la imagen
    $imagen_nombre = $_FILES['imagen']['name'];
    $imagen_temporal = $_FILES['imagen']['tmp_name'];
    $carpeta_destino = 'uploads/';
    
    // Crear directorio si no existe
    if (!file_exists($carpeta_destino)) {
        mkdir($carpeta_destino, 0777, true);
    }
    
    // Generar nombre único para la imagen
    $extension = pathinfo($imagen_nombre, PATHINFO_EXTENSION);
    $nombre_unico = uniqid() . '.' . $extension;
    $ruta_imagen = $carpeta_destino . $nombre_unico;
    
    if (move_uploaded_file($imagen_temporal, $ruta_imagen)) {
        // Insertar en la base de datos
        $query = "INSERT INTO publicaciones (categoria, descripcion, imagen, fecha_creacion) 
                 VALUES (?, ?, ?, NOW())";
        
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("sss", $categoria, $descripcion, $ruta_imagen);
        
        if ($stmt->execute()) {
            header("Location: publicaciones.php?success=1");
            exit();
        } else {
            echo "Error al guardar en la base de datos: " . $conexion->error;
        }
    } else {
        echo "Error al subir la imagen";
    }
}
?>
