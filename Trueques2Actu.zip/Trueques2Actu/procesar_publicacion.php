<?php
require_once 'conexion.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Leer campos (con fallback por si vienen con nombres diferentes)
    $titulo = isset($_POST['titulo']) ? trim($_POST['titulo']) : '';
    $categoria = isset($_POST['categoria']) ? trim($_POST['categoria']) : '';
    // algunos formularios pueden usar 'descripcion' o 'descripcion_publicacion'
    $descripcion = '';
    if (isset($_POST['descripcion'])) $descripcion = trim($_POST['descripcion']);
    elseif (isset($_POST['descripcion_publicacion'])) $descripcion = trim($_POST['descripcion_publicacion']);

    // Si falta título pero hay descripción, usar un extracto como título
    if ($titulo === '' && $descripcion !== '') {
        $titulo = mb_substr($descripcion, 0, 60);
    }

    // Categoría por defecto
    if ($categoria === '') {
        $categoria = 'General';
    }

    // Si no hay título ni descripción, redirigir con error
    if ($titulo === '' && $descripcion === '') {
        $_SESSION['pub_error'] = "Faltan campos obligatorios (título o descripción).";
        // preservar lo que haya enviado el usuario para rellenar el formulario (opcional)
        $_SESSION['pub_preserve'] = [
            'titulo' => $titulo,
            'categoria' => $categoria,
            'descripcion' => $descripcion
        ];
        header("Location: publicar.php");
        exit;
    }

    // Obtener id_usuario desde sesión (si existe) o por CI
    $user_id = null;
    if (isset($_SESSION['user_id'])) {
        $user_id = intval($_SESSION['user_id']);
    } elseif (isset($_SESSION['ci'])) {
        $ci = $_SESSION['ci'];
        $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
        if ($stmtu) {
            $stmtu->bind_param("s", $ci);
            $stmtu->execute();
            $stmtu->bind_result($uid);
            if ($stmtu->fetch()) $user_id = intval($uid);
            $stmtu->close();
        }
    }
    if ($user_id === null) {
        $_SESSION['pub_error'] = "No se ha podido identificar al usuario. Inicia sesión.";
        header("Location: publicar.php");
        exit;
    }

    // Procesar la imagen (opcional)
    $ruta_imagen = '';
    if (isset($_FILES['imagen']) && isset($_FILES['imagen']['tmp_name']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $imagen_nombre = $_FILES['imagen']['name'];
        $imagen_temporal = $_FILES['imagen']['tmp_name'];
        $carpeta_destino = 'uploads/';

        if (!file_exists($carpeta_destino)) {
            mkdir($carpeta_destino, 0777, true);
        }

        $extension = pathinfo($imagen_nombre, PATHINFO_EXTENSION);
        $extension = strtolower($extension);
        $allowed = ['jpg','jpeg','png','webp'];
        if (!in_array($extension, $allowed)) {
            $_SESSION['pub_error'] = "Tipo de imagen no permitido.";
            header("Location: publicar.php");
            exit;
        }

        $nombre_unico = uniqid('pub_') . '.' . $extension;
        $ruta_imagen = $carpeta_destino . $nombre_unico;

        if (!move_uploaded_file($imagen_temporal, $ruta_imagen)) {
            $_SESSION['pub_error'] = "Error al subir la imagen.";
            header("Location: publicar.html");
            exit;
        }
    }

    // Insertar en la base de datos incluyendo titulo e id_usuario
    $query = "INSERT INTO publicaciones (titulo, categoria, descripcion, imagen, id_usuario, fecha_creacion) 
             VALUES (?, ?, ?, ?, ?, NOW())";

    $stmt = $conexion->prepare($query);
    if (!$stmt) {
        $_SESSION['pub_error'] = "Error en la preparación de la consulta: " . $conexion->error;
        header("Location: publicar.php");
        exit;
    }

    // usar cadena vacía si no hay imagen
    $img_param = $ruta_imagen !== '' ? $ruta_imagen : '';

    $stmt->bind_param("ssssi", $titulo, $categoria, $descripcion, $img_param, $user_id);

    if ($stmt->execute()) {
        $stmt->close();
        // limpiar posibles mensajes/valores preservados
        unset($_SESSION['pub_error'], $_SESSION['pub_preserve']);
        header("Location: publicaciones.php?success=1");
        exit();
    } else {
        $_SESSION['pub_error'] = "Error al guardar en la base de datos: " . $stmt->error;
        $stmt->close();
        header("Location: publicar.html");
        exit;
    }
}
// Si se accede sin POST, redirigir al formulario
header("Location: publicar.php");
exit;
?>
