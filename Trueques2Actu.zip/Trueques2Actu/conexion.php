<?php
	$conexion = new mysqli('localhost', 'root', '', 'proyecto');
	if ($conexion->connect_errno) {
		echo "Lo sentimos, este sitio web está experimentando problemas.";
		exit;
	}
	
	// Crear tabla administradores si no existe
	$sql = "CREATE TABLE IF NOT EXISTS administradores (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL
	)";
	$conexion->query($sql);
	
	// Verificar si el admin ya existe
	$stmt = $conexion->prepare("SELECT id FROM administradores WHERE ci = ?");
	$ci = "51946920";
	$stmt->bind_param("s", $ci);
	$stmt->execute();
	$stmt->store_result();
	
	// Si no existe, crear el admin por defecto
	if ($stmt->num_rows == 0) {
	    $stmt->close();
	    $stmt = $conexion->prepare("INSERT INTO administradores (ci, nombre, apellido, correo, fecha_nacimiento, contrasena) VALUES (?, ?, ?, ?, ?, ?)");
	    $ci = "51946920";
	    $nombre = "El";
	    $apellido = "Admin";
	    $correo = "codemass2025@gmail.com";
	    $fecha_nacimiento = "2025-11-13";
	    $contrasena = password_hash("A13M11S07S09cm", PASSWORD_DEFAULT);
	    $stmt->bind_param("ssssss", $ci, $nombre, $apellido, $correo, $fecha_nacimiento, $contrasena);
	    $stmt->execute();
	}
	
	// Crear tabla usuarios si no existe
	$sql = "CREATE TABLE IF NOT EXISTS usuarios (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL,
	    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
	)";

	$conexion->query($sql);

	// --- Nuevo: asegurar que la columna 'avatar' exista ---
	$res = $conexion->query("SHOW COLUMNS FROM `usuarios` LIKE 'avatar'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `usuarios` ADD COLUMN `avatar` VARCHAR(255) DEFAULT NULL");
	}
	// --- fin cambio ---

	// Crear tabla publicaciones si no existe
	$sql = "CREATE TABLE IF NOT EXISTS publicaciones (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    titulo VARCHAR(255) NOT NULL,
	    descripcion TEXT NOT NULL,
	    id_usuario INT,
	    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
	)";
	$conexion->query($sql);
	
?>