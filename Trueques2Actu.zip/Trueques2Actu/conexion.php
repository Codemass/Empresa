<?php
	$conexion = new mysqli('localhost', 'root', '', 'proyecto');
	if ($conexion->connect_errno) {
		echo "Lo sentimos, este sitio web está experimentando problemas.";
		exit;
	}
	
	// Crear tabla administradores si no existe
	$sql = "CREATE TABLE IF NOT EXISTS administradores (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL
	)";
	$conexion->query($sql);
	
	// Verificar si el admin ya existe
	$stmt = $conexion->prepare("SELECT id FROM administradores WHERE ci = ?");
	$ci = "51946920";
	$stmt->bind_param("s", $ci);
	$stmt->execute();
	$stmt->store_result();
	
	// Si no existe, crear el admin por defecto
	if ($stmt->num_rows == 0) {
	    $stmt->close();
	    $stmt = $conexion->prepare("INSERT INTO administradores (ci, nombre, apellido, correo, fecha_nacimiento, contrasena) VALUES (?, ?, ?, ?, ?, ?)");
	    $ci = "51946920";
	    $nombre = "El";
	    $apellido = "Admin";
	    $correo = "codemass2025@gmail.com";
	    $fecha_nacimiento = "2025-11-13";
	    $contrasena = password_hash("A13M11S07S09cm", PASSWORD_DEFAULT);
	    $stmt->bind_param("ssssss", $ci, $nombre, $apellido, $correo, $fecha_nacimiento, $contrasena);
	    $stmt->execute();
	}
	
?>