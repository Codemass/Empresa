<?php
	$conexion = new mysqli('localhost', 'root', '', 'proyecto');
	if ($conexion->connect_errno) {
		echo "Lo sentimos, este sitio web está experimentando problemas.";
		exit;
	}
	
	// Crear tabla administradores si no existe
	$sql = "CREATE TABLE IF NOT EXISTS administradores (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL
	)";
	$conexion->query($sql);
	
	// Verificar si el admin ya existe
	$stmt = $conexion->prepare("SELECT id FROM administradores WHERE ci = ?");
	$ci = "51946920";
	$stmt->bind_param("s", $ci);
	$stmt->execute();
	$stmt->store_result();
	
	// Si no existe, crear el admin por defecto
	if ($stmt->num_rows == 0) {
	    $stmt->close();
	    $stmt = $conexion->prepare("INSERT INTO administradores (ci, nombre, apellido, correo, fecha_nacimiento, contrasena) VALUES (?, ?, ?, ?, ?, ?)");
	    $ci = "51946920";
	    $nombre = "El";
	    $apellido = "Admin";
	    $correo = "codemass2025@gmail.com";
	    $fecha_nacimiento = "2025-11-13";
	    $contrasena = password_hash("A13M11S07S09cm", PASSWORD_DEFAULT);
	    $stmt->bind_param("ssssss", $ci, $nombre, $apellido, $correo, $fecha_nacimiento, $contrasena);
	    $stmt->execute();
	}
	
	// Crear tabla usuarios si no existe
	$sql = "CREATE TABLE IF NOT EXISTS usuarios (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL,
	    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
	)";

	$conexion->query($sql);

	// --- Nuevo: asegurar que la columna 'avatar' exista ---
	$res = $conexion->query("SHOW COLUMNS FROM `usuarios` LIKE 'avatar'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `usuarios` ADD COLUMN `avatar` VARCHAR(255) DEFAULT NULL");
	}
	// --- fin cambio ---

	// Crear tabla publicaciones si no existe
	$sql = "CREATE TABLE IF NOT EXISTS publicaciones (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    titulo VARCHAR(255) NOT NULL,
	    descripcion TEXT NOT NULL,
	    id_usuario INT,
	    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
	)";
	$conexion->query($sql);

	// Asegurar que la columna 'activo' exista para poder "ocultar" publicaciones en vez de borrarlas
	$res_pub_col = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'activo'");
	if ($res_pub_col && $res_pub_col->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `activo` TINYINT(1) NOT NULL DEFAULT 1");
	}
	
	// Crear tabla solicitudes_trueque
	$sql = "CREATE TABLE IF NOT EXISTS solicitudes_trueque (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_publicacion INT NOT NULL,
	    id_usuario_solicitante INT NOT NULL,
	    id_usuario_dueno INT NOT NULL,
	    estado VARCHAR(20) DEFAULT 'pendiente',
	    fecha_solicitud DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_solicitante) REFERENCES usuarios(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_dueno) REFERENCES usuarios(id) ON DELETE CASCADE
	)";
	$conexion->query($sql);
	
	// Si la columna id_publicacion_ofrecida no existe (por compatibilidad), agregarla
	$res_col = $conexion->query("SHOW COLUMNS FROM `solicitudes_trueque` LIKE 'id_publicacion_ofrecida'");
	if ($res_col && $res_col->num_rows === 0) {
	    $conexion->query("ALTER TABLE `solicitudes_trueque` ADD COLUMN `id_publicacion_ofrecida` INT NULL AFTER `fecha_solicitud`");
	    // opción: agregar FK si deseado (silencioso si falla)
	    @$conexion->query("ALTER TABLE `solicitudes_trueque` ADD CONSTRAINT fk_ofrecida_pub FOREIGN KEY (id_publicacion_ofrecida) REFERENCES publicaciones(id) ON DELETE SET NULL");
	}
	
	// Crear tabla chats
	$sql = "CREATE TABLE IF NOT EXISTS chats (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_solicitud INT NOT NULL UNIQUE,
	    id_usuario_1 INT NOT NULL,
	    id_usuario_2 INT NOT NULL,
	    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_solicitud) REFERENCES solicitudes_trueque(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_1) REFERENCES usuarios(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_2) REFERENCES usuarios(id) ON DELETE CASCADE
	)";
	$conexion->query($sql);

	// Crear tabla mensajes_chat
	$sql = "CREATE TABLE IF NOT EXISTS mensajes_chat (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_chat INT NOT NULL,
	    id_usuario INT NOT NULL,
	    mensaje TEXT NOT NULL,
	    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_chat) REFERENCES chats(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
	)";
	$conexion->query($sql);

	// Crear tabla sanciones
	$sql = "CREATE TABLE IF NOT EXISTS sanciones (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_usuario INT NOT NULL,
	    motivo TEXT NOT NULL,
	    fecha_sancion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    tipo VARCHAR(50) NOT NULL,
	    activa TINYINT(1) DEFAULT 1,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
	)";
	$conexion->query($sql);

	// --- Nuevo: tabla para mensajes de contacto enviados por usuarios ---
	$sql = "CREATE TABLE IF NOT EXISTS contact_messages (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_usuario INT NULL,
	    nombre VARCHAR(150) NULL,
	    correo VARCHAR(255) NULL,
	    telefono VARCHAR(50) NULL,
	    mensaje TEXT NOT NULL,
	    estado VARCHAR(20) NOT NULL DEFAULT 'pendiente',
	    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE SET NULL
	)";
	$conexion->query($sql);
	// --- fin cambio ---

	// --- Nuevo: tabla para respuestas del admin a mensajes de contacto ---
	$sql = "CREATE TABLE IF NOT EXISTS admin_replies (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    contact_id INT NOT NULL,
	    id_admin INT NULL,
	    mensaje TEXT NOT NULL,
	    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (contact_id) REFERENCES contact_messages(id) ON DELETE CASCADE
	)";
	$conexion->query($sql);
	// --- fin cambio ---

	// --- NUEVO: tabla notificaciones (avisos internos) ---
	$conexion->query("CREATE TABLE IF NOT EXISTS notificaciones (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    user_id INT NOT NULL,
	    tipo VARCHAR(50) NOT NULL,
	    referencia_id INT NULL,
	    mensaje VARCHAR(255) NOT NULL,
	    leida TINYINT(1) DEFAULT 0,
	    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (user_id) REFERENCES usuarios(id) ON DELETE CASCADE
	)");
	// --- fin nuevo ---
?>