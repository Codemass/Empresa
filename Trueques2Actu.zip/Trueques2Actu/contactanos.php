<?php
require_once 'conexion.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>CHANGEMASS</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout position_head">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item ">
                                 <a class="nav-link" href="index.html">Inicio</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="publicaciones.php">Publicaciones</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="publicar.html">Publicar</a>
                              </li>
                              <li class="nav-item active">
                                 <a class="nav-link" href="contactanos.php">Contactanos</a>
                              </li>
                              <li class="nav-item"><a class="nav-link" href="mis_solicitudes.php">Mis Solicitudes</a></li>
                  <li class="nav-item"><a class="nav-link" href="mis_chats.php">Mis Chats</a></li>
                  
                              <li class="nav-item d_none login_btn">
                                 <a class="nav-link" href="ajustes.html">
                                    <i class="fa-solid fa-gear" style="margin-right:6px;"></i> ajustes</a>
                              </li>
                              <?php 
                              // Obtener user_id y contar mensajes con respuestas nuevas
                              $user_id = null;
                              $new_messages_count = 0;
                              if (isset($_SESSION['user_id'])) {
                                  $user_id = intval($_SESSION['user_id']);
                              } elseif (isset($_SESSION['ci'])) {
                                  $ci = $_SESSION['ci'];
                                  $stm = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
                                  if ($stm) {
                                    $stm->bind_param("s", $ci);
                                    $stm->execute();
                                    $stm->bind_result($uidtmp);
                                    if ($stm->fetch()) $user_id = intval($uidtmp);
                                    $stm->close();
                                  }
                              }
                              
                              // Contar mensajes respondidos (estado = 'respondido')
                              if ($user_id) {
                                  $stmt_count = $conexion->prepare("SELECT COUNT(*) as total FROM contact_messages WHERE id_usuario = ? AND estado = 'respondido'");
                                  if ($stmt_count) {
                                    $stmt_count->bind_param("i", $user_id);
                                    $stmt_count->execute();
                                    $stmt_count->bind_result($new_messages_count);
                                    $stmt_count->fetch();
                                    $stmt_count->close();
                                  }
                              }
                              ?>
                              <?php if (isset($_SESSION['user_id']) || isset($_SESSION['ci'])): ?>
                              <li class="nav-item">
                                <button id="openMessagesBtn" style="background:none;border:none;color:#7c5fe9;padding:10px;cursor:pointer;font-size:0.9rem;margin-left:10px;font-weight:600;position:relative;">
                           <button id="openMessagesBtn" type="button" onclick="openMessages()" style="background:none;border:none;color:#7c5fe9;padding:10px;cursor:pointer;font-size:0.9rem;margin-left:10px;font-weight:600;position:relative;">
                                   <i class="fa fa-envelope" style="margin-right:6px;"></i>Mis mensajes
                                   <?php if ($new_messages_count > 0): ?>
                                  <span id="messagesBadge" style="position:absolute;top:-5px;right:0px;background:#dc3545;color:#fff;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:700;"><?php echo intval($new_messages_count); ?></span>
                                  <span id="messagesBadge" style="position:absolute;top:-5px;right:0px;background:#dc3545;color:#fff;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:700;"><?php echo intval($new_messages_count); ?></span>
                                   <?php endif; ?>
                                 </button>
                              </li>
                              <?php endif; ?>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
       <link rel="stylesheet" href="css/style.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
         <style> 
            .container {
               background: #fff;
               border-radius: 25px;
               box-shadow: 0 4px 24px 0 #6366f11a;
               margin: 40px auto;
               padding: 32px 32px;
            }
            
            .glasses_box {
             background: #fff;
             border-radius: 25px;
               box-shadow: 0 4px 24px 0 #6366f11a;
               padding: 24px 16px;
               margin-bottom: 32px;
               transition: box-shadow 0.3s, transform 0.2s;
               text-align: center;
            }
            .glasses_box:hover {
               box-shadow: 0 8px 32px 0 #7c5fe9;
               transform: translateY(-6px) scale(1.05);
            }
            .glasses_box figure img {
               width: 100px;
               height: 100px;
               object-fit: contain;
               margin-bottom: 16px;
               border-radius: 20px;
               box-shadow: 0 2px 8px #6366f114;
            }
            .glasses_box p {
               color: #6366f1;
               font-size: 1.1rem;
               font-weight: 500;
               margin-top: 8px;
            }
            .sidebar {
               background: #fff;
               border-radius: 16px;
               box-shadow: 0 2px 12px rgba(99,102,241,0.10);
               padding: 24px 18px;
               margin-bottom: 32px;
            }
            .sidebar h2 {
               color: #7c5fe9;
               font-size: 1.3rem;
               font-weight: 600;
               margin-bottom: 16px;
            }
            .sidebar ul {
               list-style: none;
               padding: 0;
            }
            .sidebar ul li {
               color: #6366f1;
               font-size: 1rem;
               padding: 6px 0;
               border-bottom: 1px solid #e3e0f7;
               transition: color 0.2s;
               cursor: pointer;
            }
            .sidebar ul li:last-child {
               border-bottom: none;
            }
            .sidebar ul li:hover {
               color: #7c5fe9;
            }

         </style>
      <!-- end header inner -->
      <!-- end header -->
      <!-- contact section -->
      <div id="contact" class="contact">
         <div class="">
            <div class="row">
               <div class="col-md-6">
                  <form id="request" class="main_form" action="procesar_contacto.php" method="POST">
                     <div class="row">
                        <div class="col-md-12 ">
                           <h3>Contactanos</h3>
                        </div>
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="Nombre" type="text" name="nombre" required> 
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Numero de telefono" type="tel" name="telefono">
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Correo" type="email" name="correo" required>                          
                        </div>
                        <div class="col-md-12">
                           <textarea class="contactusmess" placeholder="Mensaje" name="mensaje" required style="width:100%;height:120px;padding:10px;border-radius:8px;border:1px solid #ddd;"></textarea>
                        </div>
                        <div class="col-md-12">
                           <button class="send_btn" type="submit">Enviar</button>
                        </div>
                     </div>
                  </form>

                  <!-- Bandeja como modal (solo usuarios logueados) -->
                  <?php if ($user_id):
                    $stmtm = $conexion->prepare("SELECT id, mensaje, estado, fecha_creacion FROM contact_messages WHERE id_usuario = ? ORDER BY fecha_creacion DESC");
                    if ($stmtm) {
                      $stmtm->bind_param("i", $user_id);
                      $stmtm->execute();
                      $resm = $stmtm->get_result();
                    }
                 ?>
                   <!-- Modal overlay -->
                   <div id="messagesModal" aria-hidden="true" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;padding:20px;">
                     <div role="dialog" aria-modal="true" aria-labelledby="modalTitle" style="background:#fff;border-radius:12px;max-width:900px;width:100%;max-height:80vh;overflow:auto;padding:20px;box-shadow:0 8px 40px rgba(0,0,0,0.25);">
                       <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px;">
                         <h3 id="modalTitle" style="margin:0;color:#6366f1;">Mis Mensajes y Respuestas</h3>
                         <button id="closeMessagesBtn" aria-label="Cerrar" style="background:#eee;border:none;padding:6px 10px;border-radius:6px;cursor:pointer;">Cerrar ✕</button>
                       </div>

                       <div style="margin-top:8px;">
                         <?php if (isset($resm) && $resm->num_rows>0): ?>
                           <?php while($cm = $resm->fetch_assoc()): ?>
                             <div style="padding:12px;border:1px solid #f1f1f1ff;border-radius:8px;margin-bottom:12px;background:#fafafa;">
                               <div style="font-size:0.95rem;color:#333;"><strong>Enviado:</strong><div style="margin-top:6px;"><?php echo nl2br(htmlspecialchars($cm['mensaje'])); ?></div></div>
                               <div style="margin-top:8px;"><small>Estado: <?php echo htmlspecialchars($cm['estado']); ?> — <?php echo date('d/m/Y H:i', strtotime($cm['fecha_creacion'])); ?></small></div>

                               <?php
                                 $rps = $conexion->prepare("SELECT r.mensaje, r.fecha, a.nombre AS admin_nombre FROM admin_replies r LEFT JOIN administradores a ON r.id_admin = a.id WHERE r.contact_id = ? ORDER BY r.fecha ASC");
                                 $rres = false;
                                 if ($rps) {
                                   $rps->bind_param("i", $cm['id']);
                                   $rps->execute();
                                   $rres = $rps->get_result();
                                 }
                               ?>

                               <?php if ($rres && $rres->num_rows>0): ?>
                                 <div style="margin-top:12px;padding:10px;background:#fff;border-radius:6px;">
                                   <strong>Respuestas del Admin:</strong>
                                   <?php while($rp = $rres->fetch_assoc()): ?>
                                     <div style="margin-top:10px;padding:8px;border-left:3px solid #6366f1;background:#f8f9ff;">
                                       <div style="font-weight:600;color:#333;"><?php echo htmlspecialchars($rp['admin_nombre'] ?: 'Admin'); ?> <small style="color:#777;font-weight:400;margin-left:8px;"><?php echo date('d/m/Y H:i', strtotime($rp['fecha'])); ?></small></div>
                                       <div style="margin-top:6px;"><?php echo nl2br(htmlspecialchars($rp['mensaje'])); ?></div>
                                     </div>
                                   <?php endwhile; ?>
                                 </div>
                               <?php else: ?>
                                 <div style="margin-top:10px;color:#777;">Aún no hay respuesta del admin.</div>
                               <?php endif; ?>
                             </div>
                           <?php endwhile; ?>
                         <?php else: ?>
                           <div style="color:#777;padding:12px;">No tienes mensajes enviados.</div>
                         <?php endif; ?>
                       </div>
                     </div>
                   </div>

                   <script>
                     (function(){
                       const openBtn = document.getElementById('openMessagesBtn');
                       const modal = document.getElementById('messagesModal');
                       const closeBtn = document.getElementById('closeMessagesBtn');
                       function openModal(){
                         modal.style.display = 'flex';
                         modal.setAttribute('aria-hidden','false');
                         // focus trap: focus close button
                         closeBtn.focus();

                         // Marcar mensajes respondidos como vistos en el servidor y quitar badge
                         fetch('mark_messages_viewed.php', { method: 'POST', credentials: 'same-origin' })
                           .then(resp => resp.json())
                           .then(data => {
                             if (data.success) {
                               const badge = document.getElementById('messagesBadge');
                               if (badge) badge.remove();
                             }
                           })
                           .catch(err => {
                             console.error('Error marcando mensajes como vistos:', err);
                           });
                       }
                       function closeModal(){
                         modal.style.display = 'none';
                         modal.setAttribute('aria-hidden','true');
                         openBtn.focus();
                       }
                       // Exponer función para onclick del botón (fallback)
                       window.openMessages = function(){ if (typeof openModal === 'function') openModal(); };

                       if (openBtn) openBtn.addEventListener('click', openModal);
                       if (closeBtn) closeBtn.addEventListener('click', closeModal);
                       // close on overlay click
                       if (modal) modal.addEventListener('click', function(e){
                         if (e.target === modal) closeModal();
                       });
                       // close on ESC
                       document.addEventListener('keydown', function(e){
                         if (e.key === 'Escape' && modal.style.display === 'flex') closeModal();
                       });
                     })();
                   </script>
                 <?php endif; ?>
               </div>
            </div>
         </div>
         <div class="container-fluid">
            <div class="map_section">
               <div id="map">
               </div>
            </div>
         </div>
      </div>
      </div>
      <!-- end contact section -->
      <!--  footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                              <li><a href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/@-34.8851079,-56.1953592,17z/data=!3m1!4b1!4m6!3m5!1s0x959f8018248ae2ef:0x51dd959d2d332c67!8m2!3d-34.8851123!4d-56.1927843!16s%2Fg%2F1hd_ld504?entry=ttu&g_ep=EgoyMDI1MDkwNy4wIKXMDSoASAFQAw%3D%3D" target="_blank" rel="noopener noreferrer"><i class="fa fa-map-marker" aria-hidden="true" style="color:#7c5fe9;"></i></a><br><span style="color:#7c5fe9;">Ubicación</span></li>
                              <li><a href="#" target="_blank" rel="noopener noreferrer"><i class="fa fa-phone" aria-hidden="true" style="color:#7c5fe9;"></i></a><br><span style="color:#7c5fe9;">+598 95 561 757</span></li>
                              <li><a href="https://mail:codemass2025@gmail.com" target="_blank" rel="noopener noreferrer"><i class="fa fa-envelope" aria-hidden="true" style="color:#7c5fe9;"></i></a><br><span style="color:#7c5fe9;">codemass2025@gmail.com</span></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <script>
         // This example adds a marker to indicate the position of Bondi Beach in Sydney,
         // Australia.
         function initMap() {
           var map = new google.maps.Map(document.getElementById('map'), {
             zoom: 11,
             center: {lat: 40.645037, lng: -73.880224},
             });
         
         var image = 'images/maps-and-flags.png';
         var beachMarker = new google.maps.Marker({
             position: {lat: 40.645037, lng: -73.880224},
             map: map,
             icon: image
           });
         }
      </script>
      <!-- google map js -->
      <!-- end google map js --> 
      <script>
  // Mostrar aviso si se envió el formulario
  (function(){
    const params = new URLSearchParams(window.location.search);
    if (params.get('sent') === '1') {
      alert('Mensaje enviado correctamente. Gracias por contactarnos.');
      // limpiar query string
      if (window.history && window.history.replaceState) {
        const url = new URL(window.location);
        url.searchParams.delete('sent');
        window.history.replaceState({}, document.title, url.pathname);
      }
    }
  })();
</script>
   </body>
</html>