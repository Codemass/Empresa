<?php
session_start();
require_once 'conexion.php';

// verificar sesión de usuario (puede usar 'user' o 'admin')
if (!isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}
$ci = $_SESSION['ci'];
$stmt = $conexion->prepare("SELECT id, nombre, apellido, correo, avatar FROM usuarios WHERE ci = ? LIMIT 1");
$stmt->bind_param("s", $ci);
$stmt->execute();
$stmt->bind_result($id, $nombre, $apellido, $correo, $avatar);
$user = null;
if ($stmt->fetch()) {
    $user = ['id'=>$id,'nombre'=>$nombre,'apellido'=>$apellido,'correo'=>$correo,'avatar'=>$avatar];
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Mi Perfil</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .profile-box { max-width:800px;margin:40px auto;padding:24px;background:#fff;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,0.06); }
    .avatar { width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid #f0f0f0; }
    .back-link {
      display:inline-flex;
      align-items:center;
      gap:8px;
      color:#7c5fe9;
      font-weight:600;
      text-decoration:none;
      margin:16px 0;
    }
    .back-link:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <!-- ...header puede incluirse si lo deseas... -->
  <div class="container"> 
    <a href="ajustes.html" class="back-link" aria-label="Volver a ajustes">← Volver a ajustes</a>
    <div class="profile-box">
      <?php if ($user): ?>
        <div style="display:flex;gap:20px;align-items:center;">
          <img src="<?php echo htmlspecialchars($user['avatar'] ? $user['avatar'] : 'images/default-avatar.png'); ?>" alt="avatar" class="avatar">
          <div>
            <h2><?php echo htmlspecialchars($user['nombre'] . ' ' . $user['apellido']); ?></h2>
            <p><?php echo htmlspecialchars($user['correo']); ?></p>
          </div>
        </div>
        <hr style="margin:16px 0;">
        <form action="actualizar_avatar.php" method="POST" enctype="multipart/form-data">
           <input type="hidden" name="user_id" value="<?php echo intval($user['id']); ?>">
           <div>
             <label></label><br>
             <input type="file" name="avatar" accept="image/*" required>
           </div>
           <div style="margin-top:12px;">
             <button type="submit" class="send_btn">Subir avatar</button>
           </div>
        </form>
      <?php else: ?>
        <p>Usuario no encontrado.</p>
      <?php endif; ?>
    </div>
  </div>
   <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <style>
         .footer .location_icon li {
               display: inline-flex;
               align-items: center;
               gap: 8px;
               color: #7c5fe9 !important;
               list-style: none;
               font-size: 1rem;
               justify-content: center;
               text-align: left;
            }
            .footer .location_icon i {
               color: #7c5fe9 !important;
            }
            .container {
               background: #fff;
               border-radius: 20px;
               box-shadow: 0 8px 32px 0 #6366f11a;
               padding: 50px;
               margin-top: 80px;
               margin-bottom: 15px;
               max-width: 850px;
              margin-left: 28%;

               animation: fadeInUp 1s;
            }
            .containerr {
               background: #fff;
               border-radius: 20px;
               box-shadow: 0 8px 32px 0 #6366f11a;
               padding: 50px;

               
               animation: fadeInUp 1s;
            }
      </style>
  <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="https://www.google.com/maps/place/Escuela+T%C3%A9cnica+Arroyo+Seco/@-34.8851079,-56.1953592,17z/data=!3m1!4b1!4m6!3m5!1s0x959f8018248ae2ef:0x51dd959d2d332c67!8m2!3d-34.8851123!4d-56.1927843!16s%2Fg%2F1hd_ld504?entry=ttu&g_ep=EgoyMDI1MDkwNy4wIKXMDSoASAFQAw%3D%3D"><i class="fa fa-map-marker" aria-hidden="true"></i></a><br>Ubicación</li>
                        <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a><br>+598 95 764 982</li>
                        <li><a href="https://mail.google.com/mail/u/1/#sent?compose=CllgCJTGmpJrsBmqKPHhfSRxBZgLMTJvsdBdNdTCfVrZJxjnNFDMcXZMrFTRRgJFgjLfBrCXQjV"><i class="fa fa-envelope" aria-hidden="true"></i></a><br>codemass2025@gmail.com</li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="containerr">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
</body>
</html>
