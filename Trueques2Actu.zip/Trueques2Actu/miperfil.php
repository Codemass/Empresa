<?php
session_start();
require_once 'conexion.php';

// Determinar qué perfil mostrar:
// 1) si hay sesión con 'ci' -> mostrar perfil propio y permitir edición (is_owner = true)
// 2) si no hay sesión pero se pasó ?id=... o ?ci=... -> mostrar perfil público (is_owner = false)
// 3) si no hay sesión ni parámetros -> mostrar formulario público para buscar por CI/ID
$is_owner = false;
$user = null;
$requested_ci = isset($_GET['ci']) ? trim($_GET['ci']) : '';
$requested_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Si hay sesión preferimos mostrar perfil del usuario en sesión
if (isset($_SESSION['ci'])) {
    $ci = $_SESSION['ci'];
    $stmt = $conexion->prepare("SELECT id, nombre, apellido, correo, avatar, ci FROM usuarios WHERE ci = ? LIMIT 1");
    $stmt->bind_param("s", $ci);
    $stmt->execute();
    $stmt->bind_result($id, $nombre, $apellido, $correo, $avatar, $ci_ret);
    if ($stmt->fetch()) {
        $user = ['id'=>$id,'nombre'=>$nombre,'apellido'=>$apellido,'correo'=>$correo,'avatar'=>$avatar,'ci'=>$ci_ret];
        $is_owner = true;
    }
    $stmt->close();
} elseif (isset($_SESSION['user_id'])) {
    $uid = intval($_SESSION['user_id']);
    $stmt = $conexion->prepare("SELECT id, nombre, apellido, correo, avatar, ci FROM usuarios WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->bind_result($id, $nombre, $apellido, $correo, $avatar, $ci_ret);
    if ($stmt->fetch()) {
        $user = ['id'=>$id,'nombre'=>$nombre,'apellido'=>$apellido,'correo'=>$correo,'avatar'=>$avatar,'ci'=>$ci_ret];
        $is_owner = true;
    }
    $stmt->close();
} elseif ($requested_id > 0 || $requested_ci !== '') {
    // Mostrar perfil público solicitado vía GET
    if ($requested_id > 0) {
        $stmt = $conexion->prepare("SELECT id, nombre, apellido, correo, avatar, ci FROM usuarios WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $requested_id);
    } else {
        $stmt = $conexion->prepare("SELECT id, nombre, apellido, correo, avatar, ci FROM usuarios WHERE ci = ? LIMIT 1");
        $stmt->bind_param("s", $requested_ci);
    }
    $stmt->execute();
    $stmt->bind_result($id, $nombre, $apellido, $correo, $avatar, $ci_ret);
    if ($stmt->fetch()) {
        $user = ['id'=>$id,'nombre'=>$nombre,'apellido'=>$apellido,'correo'=>$correo,'avatar'=>$avatar,'ci'=>$ci_ret];
        $is_owner = false;
    }
    $stmt->close();
} else {
    // No sesión y no parámetros -> mostrar formulario público para buscar perfil
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="utf-8">
      <title>Buscar perfil</title>
      <link rel="stylesheet" href="css/style.css">
      <style>
        .box{max-width:560px;margin:80px auto;background:#fff;padding:24px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.06);}
        .btn{background:#7c5fe9;color:#fff;border:none;padding:10px 16px;border-radius:8px;cursor:pointer;}
        .hint{color:#666;margin-bottom:12px;}
      </style>
    </head>
    <body>
      <div class="box">
        <h3>Ver perfil público</h3>
        <p class="hint">Introduce tu C.I. o el ID de usuario para ver el perfil (solo vista pública, sin opciones de edición).</p>
        <form method="GET" action="miperfil.php">
          <div style="margin-bottom:12px;">
            <label>C.I.</label>
            <input name="ci" type="text" placeholder="Ej: 51946920" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
          </div>
          <div style="margin-bottom:12px;">
            <label>o ID de usuario</label>
            <input name="id" type="number" placeholder="ID usuario" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
          </div>
          <div>
            <button class="btn" type="submit">Buscar perfil</button>
            <a href="index.html" style="margin-left:12px;color:#666;text-decoration:none;">← Volver</a>
          </div>
        </form>
      </div>
    </body>
    </html>
    <?php
    exit;
}

// Si llegamos aquí y no encontramos usuario, mostrar mensaje sencillo
if (!$user) {
    // mostrar página simple con enlace a búsqueda/login
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head><meta charset="utf-8"><title>Perfil no encontrado</title><link rel="stylesheet" href="css/style.css"></head>
    <body>
      <div style="max-width:600px;margin:80px auto;background:#fff;padding:24px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,0.06);">
        <h3>Perfil no encontrado</h3>
        <p>El perfil solicitado no existe. Puedes <a href="miperfil.php">buscar otro perfil</a> o <a href="login.php">iniciar sesión</a>.</p>
      </div>
    </body>
    </html>
    <?php
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Mi Perfil</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .profile-box { max-width:800px;margin:40px auto;padding:24px;background:#fff;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,0.06); }
    .avatar { width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid #f0f0f0; }
    .back-link {
      display:inline-flex;
      align-items:center;
      gap:8px;
      color:#7c5fe9;
      font-weight:600;
      text-decoration:none;
      margin:16px 0;
    }
    .back-link:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <div class="container">
    <a href="index.html" class="back-link" aria-label="Volver">← Volver</a>
    <div class="profile-box">
      <?php if ($user): ?>
        <div style="display:flex;gap:20px;align-items:center;">
          <img src="<?php echo htmlspecialchars($user['avatar'] ? $user['avatar'] : 'images/default-avatar.png'); ?>" alt="avatar" class="avatar">
          <div>
            <h2><?php echo htmlspecialchars($user['nombre'] . ' ' . $user['apellido']); ?></h2>
            <p><?php echo htmlspecialchars($user['correo']); ?></p>
            <?php if (!$is_owner): ?>
              <p style="color:#666;margin-top:8px;">Vista pública del perfil.</p>
            <?php endif; ?>
          </div>
        </div>
        <hr style="margin:16px 0;">
        <?php if ($is_owner): ?>
          <form action="actualizar_avatar.php" method="POST" enctype="multipart/form-data">
             <input type="hidden" name="user_id" value="<?php echo intval($user['id']); ?>">
             <div>
               
               <input type="file" name="avatar" accept="image/*" required>
             </div>
             <div style="margin-top:12px;">
               <button type="submit" class="send_btn">Subir avatar</button>
             </div>
          </form>

          <div style="margin-top:20px;padding-top:20px;border-top:1px solid #eee;">
            <a href="logout.php" style="display:inline-block;background:#dc3545;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;">
              <i class="fa-solid fa-sign-out-alt" style="margin-right:8px;"></i> Cerrar sesión
            </a>
          </div>
        <?php else: ?>
          <!-- Opciones públicas: compartir contacto público o volver -->
          <div style="margin-top:16px;">
            <a href="publicacion.php?user=<?php echo intval($user['id']); ?>" class="read_more">Ver publicaciones del usuario</a>
          </div>
        <?php endif; ?>

      <?php else: ?>
        <p>Usuario no encontrado.</p>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
