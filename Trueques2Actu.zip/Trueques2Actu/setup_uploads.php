<?php
$uploads_dir = __DIR__ . '/uploads';

// Crear el directorio si no existe
if (!file_exists($uploads_dir)) {
    mkdir($uploads_dir, 0777, true);
    chmod($uploads_dir, 0777);
}

echo "Directorio de uploads configurado correctamente.";
?>