<?php
require_once 'conexion.php';
session_start();

// Verificar si es admin
$is_admin = false;
if (isset($_SESSION['correo']) && $_SESSION['correo'] === 'codemass2025@gmail.com') {
    $is_admin = true;
}

if (!$is_admin) {
    header('Location: index.html');
    exit;
}

// Manejar eliminación de publicación
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['id_publicacion'])) {
    $action = $_POST['action'];
    $id_pub = intval($_POST['id_publicacion']);

    if ($action === 'eliminar') {
        $stmt = $conexion->prepare("DELETE FROM publicaciones WHERE id = ?");
        $stmt->bind_param("i", $id_pub);
        $stmt->execute();
        $stmt->close();
        
        header('Location: admin_panel.php?eliminada=1');
        exit;
    }
}

// Obtener todas las publicaciones
$query = "SELECT p.id, p.titulo, p.descripcion, p.imagen, p.categoria, p.fecha_creacion,
          u.nombre AS usuario_nombre, u.apellido AS usuario_apellido, u.ci AS usuario_ci,
          (SELECT COUNT(*) FROM solicitudes_trueque WHERE id_publicacion = p.id) AS total_solicitudes
          FROM publicaciones p
          LEFT JOIN usuarios u ON p.id_usuario = u.id
          ORDER BY p.fecha_creacion DESC";
$result = $conexion->query($query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Panel Admin - Publicaciones</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%); }
    .admin-container { background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(99,102,241,0.1); padding: 30px; margin-top: 40px; margin-bottom: 40px; max-width: 1100px; margin-left: auto; margin-right: auto; }
    h2 { color: #7c5fe9; font-weight: 700; margin-bottom: 30px; }
    .admin-nav { display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap; }
    .admin-nav a { background: #6366f1; color: #fff; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; }
    .admin-nav a:hover { background: #5558d9; text-decoration: none; }
    .admin-nav a.active { background: #7c5fe9; }
    .alert { padding: 12px; margin-bottom: 20px; border-radius: 8px; }
    .alert-success { background: #d4edda; color: #155724; }
    table { width: 100%; border-collapse: collapse; }
    table th { background: #6366f1; color: #fff; padding: 12px; text-align: left; }
    table td { padding: 12px; border-bottom: 1px solid #e3e0f7; }
    table tr:hover { background: #f8f9ff; }
    .pub-imagen { width: 60px; height: 60px; object-fit: cover; border-radius: 8px; }
    .btn-sm { padding: 6px 12px; border-radius: 6px; border: none; cursor: pointer; font-weight: 600; }
    .btn-ver { background: #6366f1; color: #fff; }
    .btn-ver:hover { background: #5558d9; }
    .btn-eliminar { background: #dc3545; color: #fff; }
    .btn-eliminar:hover { background: #c82333; }
  </style>
</head>
<body class="main-layout position_head">
  <div class="admin-container">
    <h2><i class="fa fa-file-alt"></i> Panel Admin - Publicaciones</h2>

    <div class="admin-nav">
      <a href="admin_panel.php" class="active">Publicaciones</a>
      <a href="admin_chats.php">Chats</a>
      <a href="admin_mensajes.php">Mensajes</a>
      <a href="admin_usuarios.php">Usuarios</a>
      <a href="publicaciones.php">Volver al Sitio</a>
    </div>

    <?php if (isset($_GET['eliminada'])): ?>
    <div class="alert alert-success"><i class="fa fa-check"></i> Publicación eliminada correctamente.</div>
    <?php endif; ?>

    <?php if ($result && $result->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>Imagen</th>
          <th>Título</th>
          <th>Usuario</th>
          <th>Categoría</th>
          <th>Solicitudes</th>
          <th>Fecha</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td>
            <?php if ($row['imagen']): ?>
            <img src="<?php echo htmlspecialchars($row['imagen']); ?>" alt="publicación" class="pub-imagen">
            <?php else: ?>
            <span style="color:#999;">Sin imagen</span>
            <?php endif; ?>
          </td>
          <td><?php echo htmlspecialchars(substr($row['titulo'], 0, 50)); ?></td>
          <td>
            <?php if ($row['usuario_nombre']): ?>
            <?php echo htmlspecialchars($row['usuario_nombre'] . ' ' . $row['usuario_apellido']); ?><br>
            <small style="color:#999;"><?php echo htmlspecialchars($row['usuario_ci']); ?></small>
            <?php else: ?>
            <span style="color:#999;">Usuario Anónimo</span>
            <?php endif; ?>
          </td>
          <td><?php echo htmlspecialchars($row['categoria']); ?></td>
          <td><span style="background:#e3e0f7;padding:4px 8px;border-radius:4px;"><?php echo intval($row['total_solicitudes']); ?></span></td>
          <td><?php echo date('d/m/Y H:i', strtotime($row['fecha_creacion'])); ?></td>
          <td style="display:flex;gap:6px;">
            <a href="publicacion.php?id=<?php echo $row['id']; ?>" class="btn-sm btn-ver">Ver</a>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="action" value="eliminar">
              <input type="hidden" name="id_publicacion" value="<?php echo $row['id']; ?>">
              <button type="submit" class="btn-sm btn-eliminar" onclick="return confirm('¿Eliminar esta publicación?');">Eliminar</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div style="text-align:center;padding:40px;color:#999;">
      <i class="fa fa-file-alt" style="font-size:2rem;margin-bottom:10px;display:block;"></i>
      <p>No hay publicaciones registradas</p>
    </div>
    <?php endif; ?>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="#" target="_blank" rel="noopener noreferrer"><i class="fa fa-map-marker"></i></a><span>Ubicación</span></li>
                        <li><a href="#" target="_blank" rel="noopener noreferrer"><i class="fa fa-phone"></i></a><span>+598 95 561 757</span></li>
                        <li><a href="#" target="_blank" rel="noopener noreferrer"><i class="fa fa-envelope"></i></a><span>codemass2025@gmail.com</span></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>© 2023 Todos los derechos reservados. <a href="#">Política de privacidad</a> | <a href="#">Términos de servicio</a></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
</body>
</html>