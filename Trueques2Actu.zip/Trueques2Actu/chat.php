<?php
require_once 'conexion.php';
session_start();

if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    header('Location: login.php');
    exit;
}

$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id = intval($uid);
        $stmtu->close();
    }
}

if ($user_id === null) {
    header('Location: login.php');
    exit;
}

// Obtener id_chat desde parámetros
$id_chat = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id_chat <= 0) {
    header('Location: publicaciones.php?error=chat_no_valido');
    exit;
}

// Verificar acceso al chat
$stmt = $conexion->prepare("SELECT id_usuario_1, id_usuario_2 FROM chats WHERE id = ?");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$stmt->bind_result($u1, $u2);
if (!$stmt->fetch() || ($user_id !== $u1 && $user_id !== $u2)) {
    $stmt->close();
    header('Location: publicaciones.php?error=acceso_denegado');
    exit;
}
$stmt->close();

// Obtener otro usuario
$otro_usuario_id = ($user_id === $u1) ? $u2 : $u1;
$stmt = $conexion->prepare("SELECT nombre, apellido, avatar FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $otro_usuario_id);
$stmt->execute();
$stmt->bind_result($otro_nombre, $otro_apellido, $otro_avatar);
$stmt->fetch();
$stmt->close();

// Obtener mensajes
$stmt = $conexion->prepare("SELECT mc.id, mc.id_usuario, mc.mensaje, mc.fecha_envio, u.nombre, u.apellido
                            FROM mensajes_chat mc
                            JOIN usuarios u ON mc.id_usuario = u.id
                            WHERE mc.id_chat = ?
                            ORDER BY mc.fecha_envio ASC");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$mensajes_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Chat - <?php echo htmlspecialchars($otro_nombre . ' ' . $otro_apellido); ?></title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%); }
    .chat-container { background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(99,102,241,0.1); max-width: 700px; margin: 40px auto; display: flex; flex-direction: column; height: 600px; }
    .chat-header { background: #6366f1; color: #fff; padding: 20px; border-radius: 20px 20px 0 0; display: flex; align-items: center; gap: 12px; }
    .chat-header img { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }
    .chat-header h5 { margin: 0; }
    .chat-messages { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 12px; }
    .mensaje { padding: 12px; border-radius: 12px; max-width: 70%; word-wrap: break-word; }
    .mensaje.propio { background: #6366f1; color: #fff; align-self: flex-end; }
    .mensaje.otro { background: #f0f0f0; color: #333; align-self: flex-start; }
    .chat-input { padding: 16px; border-top: 1px solid #e3e0f7; display: flex; gap: 8px; }
    .chat-input textarea { flex: 1; border: 1px solid #ccc; border-radius: 8px; padding: 8px; resize: none; font-family: Arial; }
    .chat-input button { background: #6366f1; color: #fff; border: none; border-radius: 8px; padding: 8px 16px; cursor: pointer; font-weight: 600; }
    .chat-input button:hover { background: #5558d9; }
    .volver-link { display: inline-block; margin-top: 20px; text-align: center; }
  </style>
</head>
<body class="main-layout position_head">
  <div class="chat-container">
    <div class="chat-header">
      <img src="<?php echo htmlspecialchars($otro_avatar ? $otro_avatar : 'images/default-avatar.png'); ?>" alt="avatar">
      <div>
        <h5 style="margin:0;"><?php echo htmlspecialchars($otro_nombre . ' ' . $otro_apellido); ?></h5>
        <small>Chat activo</small>
      </div>
    </div>
    <div class="chat-messages" id="chatMessages">
      <?php while($msg = $mensajes_result->fetch_assoc()): ?>
        <div class="mensaje <?php echo ($msg['id_usuario'] === $user_id) ? 'propio' : 'otro'; ?>">
          <small style="opacity:0.8;"><?php echo htmlspecialchars($msg['nombre']); ?></small><br>
          <?php echo htmlspecialchars($msg['mensaje']); ?>
          <small style="opacity:0.7;display:block;margin-top:4px;"><?php echo date('H:i', strtotime($msg['fecha_envio'])); ?></small>
        </div>
      <?php endwhile; ?>
    </div>
    <div class="chat-input">
      <form method="POST" action="procesar_mensaje.php" style="display:flex;width:100%;gap:8px;">
        <input type="hidden" name="id_chat" value="<?php echo $id_chat; ?>">
        <textarea name="mensaje" rows="2" placeholder="Escribe tu mensaje..." required></textarea>
        <button type="submit">Enviar</button>
      </form>
    </div>
  </div>

  <div class="text-center volver-link">
    <a href="mis_chats.php" class="read_more">
      <i class="fa fa-arrow-left"></i> Volver a Mis Chats
    </a>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script>
    // Auto-scroll al último mensaje
    const chatMessages = document.getElementById('chatMessages');
    if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Cargar nuevos mensajes cada 2 segundos sin recargar la página
    setInterval(() => {
      fetch('cargar_mensajes.php?id_chat=<?php echo $id_chat; ?>')
        .then(response => response.text())
        .then(data => {
          const chatMessages = document.getElementById('chatMessages');
          chatMessages.innerHTML = data;
          chatMessages.scrollTop = chatMessages.scrollHeight;
        })
        .catch(error => console.error('Error al cargar mensajes:', error));
    }, 2000);
  </script>
</body>
</html>
