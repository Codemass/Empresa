<?php
session_start();
require_once 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $categoria = $_POST['categoria'] ?? '';
    $descripcion = $_POST['descripcion'] ?? '';
    
    // Validar que se haya subido una imagen
    if (!isset($_FILES['imagen']) || $_FILES['imagen']['error'] !== UPLOAD_ERR_OK) {
        echo "<script>alert('Error al subir la imagen. Por favor, inténtalo de nuevo.');window.location='publicar.html';</script>";
        exit;
    }

    // Configurar directorio de subida
    $directorio_destino = "uploads/";
    if (!file_exists($directorio_destino)) {
        mkdir($directorio_destino, 0777, true);
    }

    // Obtener información del archivo
    $archivo_nombre = $_FILES['imagen']['name'];
    $archivo_tmp = $_FILES['imagen']['tmp_name'];
    $extension = strtolower(pathinfo($archivo_nombre, PATHINFO_EXTENSION));

    // Validar extensión
    $extensiones_permitidas = array('jpg', 'jpeg', 'png', 'gif', 'webp');
    if (!in_array($extension, $extensiones_permitidas)) {
        echo "<script>alert('Tipo de archivo no permitido. Solo se permiten imágenes JPG, JPEG, PNG, GIF y WEBP.');window.location='publicar.html';</script>";
        exit;
    }

    // Generar nombre único para el archivo
    $nombre_unico = uniqid() . '.' . $extension;
    $ruta_archivo = $directorio_destino . $nombre_unico;

    // Mover el archivo
    if (move_uploaded_file($archivo_tmp, $ruta_archivo)) {
        // Insertar en la base de datos
        $stmt = $conexion->prepare("INSERT INTO publicaciones (categoria, descripcion, imagen) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $categoria, $descripcion, $ruta_archivo);

        if ($stmt->execute()) {
            echo "<script>alert('Publicación realizada con éxito.');window.location='publicaciones.html';</script>";
        } else {
            unlink($ruta_archivo); // Eliminar la imagen si falla la inserción en la BD
            echo "<script>alert('Error al guardar la publicación en la base de datos.');window.location='publicar.html';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Error al subir la imagen al servidor.');window.location='publicar.html';</script>";
    }
    
    $conexion->close();
} else {
    header("Location: publicar.html");
}
?>