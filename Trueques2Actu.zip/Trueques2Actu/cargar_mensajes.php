<?php
require_once 'conexion.php';
session_start();

if (!isset($_SESSION['user_id']) && !isset($_SESSION['ci'])) {
    exit;
}

$user_id = null;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
} else {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id = intval($uid);
        $stmtu->close();
    }
}

if (!isset($_GET['id_chat'])) {
    exit;
}

$id_chat = intval($_GET['id_chat']);

// Obtener mensajes
$stmt = $conexion->prepare("SELECT mc.id, mc.id_usuario, mc.mensaje, mc.fecha_envio, u.nombre, u.apellido
                            FROM mensajes_chat mc
                            JOIN usuarios u ON mc.id_usuario = u.id
                            WHERE mc.id_chat = ?
                            ORDER BY mc.fecha_envio ASC");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$mensajes_result = $stmt->get_result();

// Mostrar mensajes sin HTML completo
while($msg = $mensajes_result->fetch_assoc()): ?>
  <div class="mensaje <?php echo ($msg['id_usuario'] === $user_id) ? 'propio' : 'otro'; ?>">
    <small style="opacity:0.8;"><?php echo htmlspecialchars($msg['nombre']); ?></small><br>
    <?php echo htmlspecialchars($msg['mensaje']); ?>
    <small style="opacity:0.7;display:block;margin-top:4px;"><?php echo date('H:i', strtotime($msg['fecha_envio'])); ?></small>
  </div>
<?php endwhile; ?>
