CREATE TABLE Usuario (
    CI INT PRIMARY KEY,
    Nombre VARCHAR(50),
    Apellido VARCHAR(50),
    Contrasena VARCHAR(100),
    Correo VARCHAR(100),
    FechaNacimiento DATE
) ENGINE=InnoDB;

CREATE TABLE Registrado (
    CI INT PRIMARY KEY,
    FOREIGN KEY (CI) REFERENCES Usuario(CI)
) ENGINE=InnoDB;

CREATE TABLE Administrador (
    CI INT PRIMARY KEY,
    FOREIGN KEY (CI) REFERENCES Usuario(CI)
) ENGINE=InnoDB;

CREATE TABLE Publicacion (
    ID_Publicacion INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Estado VARCHAR(20),
    FechaPublicacion DATE
) ENGINE=InnoDB;

CREATE TABLE Trueque (
    ID_Trueque INT PRIMARY KEY,
    ID_PublicacionReceptor INT,
    CI_UsuarioReceptor INT,
    FechaAceptacion DATE,
    FOREIGN KEY (ID_PublicacionReceptor) REFERENCES Publicacion(ID_Publicacion),
    FOREIGN KEY (CI_UsuarioReceptor) REFERENCES Registrado(CI)
) ENGINE=InnoDB;

CREATE TABLE Valoracion (
    ID_Valoracion INT PRIMARY KEY,
    CI_UsuarioEmisor INT,
    CI_UsuarioValorado INT,
    Puntuacion INT,
    Comentario TEXT,
    FOREIGN KEY (CI_UsuarioEmisor) REFERENCES Registrado(CI),
    FOREIGN KEY (CI_UsuarioValorado) REFERENCES Registrado(CI)
) ENGINE=InnoDB;
