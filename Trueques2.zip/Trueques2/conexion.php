<?php
	$conexion = new mysqli('localhost', 'root', '', 'Proyecto');
	if ($conexion->connect_errno) {
		echo "Lo sentimos, este sitio web está experimentando problemas.";
		exit;
	}
	
?>