<?php
require_once 'conexion.php';
session_start();

// Obtener user_id del usuario logueado
$user_id_logueado = null;
if (isset($_SESSION['user_id'])) {
    $user_id_logueado = intval($_SESSION['user_id']);
} elseif (isset($_SESSION['ci'])) {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id_logueado = intval($uid);
        $stmtu->close();
    }
}

// Redirigir si no está logueado
if (!$user_id_logueado) {
    header("Location: login.php");
    exit;
}

// Obtener id del usuario a calificar
$id_usuario = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id_usuario <= 0 || $id_usuario === $user_id_logueado) {
    header("Location: publicaciones.php");
    exit;
}

// Obtener datos del usuario a calificar
$stmt = $conexion->prepare("SELECT nombre, apellido FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();
$stmt->close();

if (!$usuario) {
    header("Location: publicaciones.php");
    exit;
}

// Obtener calificación existente si la hay
$calificacion_existente = null;
$stmt = $conexion->prepare("SELECT * FROM calificaciones WHERE id_usuario_evaluado = ? AND id_usuario_evaluador = ?");
$stmt->bind_param("ii", $id_usuario, $user_id_logueado);
$stmt->execute();
$resultado = $stmt->get_result();
$calificacion_existente = $resultado->fetch_assoc();
$stmt->close();

// Procesar envío del formulario
$mensaje = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $puntuacion = isset($_POST['puntuacion']) ? intval($_POST['puntuacion']) : 0;
    $comentario = isset($_POST['comentario']) ? trim($_POST['comentario']) : '';

    if ($puntuacion < 1 || $puntuacion > 5) {
        $mensaje = 'Puntuación inválida. Debe estar entre 1 y 5.';
    } else {
        if ($calificacion_existente) {
            // Actualizar calificación existente
            $stmt = $conexion->prepare("UPDATE calificaciones SET puntuacion = ?, comentario = ? WHERE id_usuario_evaluado = ? AND id_usuario_evaluador = ?");
            $stmt->bind_param("isii", $puntuacion, $comentario, $id_usuario, $user_id_logueado);
            if ($stmt->execute()) {
                $mensaje = 'Calificación actualizada correctamente.';
                header("Refresh: 2; url=perfil_usuario.php?id=$id_usuario");
            } else {
                $mensaje = 'Error al actualizar la calificación.';
            }
            $stmt->close();
        } else {
            // Insertar nueva calificación
            $stmt = $conexion->prepare("INSERT INTO calificaciones (id_usuario_evaluado, id_usuario_evaluador, puntuacion, comentario) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiis", $id_usuario, $user_id_logueado, $puntuacion, $comentario);
            if ($stmt->execute()) {
                $mensaje = 'Calificación registrada correctamente.';
                header("Refresh: 2; url=perfil_usuario.php?id=$id_usuario");
            } else {
                $mensaje = 'Error al registrar la calificación.';
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CHANGEMASS - Calificar usuario</title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/responsive.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <style>
         body {
            background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%);
         }
         .rating-stars {
            font-size: 3rem;
            color: #ddd;
            letter-spacing: 10px;
            cursor: pointer;
            user-select: none;
         }
         .rating-stars span {
            transition: color 0.2s;
         }
         .rating-stars span:hover,
         .rating-stars span.active {
            color: #ffc107;
         }
      </style>
   </head>
   <body class="main-layout position_head">
      <!-- ...existing header code... -->
      <header>
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark">
                        <div class="collapse navbar-collapse">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                              <li class="nav-item"><a class="nav-link" href="publicaciones.php">Publicaciones</a></li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>

      <div class="container" style="margin-top:50px;margin-bottom:50px;">
         <div class="row">
            <div class="col-md-6 offset-md-3">
               <div style="background:#fff;border-radius:18px;box-shadow:0 4px 24px 0 rgba(99,102,241,0.10);padding:40px;animate__animated animate__fadeInUp;">
                  <h2 style="color:#7c5fe9;text-align:center;margin-bottom:30px;font-weight:700;">
                     Calificar a <?php echo htmlspecialchars($usuario['nombre']); ?>
                  </h2>

                  <?php if ($mensaje): ?>
                  <div style="background:<?php echo strpos($mensaje, 'Error') ? '#f8d7da' : '#d4edda'; ?>;color:<?php echo strpos($mensaje, 'Error') ? '#721c24' : '#155724'; ?>;padding:12px;border-radius:8px;margin-bottom:20px;border:1px solid <?php echo strpos($mensaje, 'Error') ? '#f5c6cb' : '#c3e6cb'; ?>;">
                     <?php echo htmlspecialchars($mensaje); ?>
                  </div>
                  <?php endif; ?>

                  <form method="POST">
                     <div style="margin-bottom:30px;text-align:center;">
                        <label style="display:block;color:#333;font-weight:600;margin-bottom:15px;">Selecciona tu calificación</label>
                        <div class="rating-stars" id="ratingStars">
                           <?php for ($i = 1; $i <= 5; $i++): ?>
                           <span class="star <?php echo $calificacion_existente && $calificacion_existente['puntuacion'] >= $i ? 'active' : ''; ?>" data-value="<?php echo $i; ?>" onclick="setRating(<?php echo $i; ?>)">★</span>
                           <?php endfor; ?>
                        </div>
                        <input type="hidden" name="puntuacion" id="puntuacion" value="<?php echo $calificacion_existente ? $calificacion_existente['puntuacion'] : '0'; ?>" required>
                     </div>

                     <div style="margin-bottom:20px;">
                        <label for="comentario" style="display:block;color:#333;font-weight:600;margin-bottom:10px;">Comentario (opcional)</label>
                        <textarea id="comentario" name="comentario" rows="5" style="width:100%;padding:12px;border:1px solid #ddd;border-radius:8px;font-family:'Poppins',sans-serif;resize:vertical;" placeholder="Comparte tu experiencia con este usuario..."><?php echo $calificacion_existente && $calificacion_existente['comentario'] ? htmlspecialchars($calificacion_existente['comentario']) : ''; ?></textarea>
                     </div>

                     <div style="display:flex;gap:10px;justify-content:center;">
                        <button type="submit" class="btn btn-primary btn-lg">
                           <i class="fa fa-send"></i> <?php echo $calificacion_existente ? 'Actualizar calificación' : 'Enviar calificación'; ?>
                        </button>
                        <a href="perfil_usuario.php?id=<?php echo $id_usuario; ?>" class="btn btn-secondary btn-lg">
                           <i class="fa fa-arrow-left"></i> Cancelar
                        </a>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>

      <!-- ...existing footer code... -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="#"><i class="fa fa-map-marker"></i></a><span>Ubicación</span></li>
                        <li><a href="#"><i class="fa fa-phone"></i></a><span>+598 95 561 757</span></li>
                        <li><a href="https://mail:codemass2025@gmail.com"><i class="fa fa-envelope"></i></a><span>codemass2025@gmail.com</span></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>

      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script>
      function setRating(value) {
         document.getElementById('puntuacion').value = value;
         const stars = document.querySelectorAll('.star');
         stars.forEach((star, index) => {
            if (index < value) {
               star.classList.add('active');
            } else {
               star.classList.remove('active');
            }
         });
      }

      // Mostrar estrellas al pasar el mouse
      document.querySelectorAll('.star').forEach(star => {
         star.addEventListener('mouseover', function() {
            const value = this.getAttribute('data-value');
            const stars = document.querySelectorAll('.star');
            stars.forEach((s, index) => {
               if (index < value) {
                  s.style.color = '#ffc107';
               } else {
                  s.style.color = '#ddd';
               }
            });
         });
      });

      document.getElementById('ratingStars').addEventListener('mouseout', function() {
         const current = document.getElementById('puntuacion').value;
         const stars = document.querySelectorAll('.star');
         stars.forEach((s, index) => {
            if (index < current) {
               s.style.color = '#ffc107';
            } else {
               s.style.color = '#ddd';
            }
         });
      });
      </script>
   </body>
</html>
