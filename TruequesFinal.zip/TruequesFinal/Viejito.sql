CREATE TABLE IF NOT EXISTS usuarios (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL,
	    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
	);










CREATE TABLE IF NOT EXISTS Usuario (
    CI INT PRIMARY KEY,
    Nombre VARCHAR(50),
    Apellido VARCHAR(50),
    Contrasena VARCHAR(100),
    Correo VARCHAR(100),
    FechaNacimiento DATE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Registrado (
    CI INT PRIMARY KEY,
    FOREIGN KEY (CI) REFERENCES Usuario(CI)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Administrador (
    CI INT PRIMARY KEY,
    FOREIGN KEY (CI) REFERENCES Usuario(CI)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Publicacion (
    ID_Publicacion INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Estado VARCHAR(20),
    FechaPublicacion DATE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Trueque (
    ID_Trueque INT PRIMARY KEY,
    ID_PublicacionReceptor INT,
    CI_UsuarioReceptor INT,
    FechaAceptacion DATE,
    FOREIGN KEY (ID_PublicacionReceptor) REFERENCES Publicacion(ID_Publicacion),
    FOREIGN KEY (CI_UsuarioReceptor) REFERENCES Registrado(CI)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Valoracion (
    ID_Valoracion INT PRIMARY KEY,
    CI_UsuarioEmisor INT,
    CI_UsuarioValorado INT,
    Puntuacion INT,
    Comentario TEXT,
    FOREIGN KEY (CI_UsuarioEmisor) REFERENCES Registrado(CI),
    FOREIGN KEY (CI_UsuarioValorado) REFERENCES Registrado(CI)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS publicaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    imagen VARCHAR(255) NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS solicitudes_trueque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_publicacion INT NOT NULL,
    id_usuario_solicitante INT NOT NULL,
    id_usuario_dueno INT NOT NULL,
    estado VARCHAR(20) DEFAULT 'pendiente',
    fecha_solicitud DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_solicitante) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_dueno) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS chats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_solicitud INT NOT NULL UNIQUE,
    id_usuario_1 INT NOT NULL,
    id_usuario_2 INT NOT NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_solicitud) REFERENCES solicitudes_trueque(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_1) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_2) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS mensajes_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_chat INT NOT NULL,
    id_usuario INT NOT NULL,
    mensaje TEXT NOT NULL,
    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_chat) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);









CREATE TABLE IF NOT EXISTS administradores (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS usuarios (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    ci VARCHAR(8) NOT NULL UNIQUE,
	    nombre VARCHAR(100) NOT NULL,
	    apellido VARCHAR(100) NOT NULL,
	    correo VARCHAR(255) NOT NULL UNIQUE,
	    fecha_nacimiento DATE NOT NULL,
	    contrasena VARCHAR(255) NOT NULL,
	    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
	);

    CREATE TABLE IF NOT EXISTS publicaciones (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    titulo VARCHAR(255) NOT NULL,
	    descripcion TEXT NOT NULL,
	    id_usuario INT,
	    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
	);

    CREATE TABLE IF NOT EXISTS solicitudes_trueque (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_publicacion INT NOT NULL,
	    id_usuario_solicitante INT NOT NULL,
	    id_usuario_dueno INT NOT NULL,
	    estado VARCHAR(20) DEFAULT 'pendiente',
	    fecha_solicitud DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_publicacion) REFERENCES publicaciones(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_solicitante) REFERENCES usuarios(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_dueno) REFERENCES usuarios(id) ON DELETE CASCADE
	);

    CREATE TABLE IF NOT EXISTS chats (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_solicitud INT NOT NULL UNIQUE,
	    id_usuario_1 INT NOT NULL,
	    id_usuario_2 INT NOT NULL,
	    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_solicitud) REFERENCES solicitudes_trueque(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_1) REFERENCES usuarios(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario_2) REFERENCES usuarios(id) ON DELETE CASCADE
	);

    CREATE TABLE IF NOT EXISTS mensajes_chat (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_chat INT NOT NULL,
	    id_usuario INT NOT NULL,
	    mensaje TEXT NOT NULL,
	    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_chat) REFERENCES chats(id) ON DELETE CASCADE,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
	);

    CREATE TABLE IF NOT EXISTS sanciones (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_usuario INT NOT NULL,
	    motivo TEXT NOT NULL,
	    fecha_sancion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    tipo VARCHAR(50) NOT NULL,
	    activa TINYINT(1) DEFAULT 1,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
	);

    CREATE TABLE IF NOT EXISTS contact_messages (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    id_usuario INT NULL,
	    nombre VARCHAR(150) NULL,
	    correo VARCHAR(255) NULL,
	    telefono VARCHAR(50) NULL,
	    mensaje TEXT NOT NULL,
	    estado VARCHAR(20) NOT NULL DEFAULT 'pendiente',
	    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE SET NULL
	);

    CREATE TABLE IF NOT EXISTS admin_replies (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    contact_id INT NOT NULL,
	    id_admin INT NULL,
	    mensaje TEXT NOT NULL,
	    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (contact_id) REFERENCES contact_messages(id) ON DELETE CASCADE
	);

    CREATE TABLE IF NOT EXISTS notificaciones (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    user_id INT NOT NULL,
	    tipo VARCHAR(50) NOT NULL,
	    referencia_id INT NULL,
	    mensaje VARCHAR(255) NOT NULL,
	    leida TINYINT(1) DEFAULT 0,
	    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (user_id) REFERENCES usuarios(id) ON DELETE CASCADE
	);