<?php
require_once 'conexion.php';
session_start();

// Obtener user_id del usuario logueado
$user_id_logueado = null;
if (isset($_SESSION['user_id'])) {
    $user_id_logueado = intval($_SESSION['user_id']);
} elseif (isset($_SESSION['ci'])) {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id_logueado = intval($uid);
        $stmtu->close();
    }
}

// Obtener término de búsqueda
$busqueda = isset($_GET['q']) ? trim($_GET['q']) : '';
$usuarios = [];
$total_resultados = 0;

if (strlen($busqueda) >= 2) {
    $busqueda_param = '%' . $busqueda . '%';
    // --- FIX: usar variable temporal para bind_param ---
    $id_logueado_param = $user_id_logueado ? intval($user_id_logueado) : 0;
    
    // Buscar usuarios por nombre, apellido o correo
    $stmt = $conexion->prepare("
        SELECT u.id, u.nombre, u.apellido, u.avatar, u.fecha_registro,
               COALESCE(AVG(c.puntuacion), 0) AS promedio_calificacion,
               COUNT(c.id) AS total_calificaciones
        FROM usuarios u
        LEFT JOIN calificaciones c ON u.id = c.id_usuario_evaluado
        WHERE (u.nombre LIKE ? OR u.apellido LIKE ? OR u.correo LIKE ?)
        AND u.id != ?
        GROUP BY u.id
        ORDER BY u.nombre ASC
        LIMIT 50
    ");
    
    if ($stmt) {
        $stmt->bind_param("sssi", $busqueda_param, $busqueda_param, $busqueda_param, $id_logueado_param);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        while ($row = $resultado->fetch_assoc()) {
            $usuarios[] = $row;
        }
        $stmt->close();
        $total_resultados = count($usuarios);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CHANGEMASS - Buscar Usuarios</title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/responsive.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <style>
         body {
            background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%);
         }
         .search-container {
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 4px 24px 0 rgba(99,102,241,0.10);
            padding: 40px 30px;
            margin-bottom: 40px;
         }
         .search-input-group {
            position: relative;
            margin-bottom: 0;
         }
         .search-input-group input {
            width: 100%;
            padding: 16px 50px 16px 20px;
            font-size: 1.1rem;
            border: 2px solid #e3e0f7;
            border-radius: 12px;
            transition: border-color 0.3s;
         }
         .search-input-group input:focus {
            outline: none;
            border-color: #7c5fe9;
            box-shadow: 0 0 0 3px rgba(124, 95, 233, 0.1);
         }
         .search-input-group button {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            background: #7c5fe9;
            border: none;
            color: #fff;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
         }
         .search-input-group button:hover {
            background: #6b50d9;
         }
         .usuario-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 2px 12px rgba(99,102,241,0.10);
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 20px;
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
         }
         .usuario-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 20px rgba(99,102,241,0.15);
            text-decoration: none;
         }
         .usuario-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #7c5fe9;
            flex-shrink: 0;
         }
         .usuario-info {
            flex-grow: 1;
         }
         .usuario-nombre {
            font-size: 1.2rem;
            font-weight: 700;
            color: #7c5fe9;
            margin-bottom: 5px;
         }
         .usuario-fecha {
            font-size: 0.9rem;
            color: #999;
            margin-bottom: 8px;
         }
         .usuario-rating {
            font-size: 0.95rem;
            color: #666;
         }
         .usuario-rating .stars {
            color: #ffc107;
            margin-right: 8px;
         }
         .no-resultados {
            background: #fff;
            border-radius: 15px;
            padding: 40px;
            text-align: center;
            color: #999;
         }
         .resultados-info {
            color: #666;
            margin-bottom: 20px;
            font-weight: 600;
         }
      </style>
   </head>
   <body class="main-layout position_head">
      <!-- ...existing header... -->
      <header>
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                              <li class="nav-item"><a class="nav-link" href="publicaciones.php">Publicaciones</a></li>
                              <li class="nav-item"><a class="nav-link" href="publicar.html">Publicar</a></li>
                              <li class="nav-item active"><a class="nav-link" href="buscar_usuarios.php"><i class="fa fa-search"></i> Buscar Usuarios</a></li>
                              <li class="nav-item"><a class="nav-link" href="contactanos.php">Contactanos</a></li>
                              <li class="nav-item"><a class="nav-link" href="mis_solicitudes.php">Mis Solicitudes</a></li>
                              <li class="nav-item"><a class="nav-link" href="mis_chats.php">Mis Chats</a></li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>

      <div class="container" style="margin-top:50px;margin-bottom:50px;">
         <div class="row">
            <div class="col-md-10 offset-md-1">
               <div class="search-container animate__animated animate__fadeInUp">
                  <h2 style="color:#7c5fe9;text-align:center;margin-bottom:30px;font-weight:700;">
                     Buscar Usuarios
                  </h2>
                  <form method="GET" class="search-input-group">
                     <input 
                        type="text" 
                        name="q" 
                        placeholder="Busca por nombre, apellido o correo..." 
                        value="<?php echo htmlspecialchars($busqueda); ?>"
                        autofocus
                     />
                     <button type="submit"><i class="fa fa-search"></i></button>
                  </form>
               </div>

               <?php if ($busqueda): ?>
                  <?php if ($total_resultados > 0): ?>
                  <div class="resultados-info">
                     Se encontraron <?php echo $total_resultados; ?> usuario<?php echo $total_resultados !== 1 ? 's' : ''; ?>
                  </div>
                  <div class="animate__animated animate__fadeIn">
                     <?php foreach ($usuarios as $usuario): ?>
                     <a href="perfil_usuario.php?id=<?php echo $usuario['id']; ?>" class="usuario-card">
                        <img src="<?php echo htmlspecialchars($usuario['avatar'] ?? 'images/default-avatar.png'); ?>" 
                             alt="avatar" class="usuario-avatar">
                        <div class="usuario-info">
                           <div class="usuario-nombre">
                              <?php echo htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']); ?>
                           </div>
                           <div class="usuario-fecha">
                              Miembro desde <?php echo date('d/m/Y', strtotime($usuario['fecha_registro'])); ?>
                           </div>
                           <div class="usuario-rating">
                              <span class="stars">
                                 <?php 
                                    $prom = floatval($usuario['promedio_calificacion']);
                                    for ($i = 1; $i <= 5; $i++) {
                                       echo $i <= floor($prom) ? '★' : ($i - $prom < 1 ? '✩' : '☆');
                                    }
                                 ?>
                              </span>
                              <span>
                                 <?php echo $usuario['total_calificaciones'] > 0 ? round($prom, 1) . '/5 (' . intval($usuario['total_calificaciones']) . ' calificaciones)' : 'Sin calificaciones'; ?>
                              </span>
                           </div>
                        </div>
                        <div style="color:#7c5fe9;font-size:1.2rem;">
                           <i class="fa fa-chevron-right"></i>
                        </div>
                     </a>
                     <?php endforeach; ?>
                  </div>
                  <?php else: ?>
                  <div class="no-resultados animate__animated animate__fadeIn">
                     <i class="fa fa-search" style="font-size:3rem;color:#ddd;margin-bottom:20px;"></i>
                     <p style="font-size:1.1rem;">No se encontraron usuarios que coincidan con "<?php echo htmlspecialchars($busqueda); ?>"</p>
                     <p style="font-size:0.95rem;margin-top:10px;">Intenta con un nombre, apellido o correo diferente</p>
                  </div>
                  <?php endif; ?>
               <?php else: ?>
               <div class="no-resultados animate__animated animate__fadeIn">
                  <i class="fa fa-user-plus" style="font-size:3rem;color:#ddd;margin-bottom:20px;"></i>
                  <p style="font-size:1.1rem;">Ingresa un término de búsqueda</p>
                  <p style="font-size:0.95rem;margin-top:10px;">Busca usuarios por nombre, apellido o correo para ver sus perfiles y calificaciones</p>
               </div>
               <?php endif; ?>
            </div>
         </div>
      </div>

      <!-- ...existing footer... -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="#"><i class="fa fa-map-marker"></i></a><span>Ubicación</span></li>
                        <li><a href="#"><i class="fa fa-phone"></i></a><span>+598 95 561 757</span></li>
                        <li><a href="https://mail:codemass2025@gmail.com"><i class="fa fa-envelope"></i></a><span>codemass2025@gmail.com</span></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>

      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>
