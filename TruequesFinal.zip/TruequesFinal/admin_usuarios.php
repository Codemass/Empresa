<?php
require_once 'conexion.php';
session_start();

// Verificar si es admin
$is_admin = false;
if (isset($_SESSION['correo']) && $_SESSION['correo'] === 'codemass2025@gmail.com') {
    $is_admin = true;
}

if (!$is_admin) {
    header('Location: index.html');
    exit;
}

// Manejar acciones (sancionar, eliminar, activar)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $id_usuario = intval($_POST['id_usuario']);

    if ($action === 'sancionar') {
        $motivo = trim($_POST['motivo']);
        $tipo = isset($_POST['tipo']) ? trim($_POST['tipo']) : 'advertencia';
        
        if ($motivo !== '') {
            $stmt = $conexion->prepare("INSERT INTO sanciones (id_usuario, motivo, tipo) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $id_usuario, $motivo, $tipo);
            $stmt->execute();
            $stmt->close();
        }
        header('Location: admin_usuarios.php?sancionado=1');
        exit;
    } elseif ($action === 'eliminar') {
        $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $stmt->close();
        
        // También eliminar sus publicaciones, chats, etc
        $conexion->query("DELETE FROM publicaciones WHERE id_usuario = $id_usuario");
        
        header('Location: admin_usuarios.php?eliminado=1');
        exit;
    } elseif ($action === 'levantar_sancion') {
        $id_sancion = intval($_POST['id_sancion']);
        $stmt = $conexion->prepare("UPDATE sanciones SET activa = 0 WHERE id = ?");
        $stmt->bind_param("i", $id_sancion);
        $stmt->execute();
        $stmt->close();
        
        header('Location: admin_usuarios.php?sancion_levantada=1');
        exit;
    }
}

// Obtener todos los usuarios
$query = "SELECT u.id, u.ci, u.nombre, u.apellido, u.correo, u.fecha_registro,
          (SELECT COUNT(*) FROM publicaciones WHERE id_usuario = u.id) AS total_publicaciones,
          (SELECT COUNT(*) FROM sanciones WHERE id_usuario = u.id AND activa = 1) AS sanciones_activas
          FROM usuarios u
          ORDER BY u.fecha_registro DESC";
$result = $conexion->query($query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Panel Admin - Usuarios</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%); }
    .admin-container { background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(99,102,241,0.1); padding: 30px; margin-top: 40px; margin-bottom: 40px; max-width: 1100px; margin-left: auto; margin-right: auto; }
    h2 { color: #7c5fe9; font-weight: 700; margin-bottom: 30px; }
    .admin-nav { display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap; }
    .admin-nav a { background: #6366f1; color: #fff; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; }
    .admin-nav a:hover { background: #5558d9; text-decoration: none; }
    .admin-nav a.active { background: #7c5fe9; }
    .alert { padding: 12px; margin-bottom: 20px; border-radius: 8px; }
    .alert-success { background: #d4edda; color: #155724; }
    table { width: 100%; border-collapse: collapse; }
    table th { background: #6366f1; color: #fff; padding: 12px; text-align: left; }
    table td { padding: 12px; border-bottom: 1px solid #e3e0f7; }
    table tr:hover { background: #f8f9ff; }
    .badge-sancion { background: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 4px; font-weight: 600; }
    .btn-sancion { background: #ffc107; color: #000; padding: 6px 12px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .btn-sancion:hover { background: #e0a800; }
    .btn-eliminar { background: #dc3545; color: #fff; padding: 6px 12px; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .btn-eliminar:hover { background: #c82333; }
    .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; }
    .modal-content { background: #fff; border-radius: 12px; padding: 24px; width: 90%; max-width: 500px; margin: auto; top: 50%; transform: translateY(-50%); position: relative; }
    .modal.active { display: flex; align-items: center; justify-content: center; }
  </style>
</head>
<body class="main-layout position_head">
  <div class="admin-container">
    <h2><i class="fa fa-users"></i> Panel Admin - Gestión de Usuarios</h2>

    <div class="admin-nav">
      <a href="admin_panel.php">Publicaciones</a>
      <a href="admin_chats.php">Chats</a>
      <a href="admin_mensajes.php">Mensajes</a>
      <a href="admin_usuarios.php" class="active">Usuarios</a>
      <a href="publicaciones.php">Volver al Sitio</a>
    </div>

    <?php if (isset($_GET['sancionado'])): ?>
    <div class="alert alert-success"><i class="fa fa-check"></i> Usuario sancionado correctamente.</div>
    <?php elseif (isset($_GET['eliminado'])): ?>
    <div class="alert alert-success"><i class="fa fa-check"></i> Usuario eliminado correctamente.</div>
    <?php elseif (isset($_GET['sancion_levantada'])): ?>
    <div class="alert alert-success"><i class="fa fa-check"></i> Sanción levantada.</div>
    <?php endif; ?>

    <?php if ($result && $result->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>C.I.</th>
          <th>Nombre</th>
          <th>Correo</th>
          <th>Publicaciones</th>
          <th>Sanciones</th>
          <th>Registrado</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['ci']); ?></td>
          <td><?php echo htmlspecialchars($row['nombre'] . ' ' . $row['apellido']); ?></td>
          <td><?php echo htmlspecialchars($row['correo']); ?></td>
          <td><?php echo intval($row['total_publicaciones']); ?></td>
          <td>
            <?php if (intval($row['sanciones_activas']) > 0): ?>
            <span class="badge-sancion"><i class="fa fa-exclamation"></i> <?php echo intval($row['sanciones_activas']); ?> activa(s)</span>
            <?php else: ?>
            <span style="color:#999;">Sin sanciones</span>
            <?php endif; ?>
          </td>
          <td><?php echo date('d/m/Y', strtotime($row['fecha_registro'])); ?></td>
          <td style="display:flex;gap:6px;">
            <button class="btn-sancion" onclick="abrirModalSancion(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['nombre']); ?>')">Sancionar</button>
            <button class="btn-eliminar" onclick="if(confirm('¿Eliminar usuario?')) { document.getElementById('form-eliminar').innerHTML='<form method=POST><input type=hidden name=action value=eliminar><input type=hidden name=id_usuario value=<?php echo $row['id']; ?>></form>'; document.getElementById('form-eliminar').firstChild.submit(); }">Eliminar</button>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div style="text-align:center;padding:40px;color:#999;">
      <i class="fa fa-users" style="font-size:2rem;margin-bottom:10px;display:block;"></i>
      <p>No hay usuarios registrados</p>
    </div>
    <?php endif; ?>
  </div>

  <!-- Modal sanción -->
  <div id="modalSancion" class="modal">
    <div class="modal-content">
      <h5>Sancionar Usuario</h5>
      <form method="POST">
        <input type="hidden" name="action" value="sancionar">
        <input type="hidden" name="id_usuario" id="modal-user-id" value="">
        <input type="hidden" id="modal-user-name" value="">
        
        <p style="margin-bottom:16px;"><strong>Usuario:</strong> <span id="modal-user-display"></span></p>
        
        <label>Tipo de Sanción:</label>
        <select name="tipo" style="width:100%;padding:8px;margin-bottom:16px;border:1px solid #ccc;border-radius:6px;">
          <option value="advertencia">Advertencia</option>
          <option value="suspension_24">Suspensión 24 horas</option>
          <option value="suspension_7">Suspensión 7 días</option>
          <option value="bloqueo">Bloqueo permanente</option>
        </select>
        
        <label>Motivo:</label>
        <textarea name="motivo" style="width:100%;padding:8px;margin-bottom:16px;border:1px solid #ccc;border-radius:6px;resize:vertical;height:80px;" required></textarea>
        
        <div style="display:flex;gap:8px;justify-content:flex-end;">
          <button type="button" onclick="cerrarModal()" style="background:#999;color:#fff;padding:8px 16px;border:none;border-radius:6px;cursor:pointer;">Cancelar</button>
          <button type="submit" style="background:#ffc107;color:#000;padding:8px 16px;border:none;border-radius:6px;cursor:pointer;font-weight:600;">Sancionar</button>
        </div>
      </form>
    </div>
  </div>

  <div id="form-eliminar"></div>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script>
    function abrirModalSancion(userId, userName) {
      document.getElementById('modal-user-id').value = userId;
      document.getElementById('modal-user-display').textContent = userName;
      document.getElementById('modalSancion').classList.add('active');
    }
    function cerrarModal() {
      document.getElementById('modalSancion').classList.remove('active');
    }
  </script>
</body>
</html>
