<?php
require_once 'conexion.php';
session_start();

// Verificar si es admin
$is_admin = false;
if (isset($_SESSION['correo']) && $_SESSION['correo'] === 'codemass2025@gmail.com') {
    $is_admin = true;
}

if (!$is_admin) {
    header('Location: index.html');
    exit;
}

// Obtener todos los chats
$query = "SELECT c.id, c.fecha_creacion,
          u1.nombre AS nombre_usuario_1, u1.apellido AS apellido_usuario_1, u1.ci AS ci_usuario_1,
          u2.nombre AS nombre_usuario_2, u2.apellido AS apellido_usuario_2, u2.ci AS ci_usuario_2,
          st.estado AS estado_solicitud,
          p.titulo AS publicacion_titulo,
          (SELECT COUNT(*) FROM mensajes_chat WHERE id_chat = c.id) AS total_mensajes,
          (SELECT MAX(fecha_envio) FROM mensajes_chat WHERE id_chat = c.id) AS ultimo_mensaje
          FROM chats c
          JOIN usuarios u1 ON c.id_usuario_1 = u1.id
          JOIN usuarios u2 ON c.id_usuario_2 = u2.id
          JOIN solicitudes_trueque st ON c.id_solicitud = st.id
          JOIN publicaciones p ON st.id_publicacion = p.id
          ORDER BY c.fecha_creacion DESC";
$result = $conexion->query($query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Panel Admin - Chats</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%); }
    .admin-container { background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(99,102,241,0.1); padding: 30px; margin-top: 40px; margin-bottom: 40px; max-width: 1000px; margin-left: auto; margin-right: auto; }
    h2 { color: #7c5fe9; font-weight: 700; margin-bottom: 30px; }
    .admin-nav { display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap; }
    .admin-nav a { background: #6366f1; color: #fff; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; }
    .admin-nav a:hover { background: #5558d9; text-decoration: none; }
    .admin-nav a.active { background: #7c5fe9; }
    .chat-row { border: 1px solid #e3e0f7; border-radius: 12px; padding: 15px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; }
    .chat-info { flex: 1; }
    .chat-info h5 { color: #6366f1; margin: 0 0 8px 0; }
    .chat-info p { margin: 4px 0; color: #666; font-size: 0.9rem; }
    .chat-actions { display: flex; gap: 8px; }
    .btn-sm { padding: 6px 12px; border-radius: 6px; border: none; cursor: pointer; font-weight: 600; }
    .btn-view { background: #6366f1; color: #fff; }
    .btn-view:hover { background: #5558d9; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    table th { background: #6366f1; color: #fff; padding: 12px; text-align: left; }
    table td { padding: 12px; border-bottom: 1px solid #e3e0f7; }
    table tr:hover { background: #f8f9ff; }
  </style>
</head>
<body class="main-layout position_head">
  <div class="admin-container">
    <h2><i class="fa fa-comments"></i> Panel Admin - Chats de Usuarios</h2>

    <div class="admin-nav">
      <a href="admin_panel.php">Publicaciones</a>
      <a href="admin_chats.php" class="active">Chats</a>
      <a href="admin_mensajes.php">Mensajes</a>
      <a href="admin_usuarios.php">Usuarios</a>
      <a href="publicaciones.php">Volver al Sitio</a>
    </div>

    <?php if ($result && $result->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>Usuario 1</th>
          <th>Usuario 2</th>
          <th>Publicación</th>
          <th>Mensajes</th>
          <th>Último Mensaje</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['nombre_usuario_1'] . ' ' . $row['apellido_usuario_1']); ?><br><small><?php echo htmlspecialchars($row['ci_usuario_1']); ?></small></td>
          <td><?php echo htmlspecialchars($row['nombre_usuario_2'] . ' ' . $row['apellido_usuario_2']); ?><br><small><?php echo htmlspecialchars($row['ci_usuario_2']); ?></small></td>
          <td><?php echo htmlspecialchars($row['publicacion_titulo']); ?></td>
          <td><?php echo intval($row['total_mensajes']); ?></td>
          <td><?php echo $row['ultimo_mensaje'] ? date('d/m/Y H:i', strtotime($row['ultimo_mensaje'])) : 'Sin mensajes'; ?></td>
          <td><span style="background:#d4edda;color:#155724;padding:4px 8px;border-radius:4px;font-weight:600;"><?php echo ucfirst($row['estado_solicitud']); ?></span></td>
          <td>
            <a href="admin_chat_detalle.php?id=<?php echo $row['id']; ?>" class="btn-sm btn-view">Ver Chat</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div style="text-align:center;padding:40px;color:#999;">
      <i class="fa fa-comments" style="font-size:2rem;margin-bottom:10px;display:block;"></i>
      <p>No hay chats aún</p>
    </div>
    <?php endif; ?>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
