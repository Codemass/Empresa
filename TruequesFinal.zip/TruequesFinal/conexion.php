<?php
	$conexion = new mysqli("localhost", "root", "", "proyecto", 3307);
	if ($conexion->connect_errno) {
		echo "Lo sentimos, este sitio web está experimentando problemas.";
		exit;
	}
	
	// Ejecutar el archivo SQL completo usando multi_query (maneja comentarios y delimitadores correctamente)
	$sqlFile = file_get_contents(__DIR__ . '/Nuevito.sql');
	if ($sqlFile !== false) {
	    if ($conexion->multi_query($sqlFile)) {
	        // iterar hasta consumir todas las respuestas
	        do {
	            if ($res = $conexion->store_result()) {
	                $res->free();
	            }
	        } while ($conexion->more_results() && $conexion->next_result());
	    } else {
	        // Loguear por si hay error ejecutando el script SQL (no interrumpir)
	        error_log("Error ejecutando Nuevito.sql: " . $conexion->error);
	    }
	}
	
	// --- Asegurar columnas que el front espera en `publicaciones` ---
	// Añadir columna 'titulo' si no existe
	$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'titulo'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `titulo` VARCHAR(255) NOT NULL AFTER `id`");
	}
	// Añadir columna 'descripcion' si no existe
	$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'descripcion'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `descripcion` TEXT NOT NULL AFTER `titulo`");
	}
	// Añadir columna id_usuario si no existe (y FK silenciosa)
	$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'id_usuario'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `id_usuario` INT NULL AFTER `descripcion`");
	    @ $conexion->query("ALTER TABLE `publicaciones` ADD CONSTRAINT fk_publicaciones_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE SET NULL");
	}
	// Añadir columna 'imagen' si no existe
	$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'imagen'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `imagen` VARCHAR(255) DEFAULT 'images/default-avatar.png' AFTER `titulo`");
	}
	// Añadir columna 'categoria' si no existe
	$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'categoria'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `categoria` VARCHAR(100) DEFAULT NULL AFTER `titulo`");
	}
	// Añadir columna 'fecha_creacion' si no existe
	$res = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'fecha_creacion'");
	if ($res && $res->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `fecha_creacion` DATETIME DEFAULT CURRENT_TIMESTAMP AFTER `id_usuario`");
	}
	// Asegurar columna 'activo'
	$res_pub_col = $conexion->query("SHOW COLUMNS FROM `publicaciones` LIKE 'activo'");
	if ($res_pub_col && $res_pub_col->num_rows === 0) {
	    $conexion->query("ALTER TABLE `publicaciones` ADD COLUMN `activo` TINYINT(1) NOT NULL DEFAULT 1");
	}
	// --- fin cambio ---
	
	// Verificar si el admin por defecto existe
	$stmt = $conexion->prepare("SELECT id FROM administradores WHERE ci = ?");
	$ci = "51946920";
	$stmt->bind_param("s", $ci);
	$stmt->execute();
	$stmt->store_result();
	
	// Si no existe, crear el admin por defecto
	if ($stmt->num_rows == 0) {
	    $stmt->close();
	    $stmt = $conexion->prepare("INSERT INTO administradores (ci, nombre, apellido, correo, fecha_nacimiento, contrasena) VALUES (?, ?, ?, ?, ?, ?)");
	    $ci = "51946920";
	    $nombre = "El";
	    $apellido = "Admin";
	    $correo = "codemass2025@gmail.com";
	    $fecha_nacimiento = "2025-11-13";
	    $contrasena = password_hash("A13M11S07S09cm", PASSWORD_DEFAULT);
	    $stmt->bind_param("ssssss", $ci, $nombre, $apellido, $correo, $fecha_nacimiento, $contrasena);
	    $stmt->execute();
	    $stmt->close();
	}
?>