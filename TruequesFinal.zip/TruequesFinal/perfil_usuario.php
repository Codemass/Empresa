<?php
require_once 'conexion.php';
session_start();

// Obtener user_id del usuario logueado
$user_id_logueado = null;
if (isset($_SESSION['user_id'])) {
    $user_id_logueado = intval($_SESSION['user_id']);
} elseif (isset($_SESSION['ci'])) {
    $ci = $_SESSION['ci'];
    $stmtu = $conexion->prepare("SELECT id FROM usuarios WHERE ci = ? LIMIT 1");
    if ($stmtu) {
        $stmtu->bind_param("s", $ci);
        $stmtu->execute();
        $stmtu->bind_result($uid);
        if ($stmtu->fetch()) $user_id_logueado = intval($uid);
        $stmtu->close();
    }
}

// Obtener id del usuario a visualizar
$id_usuario = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id_usuario <= 0) {
    header("Location: publicaciones.php");
    exit;
}

// Si intenta ver su propio perfil, redirigir a ajustes
if ($user_id_logueado && $user_id_logueado === $id_usuario) {
    header("Location: ajustes.html");
    exit;
}

// Obtener datos del usuario
$stmt = $conexion->prepare("SELECT nombre, apellido, avatar, fecha_registro FROM usuarios WHERE id = ?");
if ($stmt === false) {
    die('Error en la preparación de la consulta: ' . $conexion->error);
}
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if (!$usuario) {
    header("Location: publicaciones.php");
    exit;
}

// Obtener calificaciones del usuario
$stmt = $conexion->prepare("
    SELECT c.*, u.nombre AS evaluador_nombre, u.apellido AS evaluador_apellido, u.avatar AS evaluador_avatar
    FROM calificaciones c
    LEFT JOIN usuarios u ON c.id_usuario_evaluador = u.id
    WHERE c.id_usuario_evaluado = ?
    ORDER BY c.fecha_calificacion DESC
");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado_cal = $stmt->get_result();
$calificaciones = [];
while ($row = $resultado_cal->fetch_assoc()) {
    $calificaciones[] = $row;
}
$stmt->close();

// Calcular promedio de calificaciones
$promedio = 0;
$total_cal = count($calificaciones);
if ($total_cal > 0) {
    $suma = array_sum(array_column($calificaciones, 'puntuacion'));
    $promedio = round($suma / $total_cal, 1);
}

// Verificar si el usuario logueado ya calificó a este usuario
$ya_califico = false;
if ($user_id_logueado) {
    $stmt = $conexion->prepare("SELECT id FROM calificaciones WHERE id_usuario_evaluado = ? AND id_usuario_evaluador = ?");
    $stmt->bind_param("ii", $id_usuario, $user_id_logueado);
    $stmt->execute();
    $resultado_check = $stmt->get_result();
    $ya_califico = $resultado_check->num_rows > 0;
    $stmt->close();
}

// Obtener publicaciones del usuario
$stmt = $conexion->prepare("SELECT id, titulo, imagen, categoria, fecha_creacion FROM publicaciones WHERE id_usuario = ? AND activo = 1 ORDER BY fecha_creacion DESC LIMIT 6");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado_pub = $stmt->get_result();
$publicaciones = [];
while ($row = $resultado_pub->fetch_assoc()) {
    $publicaciones[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CHANGEMASS - Perfil de <?php echo htmlspecialchars($usuario['nombre']); ?></title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/responsive.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <style>
         body {
            background: linear-gradient(135deg, #e3e0f7 0%, #b6b3e6 100%);
         }
         .perfil-header {
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 4px 24px 0 rgba(99,102,241,0.10);
            padding: 40px 30px;
            margin-bottom: 30px;
            text-align: center;
         }
         .perfil-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 20px;
            border: 4px solid #7c5fe9;
         }
         .perfil-nombre {
            color: #7c5fe9;
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
         }
         .stars {
            color: #ffc107;
            font-size: 1.3rem;
            margin: 10px 0;
         }
         .calificacion-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 12px rgba(99,102,241,0.10);
         }
         .calificador-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 10px;
         }
         .calificador-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
         }
      </style>
   </head>
   <body class="main-layout position_head">
      <!-- ...existing header code... -->
      <header>
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.png" alt="#" width="150" height="150" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark">
                        <div class="collapse navbar-collapse">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item"><a class="nav-link" href="index.html">Inicio</a></li>
                              <li class="nav-item"><a class="nav-link" href="publicaciones.php">Publicaciones</a></li>
                              <li class="nav-item"><a class="nav-link" href="publicar.html">Publicar</a></li>
                              <li class="nav-item"><a class="nav-link" href="contactanos.php">Contactanos</a></li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>

      <div class="container" style="margin-top:50px;margin-bottom:50px;">
         <div class="row">
            <div class="col-md-8 offset-md-2">
               <!-- Perfil del usuario -->
               <div class="perfil-header animate__animated animate__fadeInUp">
                  <img src="<?php echo htmlspecialchars($usuario['avatar'] ?? 'images/default-avatar.png'); ?>" alt="avatar" class="perfil-avatar">
                  <div class="perfil-nombre"><?php echo htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']); ?></div>
                  <p style="color:#666;margin:5px 0;">Miembro desde <?php echo date('d/m/Y', strtotime($usuario['fecha_registro'])); ?></p>
                  
                  <div class="stars">
                     <?php 
                        for ($i = 1; $i <= 5; $i++) {
                           echo $i <= floor($promedio) ? '★' : ($i - $promedio < 1 ? '✩' : '☆');
                        }
                     ?>
                     <span style="color:#333;margin-left:10px;"><?php echo $total_cal > 0 ? $promedio . '/5 (' . $total_cal . ' calificaciones)' : 'Sin calificaciones'; ?></span>
                  </div>

                  <?php if ($user_id_logueado && !$ya_califico): ?>
                  <div style="margin-top:20px;">
                     <a href="calificar_usuario.php?id=<?php echo $id_usuario; ?>" class="btn btn-primary btn-lg">
                        <i class="fa fa-star"></i> Calificar a este usuario
                     </a>
                  </div>
                  <?php elseif ($ya_califico): ?>
                  <div style="margin-top:20px;padding:10px;background:#d4edda;color:#155724;border-radius:8px;border:1px solid #c3e6cb;">
                     Ya has calificado a este usuario. <a href="calificar_usuario.php?id=<?php echo $id_usuario; ?>">Editar calificación</a>
                  </div>
                  <?php elseif (!$user_id_logueado): ?>
                  <div style="margin-top:20px;">
                     <a href="login.php" class="btn btn-warning btn-lg">
                        <i class="fa fa-sign-in"></i> Inicia sesión para calificar
                     </a>
                  </div>
                  <?php endif; ?>
               </div>

               <!-- Publicaciones del usuario -->
               <?php if (count($publicaciones) > 0): ?>
               <div style="margin-top:40px;margin-bottom:30px;">
                  <h3 style="color:#7c5fe9;font-weight:700;margin-bottom:20px;">Publicaciones Recientes</h3>
                  <div class="row">
                     <?php foreach ($publicaciones as $pub): ?>
                     <div class="col-md-6">
                        <div class="glasses_box" style="text-align:center;margin-bottom:15px;cursor:pointer;" onclick="window.location.href='publicacion.php?id=<?php echo $pub['id']; ?>'">
                           <figure>
                              <img src="<?php echo htmlspecialchars($pub['imagen']); ?>" alt="<?php echo htmlspecialchars($pub['titulo']); ?>" style="width:100%;height:200px;object-fit:cover;border-radius:12px;">
                           </figure>
                           <p style="padding:10px;margin:0;color:#6366f1;font-weight:600;"><?php echo htmlspecialchars($pub['categoria']); ?></p>
                        </div>
                     </div>
                     <?php endforeach; ?>
                  </div>
               </div>
               <?php endif; ?>

               <!-- Calificaciones -->
               <?php if (count($calificaciones) > 0): ?>
               <div style="margin-top:40px;">
                  <h3 style="color:#7c5fe9;font-weight:700;margin-bottom:20px;">Calificaciones de otros usuarios</h3>
                  <?php foreach ($calificaciones as $cal): ?>
                  <div class="calificacion-card">
                     <div class="calificador-info">
                        <img src="<?php echo htmlspecialchars($cal['evaluador_avatar'] ?? 'images/default-avatar.png'); ?>" alt="avatar" class="calificador-avatar">
                        <div>
                           <strong style="color:#333;"><?php echo htmlspecialchars(($cal['evaluador_nombre'] ?? 'Usuario Anónimo') . ' ' . ($cal['evaluador_apellido'] ?? '')); ?></strong>
                           <p style="font-size:0.85rem;color:#999;margin:0;">
                              <?php echo date('d/m/Y H:i', strtotime($cal['fecha_calificacion'])); ?>
                           </p>
                        </div>
                     </div>
                     <div class="stars" style="margin-bottom:10px;">
                        <?php 
                           for ($i = 1; $i <= 5; $i++) {
                              echo $i <= $cal['puntuacion'] ? '★' : '☆';
                           }
                        ?>
                        <span style="color:#333;font-weight:600;margin-left:10px;"><?php echo $cal['puntuacion']; ?>/5</span>
                     </div>
                     <?php if ($cal['comentario']): ?>
                     <p style="color:#555;margin:10px 0 0 0;"><?php echo nl2br(htmlspecialchars($cal['comentario'])); ?></p>
                     <?php endif; ?>
                  </div>
                  <?php endforeach; ?>
               </div>
               <?php endif; ?>

               <div style="text-align:center;margin-top:40px;">
                  <a href="publicaciones.php" class="read_more"><i class="fa fa-arrow-left"></i> Volver</a>
               </div>
            </div>
         </div>
      </div>

      <!-- ...existing footer code... -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <ul class="location_icon">
                        <li><a href="#"><i class="fa fa-map-marker"></i></a><span>Ubicación</span></li>
                        <li><a href="#"><i class="fa fa-phone"></i></a><span>+598 95 561 757</span></li>
                        <li><a href="https://mail:codemass2025@gmail.com"><i class="fa fa-envelope"></i></a><span>codemass2025@gmail.com</span></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>©2025 Design by CODEMASS</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>

      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
   </body>
</html>
